﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.Administrators;
using BusinessLogic.Students;
using BusinessLogic.Teachers;
using DataAccess.Users;
using ENTITIES;

namespace BusinessLogic.Users
{
    public class UserServices : IUserServices
    {
        IUsersRepository Repository = new UserRepository();
        IAdministratorService serviceAdministrator = new AdministratorService();
        IStudentService serviceStudent = new StudentService();
        ITeacherService serviceTeacher = new TeacherService();

        public bool CreateUser(USER obj)
        {
            if (obj.Name != "" && obj.LastName != "" && obj.UserName != "" && obj.Pasword != "")
            {
                return Repository.CreateUser(obj);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteUser(int userId)
        {
            return Repository.DeleteUser(userId);
        }

        public USER GetUser(int userId)
        {
            return Repository.GetUser(userId);
        }

        public List<USER> GetUser()
        {
            return Repository.GetUser();
        }

        public List<USER> GetUserWithoutRelationship()
        {
            List<USER> original = GetUser();
            List<USER> result = new List<USER>();
            foreach (var item in original)
            {
                if (serviceTeacher.GetTeacher(item.ID)==null &&serviceStudent.GetStudent(item.ID)==null
                    && serviceAdministrator.GetAdministrator(item.ID)==null)
                {
                    result.Add(item);
                }
            }
            return result;
        }

        public bool UpdateUser(USER obj)
        {
            return Repository.UpdateUser(obj);
        }
    }
}
