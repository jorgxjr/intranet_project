﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Scores;
using ENTITIES;

namespace BusinessLogic.Scores
{
    public class ScoreService:IScoreService
    {
        IScoreRepository service = new ScoreRepository();

        public bool CreateScore(SCORE obj)
        {
            return service.CreateScore(obj);
        }

        public bool DeleteScore(int scoreID)
        {
            return service.DeleteScore(scoreID);
        }

        public SCORE GetLastScore()
        {
            return service.GetLastScore();
        }

        public List<SCORE> GetScore()
        {
            return service.GetScore();
        }

        public void UpdateScore(SCORE obj)
        {
            service.UpdateScore(obj);
        }
    }
}
