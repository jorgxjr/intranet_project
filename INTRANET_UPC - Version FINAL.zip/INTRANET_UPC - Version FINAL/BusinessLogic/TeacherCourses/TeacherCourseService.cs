﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.Teachers;
using DataAccess.TeacherCourses;
using ENTITIES;

namespace BusinessLogic.TeacherCourses
{
    public class TeacherCourseService:ITeacherCourseService
    {
        ITeacherCourseRepository service = new TeacherCourseRepository();
        ITeacherService serviceTeacher = new TeacherService();

        public bool CreateTeacherCourse(TECHER_COURSE obj)
        {
            return service.CreateTeacherCourse(obj);
        }

        public bool DeleteTeacherCourse(int teachercourseId)
        {
            return service.DeleteTeacherCourse(teachercourseId);
        }

        public List<TECHER_COURSE> GetTeacherCourse()
        {
            return service.GetTeacherCourse();
        }

        public TECHER_COURSE GetTeacherCourseByIDs(int teacherID, int courseID)
        {
            return service.GetTeacherCourseByIDs(teacherID, courseID);
        }

        public List<TEACHER> TeachersXCourse(int courseID)
        {
            List<TECHER_COURSE> lista = service.ListTeacherXCourse(courseID);
            List<TEACHER> result = new List<TEACHER>();
            foreach(var item in lista)
            {
                TEACHER t = serviceTeacher.GetTeacherXID(item.TeacherID);
                result.Add(t);
            }
            return result;
        }
    }
}
