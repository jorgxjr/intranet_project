﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.TeacherCourses
{
    public interface ITeacherCourseService
    {
        bool CreateTeacherCourse(TECHER_COURSE obj);
        bool DeleteTeacherCourse(int teachercourseId);
        List<TECHER_COURSE> GetTeacherCourse();
        List<TEACHER> TeachersXCourse(int courseID);
        TECHER_COURSE GetTeacherCourseByIDs(int teacherID, int courseID);
    }
}
