﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Administrators
{
    public interface IAdministratorService
    {
        bool CreateAdministrator(ADMINISTRATOR obj);
        bool UpdateAdministrator(ADMINISTRATOR obj);
        bool DeleteAdministrator(int administratorId);
        ADMINISTRATOR GetAdministrator(int UserID);
        List<ADMINISTRATOR> GetAdministrator();
    }
}
