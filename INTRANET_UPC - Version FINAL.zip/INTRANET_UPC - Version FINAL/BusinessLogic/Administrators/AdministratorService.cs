﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Administrators;
using ENTITIES;

namespace BusinessLogic.Administrators
{
    public class AdministratorService : IAdministratorService
    {
        IAdministratorRepository administratorRepository = new AdministratorRepository();

        public bool CreateAdministrator(ADMINISTRATOR obj)
        {
            if (obj.WorkArea != "")
            {
                return administratorRepository.CreateAdministrator(obj);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteAdministrator(int administratorId)
        {
            return administratorRepository.DeleteAdministrator(administratorId);
        }

        public ADMINISTRATOR GetAdministrator(int UserId)
        {
            return administratorRepository.GetAdministrator(UserId);
        }

        public List<ADMINISTRATOR> GetAdministrator()
        {
            return administratorRepository.GetAdministrator();
        }

        public bool UpdateAdministrator(ADMINISTRATOR obj)
        {
            return administratorRepository.UpdateAdministrator(obj);
        }
    }
}