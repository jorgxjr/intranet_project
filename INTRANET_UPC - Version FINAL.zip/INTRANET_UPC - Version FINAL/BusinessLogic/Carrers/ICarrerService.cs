﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Carrers
{
    public interface ICarrerService
    {
        bool CreateCarrer(CAREER obj);
        bool UpdateCarrer(CAREER obj);
        bool DeleteCarrer(int carrerId);
        List<CAREER> GetCarrer();
    }
}
