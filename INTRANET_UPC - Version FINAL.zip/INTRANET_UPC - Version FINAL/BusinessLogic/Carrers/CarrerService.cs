﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Carrers;
using ENTITIES;

namespace BusinessLogic.Carrers
{
    public class CarrerService : ICarrerService
    {
        ICarrerRepository service = new CarrerRepository();
        public bool CreateCarrer(CAREER obj)
        {
            if (obj.Name != "")
            {
                return service.CreateCarrer(obj);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteCarrer(int carrerId)
        {
            return service.DeleteCarrer(carrerId);
        }

        public List<CAREER> GetCarrer()
        {
            return service.GetCarrer();
        }

        public bool UpdateCarrer(CAREER obj)
        {
            return service.UpdateCarrer(obj);
        }
    }
}
