﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.StudentCourseSections
{
    public interface IStudentCourseSectionService
    {
        bool CreateStudentCourseSection(STUDENT__COURSE_SECTION obj);
        bool DeleteStudentCourseSection(int StudentCourseSectionID);
        List<STUDENT__COURSE_SECTION> GetStudentCourseSection();
        List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXcsID(int csID);
        List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXTeacherID(int teacherID);
        bool DeleteStudentCourseSection(int IDCourseSection, int IDStudent);
        bool ValidateData(int IDCourseSection, int IDStudent);
        List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXStudentID(int StudentID);
        STUDENT__COURSE_SECTION GetStudentCourseSection(int id);
        bool UpdateStudentCourseSection(int id, int scoreID);
    }
}
