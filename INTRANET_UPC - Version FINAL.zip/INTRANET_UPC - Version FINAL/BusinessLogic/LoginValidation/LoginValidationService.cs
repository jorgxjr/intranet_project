﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.LoginValidation;
using ENTITIES;

namespace BusinessLogic.LoginValidation
{
    public class LoginValidationService : ILoginValidationService
    {
        ILoginValidationRepository repository = new LoginValidationRepository();

        public void ChangeLastLogin(LOGIN_VALIDATION obj)
        {
            repository.ChangeLastLogin(obj);
        }

        public bool createLoginValidation(LOGIN_VALIDATION obj)
        {
            return repository.createLoginValidation(obj);
        }

        public List<LOGIN_VALIDATION> getLoginValidationsXUserID(int userID)
        {
            return repository.getLoginValidationsXUserID(userID);
        }

        public void ReduceAttempts(LOGIN_VALIDATION obj)
        {
            repository.ReduceAttempts(obj);
        }
    }
}
