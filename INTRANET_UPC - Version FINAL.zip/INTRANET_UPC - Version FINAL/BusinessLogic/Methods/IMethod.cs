﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Methods
{
    public interface IMethod
    {
        int ValidateUser(String UserName, String Password, out string error);
        Tuple<Char, STUDENT, TEACHER, ADMINISTRATOR> GetTypeOfUser(int userID);
        bool PermitLogin(int userID);
    }
}
