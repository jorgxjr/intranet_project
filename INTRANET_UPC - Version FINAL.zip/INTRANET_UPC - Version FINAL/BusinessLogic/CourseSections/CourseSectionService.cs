﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.CourseCarrers;
using BusinessLogic.TeacherCourses;
using DataAccess.CourseSections;
using ENTITIES;

namespace BusinessLogic.CourseSections
{
    public class CourseSectionService:ICourseSectionService
    {
        ICourseSectionRepository service = new CourseSectionRepository();
        ICourseCarrerService serviceCourseCarrer = new CourseCarrerService();
        public bool CreateCourseSection(COURSE_SECTION obj)
        {
            if (obj.Day != "" && obj.ClasroomName != "" && obj.VacanciesAvailable > 0 && obj.HourEnd > obj.HourStart)
            {
                return service.CreateCourseSection(obj);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteCourseSection(int courseSectionId)
        {
            return service.DeleteCourseSection(courseSectionId);
        }

        public List<COURSE_SECTION> GetCourseSection()
        {
            return service.GetCourseSection();
        }

        //filtra por carrera
        public List<COURSE_SECTION> GetCourseSection(STUDENT obj)
        {
            List<COURSE_SECTION> original = GetCourseSection();
            List<COURSE_SECTION> result = new List<COURSE_SECTION>();
            int carrerID = obj.CarrerID;
            List<COURSE_CARRER> lista = serviceCourseCarrer.GetCourseCarrer(carrerID);
            foreach(var item in original)
            {
                foreach(var item2 in lista)
                {
                    if(item.TECHER_COURSE.CourseID==item2.CourseID)
                    {
                        result.Add(item);
                    }
                }
            }

            return result;
        }

        public List<COURSE_SECTION> GetCourseSectionXTeacherID(int teacherID)
        {
            return service.GetCourseSectionXTeacherID(teacherID);
        }
    }
}
