﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.CourseSections
{
    public interface ICourseSectionService
    {
        bool CreateCourseSection(COURSE_SECTION obj);
        bool DeleteCourseSection(int courseSectionId);
        List<COURSE_SECTION> GetCourseSection();
        List<COURSE_SECTION> GetCourseSection(STUDENT obj);
        List<COURSE_SECTION> GetCourseSectionXTeacherID(int teacherID);
    }
}
