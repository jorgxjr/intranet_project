﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class TECHER_COURSE
    {
        public string courseName
        {
            set
            {

            }
            get
            {
                return this.COURSE.Name;
            }
        }
        public string teacherName
        {
            set
            {

            }
            get
            {
                return this.TEACHER.USER.Name + " " + this.TEACHER.USER.LastName;
            }
        }
    }
}
