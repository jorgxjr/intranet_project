﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class DEBT
    {
        public string studentName
        {
            set
            {

            }
            get
            {
                return this.STUDENT.USER.Name + " " + this.STUDENT.USER.LastName;
            }
        }
    }
}
