﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class ADMINISTRATOR
    {
        public string name
        {
            set
            {
                //nothing at all
            }
            get
            {
                return this.USER.Name;
            }
        }

        public string lastname
        {
            set
            {
                //nothing at all
            }
            get
            {
                return this.USER.LastName;
            }
        }

        public string daybirth
        {
            set
            {
                //nothing at all
            }
            get
            {
                return this.USER.DateOfBirth;
            }
        }

        public string gender
        {
            set
            {
                //nothing at all
            }
            get
            {
                return this.USER.Gender;
            }
        }

        public string username
        {
            set
            {
                //nothing at all
            }
            get
            {
                return this.USER.UserName;
            }
        }

        public int dni
        {
            set
            {
                //nothing at all
            }
            get
            {
                return this.USER.DNI;
            }
        }
    }
}
