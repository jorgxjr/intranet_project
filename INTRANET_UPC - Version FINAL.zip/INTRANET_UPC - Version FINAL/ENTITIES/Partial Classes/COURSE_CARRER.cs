﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class COURSE_CARRER
    {
        public string CareerName
        {
            set
            {

            }
            get
            {
                return this.CAREER.Name;
            }


        }

        public string CourseName
        {
            set
            {

            }
            get
            {
                return this.COURSE.Name;
            }
        }
    }
}
