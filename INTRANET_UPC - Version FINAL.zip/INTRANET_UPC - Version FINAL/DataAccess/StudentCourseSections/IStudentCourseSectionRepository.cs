﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.StudentCourseSections
{
    public interface IStudentCourseSectionRepository
    {
        bool CreateStudentCourseSection(STUDENT__COURSE_SECTION obj);
        bool DeleteStudentCourseSection(int StudentCourseSectionID);
        bool DeleteStudentCourseSection(int IDCourseSection, int IDStudent);
        List<STUDENT__COURSE_SECTION> GetStudentCourseSection();
        List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXcsID(int csID);
        List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXTeacherID(int teacherID);
        List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXStudentID(int StudentID);
        bool ValidateData(int IDCourseSection, int IDStudent);
        STUDENT__COURSE_SECTION GetStudentCourseSection(int id);
        bool UpdateStudentCourseSection(int id, int scoreID);
    }
}
