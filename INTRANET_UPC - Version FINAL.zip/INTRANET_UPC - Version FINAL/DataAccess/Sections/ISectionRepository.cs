﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Sections
{
    public interface ISectionRepository
    {
        bool CreateSection(SECTION obj);
        bool DeleteSection(int sectionId);
        List<SECTION> GetSection();
    }
}
