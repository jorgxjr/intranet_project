﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.CourseSections
{
    public class CourseSectionRepository : ICourseSectionRepository
    {
        public bool CreateCourseSection(COURSE_SECTION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.COURSE_SECTION.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteCourseSection(int courseSectionId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var CourseSection = from c in dataContext.COURSE_SECTION
                                       where c.ID == courseSectionId select c;
                    COURSE_SECTION objCourseSection = CourseSection.FirstOrDefault();

                    dataContext.COURSE_SECTION.Remove(objCourseSection);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<COURSE_SECTION> GetCourseSection()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var CourseSection = from c in dataContext.COURSE_SECTION.Include("SECTION").Include("TECHER_COURSE").Include("TECHER_COURSE.COURSE").Include("TECHER_COURSE.TEACHER").Include("TECHER_COURSE.TEACHER.USER")
                                    select c;

                return CourseSection.ToList();
            }
        }

        public List<COURSE_SECTION> GetCourseSectionXTeacherID(int teacherID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var CourseSection = from c in dataContext.COURSE_SECTION.
                         Include("SECTION").
                         Include("TECHER_COURSE.COURSE")
                         where c.TECHER_COURSE.TeacherID.Equals(teacherID)
                         select c;

                return CourseSection.ToList();
            }
        }
    }
}
