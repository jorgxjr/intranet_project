﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.CourseSections
{
    public interface ICourseSectionRepository
    {
        bool CreateCourseSection(COURSE_SECTION obj);
        bool DeleteCourseSection(int courseSectionId);
        List<COURSE_SECTION> GetCourseSection();
        List<COURSE_SECTION> GetCourseSectionXTeacherID(int teacherID);
    }
}
