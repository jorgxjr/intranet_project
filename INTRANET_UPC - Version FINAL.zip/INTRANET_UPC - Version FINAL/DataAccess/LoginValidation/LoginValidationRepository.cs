﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.LoginValidation
{
    public class LoginValidationRepository : ILoginValidationRepository
    {
        public void ChangeLastLogin(LOGIN_VALIDATION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var login = from c in dataContext.LOGIN_VALIDATION where c.ID == obj.ID select c;
                LOGIN_VALIDATION L = login.FirstOrDefault();
                L.LastLogin = DateTime.Now;
                dataContext.SaveChanges();
            }
        }

        public bool createLoginValidation(LOGIN_VALIDATION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.LOGIN_VALIDATION.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<LOGIN_VALIDATION> getLoginValidationsXUserID(int userID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var login = from c in dataContext.LOGIN_VALIDATION where c.UserID==userID select c;

                return login.ToList();
            }
        }

        public void ReduceAttempts(LOGIN_VALIDATION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var login = from c in dataContext.LOGIN_VALIDATION where c.ID == obj.ID select c;
                LOGIN_VALIDATION L = login.FirstOrDefault();
                L.Attempts -= 1;
                dataContext.SaveChanges();
            }
        }
    }
}
