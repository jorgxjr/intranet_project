﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.LoginValidation
{
    public interface ILoginValidationRepository
    {
        bool createLoginValidation(LOGIN_VALIDATION obj);
        List<LOGIN_VALIDATION> getLoginValidationsXUserID(int userID);
        void ReduceAttempts(LOGIN_VALIDATION obj);
        void ChangeLastLogin(LOGIN_VALIDATION obj);
    }
}
