﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Students
{
    public class StudentRepository : IStudentRepository
    {
        public bool CreateStudent(STUDENT obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.STUDENTs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteStudent(int studentId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var student = from c in dataContext.STUDENTs where c.ID == studentId select c;
                    STUDENT objStudent = student.FirstOrDefault();

                    dataContext.STUDENTs.Remove(objStudent);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public STUDENT GetStudent(int UserID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var student = from c in dataContext.STUDENTs.Include("USER").Include("CAREER") where c.UserID == UserID select c;
                STUDENT objStudent = student.FirstOrDefault();

                return objStudent;
            }
        }

        public List<STUDENT> GetStudent()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var student = from c in dataContext.STUDENTs.Include("USER").Include("CAREER") select c;

                return student.ToList();
            }
        }

        public bool UpdateStudent(STUDENT obj)
        {
            throw new NotImplementedException();
        }
    }
}
