﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Debts
{
    public class DebtRepository : IDebtRepository
    {
        public bool CreateDebt(DEBT obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.DEBTs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {

                    return false;
                }
            }
        }

        public bool DeleteDebt(int debtId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var debt = from c in dataContext.DEBTs where c.ID == debtId select c;
                    DEBT objDebt = debt.FirstOrDefault();

                    dataContext.DEBTs.Remove(objDebt);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<DEBT> GetDebt()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var debt = from c in dataContext.DEBTs.Include("STUDENT").Include("STUDENT.USER") select c;

                return debt.ToList();
            }
        }

        public List<DEBT> GetDebt(int StudentID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var debt = from c in dataContext.DEBTs where c.StudentID == StudentID select c;

                return debt.ToList();
            }
        }
    }
}
