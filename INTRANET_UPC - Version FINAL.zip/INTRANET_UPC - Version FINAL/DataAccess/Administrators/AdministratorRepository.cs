﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Administrators
{
    public class AdministratorRepository : IAdministratorRepository
    {
        public bool CreateAdministrator(ADMINISTRATOR obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.ADMINISTRATORs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteAdministrator(int administratorId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var administaror = from c in dataContext.ADMINISTRATORs where c.ID == administratorId select c;
                    ADMINISTRATOR objAdministrator = administaror.FirstOrDefault();

                    dataContext.ADMINISTRATORs.Remove(objAdministrator);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<ADMINISTRATOR> GetAdministrator()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var administaror = from c in dataContext.ADMINISTRATORs.Include("USER") select c;

                return administaror.ToList();
            }
        }

        public ADMINISTRATOR GetAdministrator(int UserID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var administaror = from c in dataContext.ADMINISTRATORs.Include("USER") where c.UserID == UserID select c;
                ADMINISTRATOR objAdministaror  = administaror.FirstOrDefault();

                return objAdministaror;
            }
        }

        public bool UpdateAdministrator(ADMINISTRATOR obj)
        {
            throw new NotImplementedException();
        }
    }
}
