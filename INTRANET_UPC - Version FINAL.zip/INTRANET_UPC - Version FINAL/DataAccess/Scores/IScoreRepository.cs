﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Scores
{
    public interface IScoreRepository
    {
        bool CreateScore(SCORE obj);
        bool DeleteScore(int scoreID);
        void UpdateScore(SCORE obj);
        List<SCORE> GetScore();
        SCORE GetLastScore();
    }
}
