﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Carrers
{
    public class CarrerRepository : ICarrerRepository
    {
        public bool CreateCarrer(CAREER obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.CAREERs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteCarrer(int carrerId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var carrer = from c in dataContext.CAREERs where c.ID == carrerId select c;
                    CAREER objCarrer = carrer.FirstOrDefault();

                    dataContext.CAREERs.Remove(objCarrer);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<CAREER> GetCarrer()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var carrer = from c in dataContext.CAREERs select c;

                return carrer.ToList();
            }
        }

        public bool UpdateCarrer(CAREER obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var carrer = from c in dataContext.CAREERs where c.ID == obj.ID select c;

                    CAREER objCarrer = carrer.FirstOrDefault();
                    objCarrer.Name = obj.Name;

                    dataContext.SaveChanges();

                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }
    }
}
