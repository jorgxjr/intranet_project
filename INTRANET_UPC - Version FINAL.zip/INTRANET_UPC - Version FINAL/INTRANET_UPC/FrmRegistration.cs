﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.CourseSections;
using BusinessLogic.Scores;
using BusinessLogic.StudentCourseSections;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmRegistration : Form
    {
        IStudentCourseSectionService service = new StudentCourseSectionService();
        ICourseSectionService serviceCourseSection = new CourseSectionService();

        IScoreService serviceScore = new ScoreService();

        List<COURSE_SECTION> lista;

        public int STUDENtid;
        public STUDENT objStudent;
        public FrmRegistration()
        {
            InitializeComponent();
        }

        private void FrmRegistration_Load(object sender, EventArgs e)
        {
            DataSource_StudentCourceSection();
        }

        void DataSource_StudentCourceSection()
        {
            lista = serviceCourseSection.GetCourseSection(objStudent);
            dgVResgistration.DataSource = lista;
        }
        void SavaData_Score(SCORE objScore)
        {
            objScore.PC01 = 0;
            objScore.PC02 = 0;
            objScore.PC03 = 0;
            objScore.MidtermExam = 0;
            objScore.FinalExam = 0;
        }
        private void dgVResgistration_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVResgistration.Columns[e.ColumnIndex].HeaderText.ToLower() == "registration")
            {
                if (MessageBox.Show("Are you sure you want to registration in this course?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    COURSE_SECTION objCourseSection = (COURSE_SECTION)dgVResgistration.Rows[e.RowIndex].DataBoundItem;
                    STUDENT__COURSE_SECTION obj = new STUDENT__COURSE_SECTION();
                    obj.Course_SectionID = objCourseSection.ID;
                    obj.StudentID = STUDENtid;
                    SCORE objScore = new SCORE();
                    SavaData_Score(objScore);
                    serviceScore.CreateScore(objScore);
                    obj.ScoreID = serviceScore.GetLastScore().ID;

                    bool flag = service.CreateStudentCourseSection(obj);
                    if(!flag)
                    {
                        MessageBox.Show("It's not posible to registration");
                    }
                }
            }
            else if (dgVResgistration.Columns[e.ColumnIndex].HeaderText.ToLower() == "deregister")
            {
                if (MessageBox.Show("Are you sure you want to Deregister this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    COURSE_SECTION objCourseSection = (COURSE_SECTION)dgVResgistration.Rows[e.RowIndex].DataBoundItem;
                    bool flag = service.DeleteStudentCourseSection(objCourseSection.ID, STUDENtid);
                    if(!flag)
                    {
                        MessageBox.Show("It's not posible to deregister");
                    }
                }
            }
        }
    }
}
