﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.Users;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmStudent : Form
    {
        public STUDENT OBJStudent;
        public int NumberUser;
        private FrmRegistration FormRegistration;
        private FrmViewCourses FormViewCourses;
        private FrmDebt FormDebt;
        private FrmUpdateDataStudent FormUpdateDataStudent;

        IUserServices serviceUser = new UserServices();

        public FrmStudent()
        {
            InitializeComponent();
        }

        private FrmRegistration MyFormRegistration
        {
            get
            {
                if (FormRegistration == null || FormRegistration.IsDisposed)
                {
                    FormRegistration = new FrmRegistration();
                    FormRegistration.MdiParent = this;
                    FormRegistration.STUDENtid = OBJStudent.ID;
                    FormRegistration.objStudent = OBJStudent;
                }
                return FormRegistration;
            }
        }

        private FrmViewCourses MyFormViewCourses
        {
            get
            {
                if (FormViewCourses == null || FormViewCourses.IsDisposed)
                {
                    FormViewCourses = new FrmViewCourses();
                    FormViewCourses.MdiParent = this;
                    FormViewCourses.OBJstudent = OBJStudent;
                }
                return FormViewCourses;
            }
        }

        private FrmDebt MyFormDebt
        {
            get
            {
                if (FormDebt == null || FormDebt.IsDisposed)
                {
                    FormDebt = new FrmDebt();
                    FormDebt.MdiParent = this;
                    FormDebt.OBJstudent = this.OBJStudent;
                }
                return FormDebt;
            }
        }

        private FrmUpdateDataStudent MyFormUpdateDataStudent
        {
            get
            {
                if (FormUpdateDataStudent == null || FormUpdateDataStudent.IsDisposed)
                {
                    FormUpdateDataStudent = new FrmUpdateDataStudent();
                    FormUpdateDataStudent.MdiParent = this;
                    FormUpdateDataStudent.OBJstudent = this.OBJStudent;
                    FormUpdateDataStudent.UserID = this.NumberUser;
                }
                return FormUpdateDataStudent;
            }

        }

        private void FrmStudent_Load(object sender, EventArgs e)
        {
            this.Text = "Student: " + serviceUser.GetUser(NumberUser).UserName;
        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyFormRegistration.Show();
        }

        private void viewCoursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyFormViewCourses.Show();
        }

        private void debtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyFormDebt.Show();
        }

        private void updateDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MyFormUpdateDataStudent.Show();
        }

    }
}
