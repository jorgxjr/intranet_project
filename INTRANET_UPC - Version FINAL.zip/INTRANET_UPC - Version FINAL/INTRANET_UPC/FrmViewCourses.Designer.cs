﻿namespace INTRANET_UPC
{
    partial class FrmViewCourses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgVGrades = new System.Windows.Forms.DataGridView();
            this.sectionCourseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC01DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC02DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC03DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.midtermExamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.finalExamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTUDENTCOURSESECTIONBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgVGrades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTUDENTCOURSESECTIONBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgVGrades
            // 
            this.dgVGrades.AllowUserToAddRows = false;
            this.dgVGrades.AllowUserToDeleteRows = false;
            this.dgVGrades.AutoGenerateColumns = false;
            this.dgVGrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVGrades.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sectionCourseDataGridViewTextBoxColumn,
            this.pC01DataGridViewTextBoxColumn,
            this.pC02DataGridViewTextBoxColumn,
            this.pC03DataGridViewTextBoxColumn,
            this.midtermExamDataGridViewTextBoxColumn,
            this.finalExamDataGridViewTextBoxColumn});
            this.dgVGrades.DataSource = this.sTUDENTCOURSESECTIONBindingSource;
            this.dgVGrades.Location = new System.Drawing.Point(12, 12);
            this.dgVGrades.Name = "dgVGrades";
            this.dgVGrades.ReadOnly = true;
            this.dgVGrades.Size = new System.Drawing.Size(693, 338);
            this.dgVGrades.TabIndex = 0;
            // 
            // sectionCourseDataGridViewTextBoxColumn
            // 
            this.sectionCourseDataGridViewTextBoxColumn.DataPropertyName = "SectionCourse";
            this.sectionCourseDataGridViewTextBoxColumn.HeaderText = "Section - Course";
            this.sectionCourseDataGridViewTextBoxColumn.Name = "sectionCourseDataGridViewTextBoxColumn";
            this.sectionCourseDataGridViewTextBoxColumn.ReadOnly = true;
            this.sectionCourseDataGridViewTextBoxColumn.Width = 150;
            // 
            // pC01DataGridViewTextBoxColumn
            // 
            this.pC01DataGridViewTextBoxColumn.DataPropertyName = "PC01";
            this.pC01DataGridViewTextBoxColumn.HeaderText = "PC01";
            this.pC01DataGridViewTextBoxColumn.Name = "pC01DataGridViewTextBoxColumn";
            this.pC01DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pC02DataGridViewTextBoxColumn
            // 
            this.pC02DataGridViewTextBoxColumn.DataPropertyName = "PC02";
            this.pC02DataGridViewTextBoxColumn.HeaderText = "PC02";
            this.pC02DataGridViewTextBoxColumn.Name = "pC02DataGridViewTextBoxColumn";
            this.pC02DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pC03DataGridViewTextBoxColumn
            // 
            this.pC03DataGridViewTextBoxColumn.DataPropertyName = "PC03";
            this.pC03DataGridViewTextBoxColumn.HeaderText = "PC03";
            this.pC03DataGridViewTextBoxColumn.Name = "pC03DataGridViewTextBoxColumn";
            this.pC03DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // midtermExamDataGridViewTextBoxColumn
            // 
            this.midtermExamDataGridViewTextBoxColumn.DataPropertyName = "MidtermExam";
            this.midtermExamDataGridViewTextBoxColumn.HeaderText = "MidtermExam";
            this.midtermExamDataGridViewTextBoxColumn.Name = "midtermExamDataGridViewTextBoxColumn";
            this.midtermExamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // finalExamDataGridViewTextBoxColumn
            // 
            this.finalExamDataGridViewTextBoxColumn.DataPropertyName = "FinalExam";
            this.finalExamDataGridViewTextBoxColumn.HeaderText = "FinalExam";
            this.finalExamDataGridViewTextBoxColumn.Name = "finalExamDataGridViewTextBoxColumn";
            this.finalExamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sTUDENTCOURSESECTIONBindingSource
            // 
            this.sTUDENTCOURSESECTIONBindingSource.DataSource = typeof(ENTITIES.STUDENT__COURSE_SECTION);
            // 
            // FrmViewCourses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 364);
            this.Controls.Add(this.dgVGrades);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmViewCourses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Courses";
            this.Load += new System.EventHandler(this.FrmViewCourses_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgVGrades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTUDENTCOURSESECTIONBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgVGrades;
        private System.Windows.Forms.BindingSource sTUDENTCOURSESECTIONBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionCourseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC01DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC02DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC03DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn midtermExamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn finalExamDataGridViewTextBoxColumn;
    }
}