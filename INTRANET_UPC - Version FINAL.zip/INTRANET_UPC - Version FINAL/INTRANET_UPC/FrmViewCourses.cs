﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.StudentCourseSections;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmViewCourses : Form
    {
        public STUDENT OBJstudent;
        private STUDENT__COURSE_SECTION obj;
        List<STUDENT__COURSE_SECTION> lista;
        IStudentCourseSectionService service = new StudentCourseSectionService();

        public FrmViewCourses()
        {
            InitializeComponent();
        }
        void DataSource_Grades()
        {
            lista = service.GetStudentCourseSectionXStudentID(OBJstudent.ID);
            dgVGrades.DataSource = lista;
        }
        private void FrmViewCourses_Load(object sender, EventArgs e)
        {
            DataSource_Grades();
        }
    }
}
