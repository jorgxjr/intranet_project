﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.Users;
using ENTITIES;
using BusinessLogic.Scores;
using BusinessLogic.StudentCourseSections;
using BusinessLogic.Teachers;
using BusinessLogic.CourseSections;
using BusinessLogic.TeacherCourses;
using BusinessLogic.Students;

namespace INTRANET_UPC
{
    public partial class FrmTeacher : Form
    {
        public TEACHER objTeacher;
        IScoreService servScore = new ScoreService();
        IStudentCourseSectionService servSCS = new StudentCourseSectionService();
        ITeacherService servTeacher = new TeacherService();
        ICourseSectionService servCS = new CourseSectionService();
        ITeacherCourseService servTC = new TeacherCourseService();
        IStudentService serviceStudent = new StudentService();

        List<COURSE_SECTION> sections;
        List<STUDENT__COURSE_SECTION> students;
        public int NumberUser;
        IUserServices serviceUser = new UserServices();
        public FrmTeacher(int userID)
        {
            InitializeComponent();
            servScore = new ScoreService();
            servSCS = new StudentCourseSectionService();
            servTeacher = new TeacherService();
            servCS = new CourseSectionService();
            servTC = new TeacherCourseService();
            objTeacher = servTeacher.GetTeacher(userID);
        }

        private void LoadStudentGrades()
        {
            students = servSCS.GetStudentCourseSectionXTeacherID(objTeacher.ID);
            dgvStudentGrades.DataSource = students;
        }

        private void LoadStudentBySection()
        {
            students = servSCS.GetStudentCourseSectionXcsID(Convert.ToInt32(cbSectionList.SelectedValue));
            dgvStudentsBySection.DataSource = students;
        }

        private void FrmTeacher_Load(object sender, EventArgs e)
        {
            this.Text = "Teacher: " + serviceUser.GetUser(NumberUser).UserName;
            sections = servCS.GetCourseSectionXTeacherID(objTeacher.ID);
            cbSections.DataSource = sections;
            cbSections.SelectedIndex = 0;

            cbSectionList.DataSource = sections;
            cbSectionList.SelectedIndex = 0;

            this.LoadStudentGrades();
        }

        private void cbSections_SelectedIndexChanged(object sender, EventArgs e)
        {
            students = servSCS.GetStudentCourseSectionXcsID(Convert.ToInt32(cbSections.SelectedValue));
            cbStudents.DataSource = students;
        }

        private void btnShowStudents_Click(object sender, EventArgs e)
        {
            this.LoadStudentBySection();
        }

        private void btnRegisterGrades_Click(object sender, EventArgs e)
        {
            try
            {

                SCORE objScore = servSCS.GetStudentCourseSectionXcsID(Convert.ToInt32(cbSections.SelectedValue))[0].SCORE;
                objScore.PC01 = Convert.ToDecimal(txtPC01.Text);
                objScore.PC02 = Convert.ToDecimal(txtPC02.Text);
                objScore.PC03 = Convert.ToDecimal(txtPC03.Text);
                objScore.MidtermExam = Convert.ToDecimal(txtMidterm.Text);
                objScore.FinalExam = Convert.ToDecimal(txtFinal.Text);

                if (objScore.PC01 >= 0 && objScore.PC01 <= 20 &&
                    objScore.PC02 >= 0 && objScore.PC02 <= 20 &&
                    objScore.PC03 >= 0 && objScore.PC03 <= 20 &&
                    objScore.MidtermExam >= 0 && objScore.MidtermExam <= 20 &&
                    objScore.FinalExam >= 0 && objScore.FinalExam <= 20)
                {
                    servScore.UpdateScore(objScore);
                }
                else
                {
                    MessageBox.Show("Only grades between 0 and 20");
                }

                //SCORE lastScore = servScore.GetLastScore();
                //STUDENT__COURSE_SECTION selectedSCS =
                //    servSCS.GetStudentCourseSection(Convert.ToInt32(cbStudents.SelectedValue));
                //servSCS.UpdateStudentCourseSection(selectedSCS.ID, lastScore.ID);
                this.LoadStudentGrades();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(cbStudents.SelectedValue);
                int ID2 = servSCS.GetStudentCourseSection(id).StudentID;
                List<STUDENT__COURSE_SECTION> lista = servSCS.GetStudentCourseSectionXStudentID(ID2);
                txtPC01.Text = lista[0].PC01.ToString();
                txtPC02.Text = lista[0].PC02.ToString();
                txtPC03.Text = lista[0].PC03.ToString();
                txtMidterm.Text = lista[0].MidtermExam.ToString();
                txtFinal.Text = lista[0].FinalExam.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
