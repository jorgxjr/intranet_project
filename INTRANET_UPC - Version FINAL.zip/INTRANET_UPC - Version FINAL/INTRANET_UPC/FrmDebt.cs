﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.Debts;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmDebt : Form
    {
        public STUDENT OBJstudent;
        List<DEBT> lista;
        IDebtService service = new DebService();
        public FrmDebt()
        {
            InitializeComponent();
        }

        void DataSource_Debt()
        {
            lista = service.GetDebt(OBJstudent.ID);
            dgVDebt.DataSource = lista;
        }
        private void FrmDebt_Load(object sender, EventArgs e)
        {
            DataSource_Debt();
        }
    }
}
