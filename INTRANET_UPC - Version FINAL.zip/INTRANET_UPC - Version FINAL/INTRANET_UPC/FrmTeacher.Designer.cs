﻿namespace INTRANET_UPC
{
    partial class FrmTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmTeacher));
            this.tbcTeacher = new System.Windows.Forms.TabControl();
            this.tpGrades = new System.Windows.Forms.TabPage();
            this.gbListGrades = new System.Windows.Forms.GroupBox();
            this.dgvStudentGrades = new System.Windows.Forms.DataGridView();
            this.userNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionCourseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC01DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC02DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC03DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.midtermExamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.finalExamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.careerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseSectionIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scoreIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOURSESECTIONDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sCOREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTUDENTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTUDENTCOURSESECTIONBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gbControls = new System.Windows.Forms.GroupBox();
            this.btnRegisterGrades = new System.Windows.Forms.Button();
            this.tlpGrades = new System.Windows.Forms.TableLayoutPanel();
            this.lblSection = new System.Windows.Forms.Label();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblPC01 = new System.Windows.Forms.Label();
            this.lblPC02 = new System.Windows.Forms.Label();
            this.lblPC03 = new System.Windows.Forms.Label();
            this.lblMidterm = new System.Windows.Forms.Label();
            this.lblFinal = new System.Windows.Forms.Label();
            this.cbSections = new System.Windows.Forms.ComboBox();
            this.cbStudents = new System.Windows.Forms.ComboBox();
            this.txtPC01 = new System.Windows.Forms.TextBox();
            this.txtPC02 = new System.Windows.Forms.TextBox();
            this.txtPC03 = new System.Windows.Forms.TextBox();
            this.txtMidterm = new System.Windows.Forms.TextBox();
            this.txtFinal = new System.Windows.Forms.TextBox();
            this.tpStudentsXSection = new System.Windows.Forms.TabPage();
            this.gbStudentsXSection = new System.Windows.Forms.GroupBox();
            this.dgvStudentsBySection = new System.Windows.Forms.DataGridView();
            this.userNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fullNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DNI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionCourseDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.careerNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC01DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC02DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pC03DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.midtermExamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.finalExamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseSectionIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scoreIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOURSESECTIONDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sCOREDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTUDENTDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tlpSections = new System.Windows.Forms.TableLayoutPanel();
            this.lblSectionList = new System.Windows.Forms.Label();
            this.cbSectionList = new System.Windows.Forms.ComboBox();
            this.btnShowStudents = new System.Windows.Forms.Button();
            this.tbcTeacher.SuspendLayout();
            this.tpGrades.SuspendLayout();
            this.gbListGrades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentGrades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTUDENTCOURSESECTIONBindingSource)).BeginInit();
            this.gbControls.SuspendLayout();
            this.tlpGrades.SuspendLayout();
            this.tpStudentsXSection.SuspendLayout();
            this.gbStudentsXSection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentsBySection)).BeginInit();
            this.tlpSections.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcTeacher
            // 
            this.tbcTeacher.Controls.Add(this.tpGrades);
            this.tbcTeacher.Controls.Add(this.tpStudentsXSection);
            this.tbcTeacher.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcTeacher.Location = new System.Drawing.Point(0, 0);
            this.tbcTeacher.Name = "tbcTeacher";
            this.tbcTeacher.SelectedIndex = 0;
            this.tbcTeacher.Size = new System.Drawing.Size(864, 489);
            this.tbcTeacher.TabIndex = 0;
            // 
            // tpGrades
            // 
            this.tpGrades.Controls.Add(this.gbListGrades);
            this.tpGrades.Controls.Add(this.gbControls);
            this.tpGrades.Controls.Add(this.tlpGrades);
            this.tpGrades.Location = new System.Drawing.Point(4, 22);
            this.tpGrades.Name = "tpGrades";
            this.tpGrades.Padding = new System.Windows.Forms.Padding(3);
            this.tpGrades.Size = new System.Drawing.Size(856, 463);
            this.tpGrades.TabIndex = 0;
            this.tpGrades.Text = "Grades";
            this.tpGrades.UseVisualStyleBackColor = true;
            // 
            // gbListGrades
            // 
            this.gbListGrades.Controls.Add(this.dgvStudentGrades);
            this.gbListGrades.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbListGrades.Location = new System.Drawing.Point(3, 255);
            this.gbListGrades.Name = "gbListGrades";
            this.gbListGrades.Size = new System.Drawing.Size(850, 205);
            this.gbListGrades.TabIndex = 2;
            this.gbListGrades.TabStop = false;
            this.gbListGrades.Text = "All Students";
            // 
            // dgvStudentGrades
            // 
            this.dgvStudentGrades.AllowUserToAddRows = false;
            this.dgvStudentGrades.AllowUserToDeleteRows = false;
            this.dgvStudentGrades.AutoGenerateColumns = false;
            this.dgvStudentGrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudentGrades.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.userNameDataGridViewTextBoxColumn,
            this.fullNameDataGridViewTextBoxColumn,
            this.sectionCourseDataGridViewTextBoxColumn,
            this.pC01DataGridViewTextBoxColumn,
            this.pC02DataGridViewTextBoxColumn,
            this.pC03DataGridViewTextBoxColumn,
            this.midtermExamDataGridViewTextBoxColumn,
            this.finalExamDataGridViewTextBoxColumn,
            this.careerNameDataGridViewTextBoxColumn,
            this.iDDataGridViewTextBoxColumn,
            this.studentIDDataGridViewTextBoxColumn,
            this.courseSectionIDDataGridViewTextBoxColumn,
            this.scoreIDDataGridViewTextBoxColumn,
            this.cOURSESECTIONDataGridViewTextBoxColumn,
            this.sCOREDataGridViewTextBoxColumn,
            this.sTUDENTDataGridViewTextBoxColumn});
            this.dgvStudentGrades.DataSource = this.sTUDENTCOURSESECTIONBindingSource;
            this.dgvStudentGrades.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStudentGrades.Location = new System.Drawing.Point(3, 16);
            this.dgvStudentGrades.Name = "dgvStudentGrades";
            this.dgvStudentGrades.ReadOnly = true;
            this.dgvStudentGrades.Size = new System.Drawing.Size(844, 186);
            this.dgvStudentGrades.TabIndex = 0;
            // 
            // userNameDataGridViewTextBoxColumn
            // 
            this.userNameDataGridViewTextBoxColumn.DataPropertyName = "UserName";
            this.userNameDataGridViewTextBoxColumn.HeaderText = "UserName";
            this.userNameDataGridViewTextBoxColumn.Name = "userNameDataGridViewTextBoxColumn";
            this.userNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fullNameDataGridViewTextBoxColumn
            // 
            this.fullNameDataGridViewTextBoxColumn.DataPropertyName = "FullName";
            this.fullNameDataGridViewTextBoxColumn.HeaderText = "FullName";
            this.fullNameDataGridViewTextBoxColumn.Name = "fullNameDataGridViewTextBoxColumn";
            this.fullNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sectionCourseDataGridViewTextBoxColumn
            // 
            this.sectionCourseDataGridViewTextBoxColumn.DataPropertyName = "SectionCourse";
            this.sectionCourseDataGridViewTextBoxColumn.HeaderText = "SectionCourse";
            this.sectionCourseDataGridViewTextBoxColumn.Name = "sectionCourseDataGridViewTextBoxColumn";
            this.sectionCourseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pC01DataGridViewTextBoxColumn
            // 
            this.pC01DataGridViewTextBoxColumn.DataPropertyName = "PC01";
            this.pC01DataGridViewTextBoxColumn.HeaderText = "PC01";
            this.pC01DataGridViewTextBoxColumn.Name = "pC01DataGridViewTextBoxColumn";
            this.pC01DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pC02DataGridViewTextBoxColumn
            // 
            this.pC02DataGridViewTextBoxColumn.DataPropertyName = "PC02";
            this.pC02DataGridViewTextBoxColumn.HeaderText = "PC02";
            this.pC02DataGridViewTextBoxColumn.Name = "pC02DataGridViewTextBoxColumn";
            this.pC02DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pC03DataGridViewTextBoxColumn
            // 
            this.pC03DataGridViewTextBoxColumn.DataPropertyName = "PC03";
            this.pC03DataGridViewTextBoxColumn.HeaderText = "PC03";
            this.pC03DataGridViewTextBoxColumn.Name = "pC03DataGridViewTextBoxColumn";
            this.pC03DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // midtermExamDataGridViewTextBoxColumn
            // 
            this.midtermExamDataGridViewTextBoxColumn.DataPropertyName = "MidtermExam";
            this.midtermExamDataGridViewTextBoxColumn.HeaderText = "MidtermExam";
            this.midtermExamDataGridViewTextBoxColumn.Name = "midtermExamDataGridViewTextBoxColumn";
            this.midtermExamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // finalExamDataGridViewTextBoxColumn
            // 
            this.finalExamDataGridViewTextBoxColumn.DataPropertyName = "FinalExam";
            this.finalExamDataGridViewTextBoxColumn.HeaderText = "FinalExam";
            this.finalExamDataGridViewTextBoxColumn.Name = "finalExamDataGridViewTextBoxColumn";
            this.finalExamDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // careerNameDataGridViewTextBoxColumn
            // 
            this.careerNameDataGridViewTextBoxColumn.DataPropertyName = "CareerName";
            this.careerNameDataGridViewTextBoxColumn.HeaderText = "CareerName";
            this.careerNameDataGridViewTextBoxColumn.Name = "careerNameDataGridViewTextBoxColumn";
            this.careerNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.careerNameDataGridViewTextBoxColumn.Visible = false;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Visible = false;
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            this.studentIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.studentIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // courseSectionIDDataGridViewTextBoxColumn
            // 
            this.courseSectionIDDataGridViewTextBoxColumn.DataPropertyName = "Course_SectionID";
            this.courseSectionIDDataGridViewTextBoxColumn.HeaderText = "Course_SectionID";
            this.courseSectionIDDataGridViewTextBoxColumn.Name = "courseSectionIDDataGridViewTextBoxColumn";
            this.courseSectionIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.courseSectionIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // scoreIDDataGridViewTextBoxColumn
            // 
            this.scoreIDDataGridViewTextBoxColumn.DataPropertyName = "ScoreID";
            this.scoreIDDataGridViewTextBoxColumn.HeaderText = "ScoreID";
            this.scoreIDDataGridViewTextBoxColumn.Name = "scoreIDDataGridViewTextBoxColumn";
            this.scoreIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.scoreIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // cOURSESECTIONDataGridViewTextBoxColumn
            // 
            this.cOURSESECTIONDataGridViewTextBoxColumn.DataPropertyName = "COURSE_SECTION";
            this.cOURSESECTIONDataGridViewTextBoxColumn.HeaderText = "COURSE_SECTION";
            this.cOURSESECTIONDataGridViewTextBoxColumn.Name = "cOURSESECTIONDataGridViewTextBoxColumn";
            this.cOURSESECTIONDataGridViewTextBoxColumn.ReadOnly = true;
            this.cOURSESECTIONDataGridViewTextBoxColumn.Visible = false;
            // 
            // sCOREDataGridViewTextBoxColumn
            // 
            this.sCOREDataGridViewTextBoxColumn.DataPropertyName = "SCORE";
            this.sCOREDataGridViewTextBoxColumn.HeaderText = "SCORE";
            this.sCOREDataGridViewTextBoxColumn.Name = "sCOREDataGridViewTextBoxColumn";
            this.sCOREDataGridViewTextBoxColumn.ReadOnly = true;
            this.sCOREDataGridViewTextBoxColumn.Visible = false;
            // 
            // sTUDENTDataGridViewTextBoxColumn
            // 
            this.sTUDENTDataGridViewTextBoxColumn.DataPropertyName = "STUDENT";
            this.sTUDENTDataGridViewTextBoxColumn.HeaderText = "STUDENT";
            this.sTUDENTDataGridViewTextBoxColumn.Name = "sTUDENTDataGridViewTextBoxColumn";
            this.sTUDENTDataGridViewTextBoxColumn.ReadOnly = true;
            this.sTUDENTDataGridViewTextBoxColumn.Visible = false;
            // 
            // sTUDENTCOURSESECTIONBindingSource
            // 
            this.sTUDENTCOURSESECTIONBindingSource.DataSource = typeof(ENTITIES.STUDENT__COURSE_SECTION);
            // 
            // gbControls
            // 
            this.gbControls.Controls.Add(this.btnRegisterGrades);
            this.gbControls.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbControls.Location = new System.Drawing.Point(3, 190);
            this.gbControls.Name = "gbControls";
            this.gbControls.Size = new System.Drawing.Size(850, 65);
            this.gbControls.TabIndex = 1;
            this.gbControls.TabStop = false;
            // 
            // btnRegisterGrades
            // 
            this.btnRegisterGrades.Location = new System.Drawing.Point(353, 19);
            this.btnRegisterGrades.Name = "btnRegisterGrades";
            this.btnRegisterGrades.Size = new System.Drawing.Size(106, 34);
            this.btnRegisterGrades.TabIndex = 0;
            this.btnRegisterGrades.Text = "Register Grades";
            this.btnRegisterGrades.UseVisualStyleBackColor = true;
            this.btnRegisterGrades.Click += new System.EventHandler(this.btnRegisterGrades_Click);
            // 
            // tlpGrades
            // 
            this.tlpGrades.ColumnCount = 2;
            this.tlpGrades.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.09417F));
            this.tlpGrades.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 76.90583F));
            this.tlpGrades.Controls.Add(this.lblSection, 0, 0);
            this.tlpGrades.Controls.Add(this.lblStudent, 0, 1);
            this.tlpGrades.Controls.Add(this.lblPC01, 0, 2);
            this.tlpGrades.Controls.Add(this.lblPC02, 0, 3);
            this.tlpGrades.Controls.Add(this.lblPC03, 0, 4);
            this.tlpGrades.Controls.Add(this.lblMidterm, 0, 5);
            this.tlpGrades.Controls.Add(this.lblFinal, 0, 6);
            this.tlpGrades.Controls.Add(this.cbSections, 1, 0);
            this.tlpGrades.Controls.Add(this.cbStudents, 1, 1);
            this.tlpGrades.Controls.Add(this.txtPC01, 1, 2);
            this.tlpGrades.Controls.Add(this.txtPC02, 1, 3);
            this.tlpGrades.Controls.Add(this.txtPC03, 1, 4);
            this.tlpGrades.Controls.Add(this.txtMidterm, 1, 5);
            this.tlpGrades.Controls.Add(this.txtFinal, 1, 6);
            this.tlpGrades.Dock = System.Windows.Forms.DockStyle.Top;
            this.tlpGrades.Location = new System.Drawing.Point(3, 3);
            this.tlpGrades.Name = "tlpGrades";
            this.tlpGrades.RowCount = 7;
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tlpGrades.Size = new System.Drawing.Size(850, 187);
            this.tlpGrades.TabIndex = 0;
            // 
            // lblSection
            // 
            this.lblSection.AutoSize = true;
            this.lblSection.Location = new System.Drawing.Point(3, 0);
            this.lblSection.Name = "lblSection";
            this.lblSection.Size = new System.Drawing.Size(43, 13);
            this.lblSection.TabIndex = 0;
            this.lblSection.Text = "Section";
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Location = new System.Drawing.Point(3, 26);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(44, 13);
            this.lblStudent.TabIndex = 1;
            this.lblStudent.Text = "Student";
            // 
            // lblPC01
            // 
            this.lblPC01.AutoSize = true;
            this.lblPC01.Location = new System.Drawing.Point(3, 52);
            this.lblPC01.Name = "lblPC01";
            this.lblPC01.Size = new System.Drawing.Size(33, 13);
            this.lblPC01.TabIndex = 2;
            this.lblPC01.Text = "PC01";
            // 
            // lblPC02
            // 
            this.lblPC02.AutoSize = true;
            this.lblPC02.Location = new System.Drawing.Point(3, 78);
            this.lblPC02.Name = "lblPC02";
            this.lblPC02.Size = new System.Drawing.Size(33, 13);
            this.lblPC02.TabIndex = 3;
            this.lblPC02.Text = "PC02";
            // 
            // lblPC03
            // 
            this.lblPC03.AutoSize = true;
            this.lblPC03.Location = new System.Drawing.Point(3, 104);
            this.lblPC03.Name = "lblPC03";
            this.lblPC03.Size = new System.Drawing.Size(33, 13);
            this.lblPC03.TabIndex = 4;
            this.lblPC03.Text = "PC03";
            // 
            // lblMidterm
            // 
            this.lblMidterm.AutoSize = true;
            this.lblMidterm.Location = new System.Drawing.Point(3, 130);
            this.lblMidterm.Name = "lblMidterm";
            this.lblMidterm.Size = new System.Drawing.Size(44, 13);
            this.lblMidterm.TabIndex = 5;
            this.lblMidterm.Text = "Midterm";
            // 
            // lblFinal
            // 
            this.lblFinal.AutoSize = true;
            this.lblFinal.Location = new System.Drawing.Point(3, 156);
            this.lblFinal.Name = "lblFinal";
            this.lblFinal.Size = new System.Drawing.Size(29, 13);
            this.lblFinal.TabIndex = 6;
            this.lblFinal.Text = "Final";
            // 
            // cbSections
            // 
            this.cbSections.DisplayMember = "CourseSection";
            this.cbSections.FormattingEnabled = true;
            this.cbSections.Location = new System.Drawing.Point(199, 3);
            this.cbSections.Name = "cbSections";
            this.cbSections.Size = new System.Drawing.Size(190, 21);
            this.cbSections.TabIndex = 7;
            this.cbSections.ValueMember = "ID";
            this.cbSections.SelectedIndexChanged += new System.EventHandler(this.cbSections_SelectedIndexChanged);
            // 
            // cbStudents
            // 
            this.cbStudents.DisplayMember = "FullName";
            this.cbStudents.FormattingEnabled = true;
            this.cbStudents.Location = new System.Drawing.Point(199, 29);
            this.cbStudents.Name = "cbStudents";
            this.cbStudents.Size = new System.Drawing.Size(190, 21);
            this.cbStudents.TabIndex = 8;
            this.cbStudents.ValueMember = "ID";
            this.cbStudents.SelectedIndexChanged += new System.EventHandler(this.cbStudents_SelectedIndexChanged);
            // 
            // txtPC01
            // 
            this.txtPC01.Location = new System.Drawing.Point(199, 55);
            this.txtPC01.Name = "txtPC01";
            this.txtPC01.Size = new System.Drawing.Size(190, 20);
            this.txtPC01.TabIndex = 9;
            // 
            // txtPC02
            // 
            this.txtPC02.Location = new System.Drawing.Point(199, 81);
            this.txtPC02.Name = "txtPC02";
            this.txtPC02.Size = new System.Drawing.Size(190, 20);
            this.txtPC02.TabIndex = 10;
            // 
            // txtPC03
            // 
            this.txtPC03.Location = new System.Drawing.Point(199, 107);
            this.txtPC03.Name = "txtPC03";
            this.txtPC03.Size = new System.Drawing.Size(190, 20);
            this.txtPC03.TabIndex = 11;
            // 
            // txtMidterm
            // 
            this.txtMidterm.Location = new System.Drawing.Point(199, 133);
            this.txtMidterm.Name = "txtMidterm";
            this.txtMidterm.Size = new System.Drawing.Size(190, 20);
            this.txtMidterm.TabIndex = 12;
            // 
            // txtFinal
            // 
            this.txtFinal.Location = new System.Drawing.Point(199, 159);
            this.txtFinal.Name = "txtFinal";
            this.txtFinal.Size = new System.Drawing.Size(190, 20);
            this.txtFinal.TabIndex = 13;
            // 
            // tpStudentsXSection
            // 
            this.tpStudentsXSection.Controls.Add(this.gbStudentsXSection);
            this.tpStudentsXSection.Controls.Add(this.tlpSections);
            this.tpStudentsXSection.Location = new System.Drawing.Point(4, 22);
            this.tpStudentsXSection.Name = "tpStudentsXSection";
            this.tpStudentsXSection.Padding = new System.Windows.Forms.Padding(3);
            this.tpStudentsXSection.Size = new System.Drawing.Size(856, 463);
            this.tpStudentsXSection.TabIndex = 1;
            this.tpStudentsXSection.Text = "Sections";
            this.tpStudentsXSection.UseVisualStyleBackColor = true;
            // 
            // gbStudentsXSection
            // 
            this.gbStudentsXSection.Controls.Add(this.dgvStudentsBySection);
            this.gbStudentsXSection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbStudentsXSection.Location = new System.Drawing.Point(3, 103);
            this.gbStudentsXSection.Name = "gbStudentsXSection";
            this.gbStudentsXSection.Size = new System.Drawing.Size(850, 357);
            this.gbStudentsXSection.TabIndex = 1;
            this.gbStudentsXSection.TabStop = false;
            this.gbStudentsXSection.Text = "Students";
            // 
            // dgvStudentsBySection
            // 
            this.dgvStudentsBySection.AllowUserToAddRows = false;
            this.dgvStudentsBySection.AllowUserToDeleteRows = false;
            this.dgvStudentsBySection.AutoGenerateColumns = false;
            this.dgvStudentsBySection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudentsBySection.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.userNameDataGridViewTextBoxColumn1,
            this.fullNameDataGridViewTextBoxColumn1,
            this.DNI,
            this.sectionCourseDataGridViewTextBoxColumn1,
            this.careerNameDataGridViewTextBoxColumn1,
            this.pC01DataGridViewTextBoxColumn1,
            this.pC02DataGridViewTextBoxColumn1,
            this.pC03DataGridViewTextBoxColumn1,
            this.midtermExamDataGridViewTextBoxColumn1,
            this.finalExamDataGridViewTextBoxColumn1,
            this.iDDataGridViewTextBoxColumn1,
            this.studentIDDataGridViewTextBoxColumn1,
            this.courseSectionIDDataGridViewTextBoxColumn1,
            this.scoreIDDataGridViewTextBoxColumn1,
            this.cOURSESECTIONDataGridViewTextBoxColumn1,
            this.sCOREDataGridViewTextBoxColumn1,
            this.sTUDENTDataGridViewTextBoxColumn1});
            this.dgvStudentsBySection.DataSource = this.sTUDENTCOURSESECTIONBindingSource;
            this.dgvStudentsBySection.Location = new System.Drawing.Point(213, 14);
            this.dgvStudentsBySection.Name = "dgvStudentsBySection";
            this.dgvStudentsBySection.ReadOnly = true;
            this.dgvStudentsBySection.Size = new System.Drawing.Size(445, 338);
            this.dgvStudentsBySection.TabIndex = 0;
            // 
            // userNameDataGridViewTextBoxColumn1
            // 
            this.userNameDataGridViewTextBoxColumn1.DataPropertyName = "UserName";
            this.userNameDataGridViewTextBoxColumn1.HeaderText = "UserName";
            this.userNameDataGridViewTextBoxColumn1.Name = "userNameDataGridViewTextBoxColumn1";
            this.userNameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // fullNameDataGridViewTextBoxColumn1
            // 
            this.fullNameDataGridViewTextBoxColumn1.DataPropertyName = "FullName";
            this.fullNameDataGridViewTextBoxColumn1.HeaderText = "FullName";
            this.fullNameDataGridViewTextBoxColumn1.Name = "fullNameDataGridViewTextBoxColumn1";
            this.fullNameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // DNI
            // 
            this.DNI.DataPropertyName = "DNI";
            this.DNI.HeaderText = "DNI";
            this.DNI.Name = "DNI";
            this.DNI.ReadOnly = true;
            // 
            // sectionCourseDataGridViewTextBoxColumn1
            // 
            this.sectionCourseDataGridViewTextBoxColumn1.DataPropertyName = "SectionCourse";
            this.sectionCourseDataGridViewTextBoxColumn1.HeaderText = "SectionCourse";
            this.sectionCourseDataGridViewTextBoxColumn1.Name = "sectionCourseDataGridViewTextBoxColumn1";
            this.sectionCourseDataGridViewTextBoxColumn1.ReadOnly = true;
            this.sectionCourseDataGridViewTextBoxColumn1.Visible = false;
            // 
            // careerNameDataGridViewTextBoxColumn1
            // 
            this.careerNameDataGridViewTextBoxColumn1.DataPropertyName = "CareerName";
            this.careerNameDataGridViewTextBoxColumn1.HeaderText = "CareerName";
            this.careerNameDataGridViewTextBoxColumn1.Name = "careerNameDataGridViewTextBoxColumn1";
            this.careerNameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pC01DataGridViewTextBoxColumn1
            // 
            this.pC01DataGridViewTextBoxColumn1.DataPropertyName = "PC01";
            this.pC01DataGridViewTextBoxColumn1.HeaderText = "PC01";
            this.pC01DataGridViewTextBoxColumn1.Name = "pC01DataGridViewTextBoxColumn1";
            this.pC01DataGridViewTextBoxColumn1.ReadOnly = true;
            this.pC01DataGridViewTextBoxColumn1.Visible = false;
            // 
            // pC02DataGridViewTextBoxColumn1
            // 
            this.pC02DataGridViewTextBoxColumn1.DataPropertyName = "PC02";
            this.pC02DataGridViewTextBoxColumn1.HeaderText = "PC02";
            this.pC02DataGridViewTextBoxColumn1.Name = "pC02DataGridViewTextBoxColumn1";
            this.pC02DataGridViewTextBoxColumn1.ReadOnly = true;
            this.pC02DataGridViewTextBoxColumn1.Visible = false;
            // 
            // pC03DataGridViewTextBoxColumn1
            // 
            this.pC03DataGridViewTextBoxColumn1.DataPropertyName = "PC03";
            this.pC03DataGridViewTextBoxColumn1.HeaderText = "PC03";
            this.pC03DataGridViewTextBoxColumn1.Name = "pC03DataGridViewTextBoxColumn1";
            this.pC03DataGridViewTextBoxColumn1.ReadOnly = true;
            this.pC03DataGridViewTextBoxColumn1.Visible = false;
            // 
            // midtermExamDataGridViewTextBoxColumn1
            // 
            this.midtermExamDataGridViewTextBoxColumn1.DataPropertyName = "MidtermExam";
            this.midtermExamDataGridViewTextBoxColumn1.HeaderText = "MidtermExam";
            this.midtermExamDataGridViewTextBoxColumn1.Name = "midtermExamDataGridViewTextBoxColumn1";
            this.midtermExamDataGridViewTextBoxColumn1.ReadOnly = true;
            this.midtermExamDataGridViewTextBoxColumn1.Visible = false;
            // 
            // finalExamDataGridViewTextBoxColumn1
            // 
            this.finalExamDataGridViewTextBoxColumn1.DataPropertyName = "FinalExam";
            this.finalExamDataGridViewTextBoxColumn1.HeaderText = "FinalExam";
            this.finalExamDataGridViewTextBoxColumn1.Name = "finalExamDataGridViewTextBoxColumn1";
            this.finalExamDataGridViewTextBoxColumn1.ReadOnly = true;
            this.finalExamDataGridViewTextBoxColumn1.Visible = false;
            // 
            // iDDataGridViewTextBoxColumn1
            // 
            this.iDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn1.Name = "iDDataGridViewTextBoxColumn1";
            this.iDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn1.Visible = false;
            // 
            // studentIDDataGridViewTextBoxColumn1
            // 
            this.studentIDDataGridViewTextBoxColumn1.DataPropertyName = "StudentID";
            this.studentIDDataGridViewTextBoxColumn1.HeaderText = "StudentID";
            this.studentIDDataGridViewTextBoxColumn1.Name = "studentIDDataGridViewTextBoxColumn1";
            this.studentIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.studentIDDataGridViewTextBoxColumn1.Visible = false;
            // 
            // courseSectionIDDataGridViewTextBoxColumn1
            // 
            this.courseSectionIDDataGridViewTextBoxColumn1.DataPropertyName = "Course_SectionID";
            this.courseSectionIDDataGridViewTextBoxColumn1.HeaderText = "Course_SectionID";
            this.courseSectionIDDataGridViewTextBoxColumn1.Name = "courseSectionIDDataGridViewTextBoxColumn1";
            this.courseSectionIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.courseSectionIDDataGridViewTextBoxColumn1.Visible = false;
            // 
            // scoreIDDataGridViewTextBoxColumn1
            // 
            this.scoreIDDataGridViewTextBoxColumn1.DataPropertyName = "ScoreID";
            this.scoreIDDataGridViewTextBoxColumn1.HeaderText = "ScoreID";
            this.scoreIDDataGridViewTextBoxColumn1.Name = "scoreIDDataGridViewTextBoxColumn1";
            this.scoreIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.scoreIDDataGridViewTextBoxColumn1.Visible = false;
            // 
            // cOURSESECTIONDataGridViewTextBoxColumn1
            // 
            this.cOURSESECTIONDataGridViewTextBoxColumn1.DataPropertyName = "COURSE_SECTION";
            this.cOURSESECTIONDataGridViewTextBoxColumn1.HeaderText = "COURSE_SECTION";
            this.cOURSESECTIONDataGridViewTextBoxColumn1.Name = "cOURSESECTIONDataGridViewTextBoxColumn1";
            this.cOURSESECTIONDataGridViewTextBoxColumn1.ReadOnly = true;
            this.cOURSESECTIONDataGridViewTextBoxColumn1.Visible = false;
            // 
            // sCOREDataGridViewTextBoxColumn1
            // 
            this.sCOREDataGridViewTextBoxColumn1.DataPropertyName = "SCORE";
            this.sCOREDataGridViewTextBoxColumn1.HeaderText = "SCORE";
            this.sCOREDataGridViewTextBoxColumn1.Name = "sCOREDataGridViewTextBoxColumn1";
            this.sCOREDataGridViewTextBoxColumn1.ReadOnly = true;
            this.sCOREDataGridViewTextBoxColumn1.Visible = false;
            // 
            // sTUDENTDataGridViewTextBoxColumn1
            // 
            this.sTUDENTDataGridViewTextBoxColumn1.DataPropertyName = "STUDENT";
            this.sTUDENTDataGridViewTextBoxColumn1.HeaderText = "STUDENT";
            this.sTUDENTDataGridViewTextBoxColumn1.Name = "sTUDENTDataGridViewTextBoxColumn1";
            this.sTUDENTDataGridViewTextBoxColumn1.ReadOnly = true;
            this.sTUDENTDataGridViewTextBoxColumn1.Visible = false;
            // 
            // tlpSections
            // 
            this.tlpSections.ColumnCount = 2;
            this.tlpSections.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.25112F));
            this.tlpSections.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.74888F));
            this.tlpSections.Controls.Add(this.lblSectionList, 0, 0);
            this.tlpSections.Controls.Add(this.cbSectionList, 1, 0);
            this.tlpSections.Controls.Add(this.btnShowStudents, 1, 1);
            this.tlpSections.Dock = System.Windows.Forms.DockStyle.Top;
            this.tlpSections.Location = new System.Drawing.Point(3, 3);
            this.tlpSections.Name = "tlpSections";
            this.tlpSections.RowCount = 2;
            this.tlpSections.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSections.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSections.Size = new System.Drawing.Size(850, 100);
            this.tlpSections.TabIndex = 0;
            // 
            // lblSectionList
            // 
            this.lblSectionList.AutoSize = true;
            this.lblSectionList.Location = new System.Drawing.Point(3, 0);
            this.lblSectionList.Name = "lblSectionList";
            this.lblSectionList.Size = new System.Drawing.Size(43, 13);
            this.lblSectionList.TabIndex = 0;
            this.lblSectionList.Text = "Section";
            // 
            // cbSectionList
            // 
            this.cbSectionList.DisplayMember = "CourseSection";
            this.cbSectionList.FormattingEnabled = true;
            this.cbSectionList.Location = new System.Drawing.Point(243, 3);
            this.cbSectionList.Name = "cbSectionList";
            this.cbSectionList.Size = new System.Drawing.Size(233, 21);
            this.cbSectionList.TabIndex = 1;
            this.cbSectionList.ValueMember = "ID";
            // 
            // btnShowStudents
            // 
            this.btnShowStudents.Location = new System.Drawing.Point(243, 53);
            this.btnShowStudents.Name = "btnShowStudents";
            this.btnShowStudents.Size = new System.Drawing.Size(110, 27);
            this.btnShowStudents.TabIndex = 2;
            this.btnShowStudents.Text = "Show Students";
            this.btnShowStudents.UseVisualStyleBackColor = true;
            this.btnShowStudents.Click += new System.EventHandler(this.btnShowStudents_Click);
            // 
            // FrmTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 489);
            this.Controls.Add(this.tbcTeacher);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmTeacher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teacher";
            this.Load += new System.EventHandler(this.FrmTeacher_Load);
            this.tbcTeacher.ResumeLayout(false);
            this.tpGrades.ResumeLayout(false);
            this.gbListGrades.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentGrades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTUDENTCOURSESECTIONBindingSource)).EndInit();
            this.gbControls.ResumeLayout(false);
            this.tlpGrades.ResumeLayout(false);
            this.tlpGrades.PerformLayout();
            this.tpStudentsXSection.ResumeLayout(false);
            this.gbStudentsXSection.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentsBySection)).EndInit();
            this.tlpSections.ResumeLayout(false);
            this.tlpSections.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcTeacher;
        private System.Windows.Forms.TabPage tpGrades;
        private System.Windows.Forms.TabPage tpStudentsXSection;
        private System.Windows.Forms.TableLayoutPanel tlpGrades;
        private System.Windows.Forms.GroupBox gbControls;
        private System.Windows.Forms.Button btnRegisterGrades;
        private System.Windows.Forms.GroupBox gbListGrades;
        private System.Windows.Forms.DataGridView dgvStudentGrades;
        private System.Windows.Forms.Label lblSection;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblPC01;
        private System.Windows.Forms.Label lblPC02;
        private System.Windows.Forms.Label lblPC03;
        private System.Windows.Forms.Label lblMidterm;
        private System.Windows.Forms.Label lblFinal;
        private System.Windows.Forms.ComboBox cbSections;
        private System.Windows.Forms.ComboBox cbStudents;
        private System.Windows.Forms.TextBox txtPC01;
        private System.Windows.Forms.TextBox txtPC02;
        private System.Windows.Forms.TextBox txtPC03;
        private System.Windows.Forms.TextBox txtMidterm;
        private System.Windows.Forms.TextBox txtFinal;
        private System.Windows.Forms.GroupBox gbStudentsXSection;
        private System.Windows.Forms.DataGridView dgvStudentsBySection;
        private System.Windows.Forms.TableLayoutPanel tlpSections;
        private System.Windows.Forms.Label lblSectionList;
        private System.Windows.Forms.ComboBox cbSectionList;
        private System.Windows.Forms.Button btnShowStudents;
        private System.Windows.Forms.BindingSource sTUDENTCOURSESECTIONBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionCourseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC01DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC02DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC03DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn midtermExamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn finalExamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn careerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseSectionIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn scoreIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOURSESECTIONDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sCOREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTUDENTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn fullNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DNI;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionCourseDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn careerNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC01DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC02DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pC03DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn midtermExamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn finalExamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseSectionIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn scoreIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOURSESECTIONDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sCOREDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTUDENTDataGridViewTextBoxColumn1;
    }
}