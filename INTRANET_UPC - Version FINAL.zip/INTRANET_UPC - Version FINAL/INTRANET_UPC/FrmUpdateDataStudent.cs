﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.Users;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmUpdateDataStudent : Form
    {
        public STUDENT OBJstudent;
        private IUserServices service = new UserServices();
        public int UserID;

        public FrmUpdateDataStudent()
        {
            InitializeComponent();
        }

        private void FrmUpdateDataStudent_Load(object sender, EventArgs e)
        {
            rbtnMale.Checked = false;
            rbtnFemale.Checked = false;

            USER user = service.GetUser(UserID);
            txtName.Text = user.Name;
            txtLastName.Text = user.LastName;
            txtBithDay.Text = user.DateOfBirth;
            if (user.Gender == "Male")
            {
                rbtnMale.Checked = true;
            }
            else
            {
                rbtnFemale.Checked = true;
            }
            txtUserName.Text = user.UserName;
            txtPassword.Text = user.Pasword;
            txtDni.Text = user.DNI.ToString();
            txtCareer.Text = OBJstudent.CAREER.Name;
            if(OBJstudent.Foreigner)
            {
                cbxForeigner.Checked = true;
            }
            else
            {
                cbxForeigner.Checked = false;
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://contactoweb.upc.edu.pe/");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text != "")
            {
                USER user = service.GetUser(UserID);
                user.Pasword = txtPassword.Text;
                service.UpdateUser(user);
                MessageBox.Show("The Update : Succesful");
            }
            else
            {
                MessageBox.Show("It's not posible to save empty password");
            }
        }
    }
}
