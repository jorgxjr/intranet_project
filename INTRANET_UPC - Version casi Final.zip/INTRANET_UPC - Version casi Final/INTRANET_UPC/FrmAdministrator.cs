﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.Administrators;
using BusinessLogic.Areas;
using BusinessLogic.Carrers;
using BusinessLogic.Courses;
using BusinessLogic.CourseSections;
using BusinessLogic.Debts;
using BusinessLogic.Sections;
using BusinessLogic.Students;
using BusinessLogic.TeacherCourses;
using BusinessLogic.Teachers;
using BusinessLogic.Users;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmAdministrator : Form
    {
        public ADMINISTRATOR OBJAdministrator;
        public int NumberUser;
        List<COURSE> listaCourse;
        List<AREA> listaArea;
        List<CAREER> listacarrer;
        List<ADMINISTRATOR> listaAdministrator;
        List<TEACHER> listaTeacher;
        List<STUDENT> listaStudent;
        List<USER> listaUser;
        List<DEBT> listaDebt;
        List<SECTION> listaSection;
        List<TECHER_COURSE> listaTeacherCourse;
        List<COURSE_SECTION> listaCourseSection;

        ICourseService courseService = new CourseService();
        ICarrerService carrerService = new CarrerService();
        IAreaService areaService = new AreaService();
        IUserServices serviceUser = new UserServices();
        IAdministratorService serviceAdministrator = new AdministratorService();
        ITeacherService serviceTeacher = new TeacherService();
        IStudentService serviceStudent = new StudentService();
        IDebtService serviceDebt = new DebService();
        ISectionService serviceSection = new SectionService();
        ITeacherCourseService serviceTeacherCourse = new TeacherCourseService();
        ICourseSectionService serviceCourseSection = new CourseSectionService();
        AREA areaDeleteOrUpdate = null;
        COURSE courseDeleteOrUpdate = null;

        //constructor
        public FrmAdministrator()
        {
            InitializeComponent();
        }

        //LOAD
        private void FrmAdministrator_Load(object sender, EventArgs e)
        {

            this.Text = "Administrator: " + serviceUser.GetUser(NumberUser).UserName;

            listaArea = areaService.GetArea();
            listacarrer = carrerService.GetCarrer();
            listaUser = serviceUser.GetUser();
            listaDebt = serviceDebt.GetDebt();
            listaStudent = serviceStudent.GetStudent();
            listaSection = serviceSection.GetSection();
            listaTeacherCourse = serviceTeacherCourse.GetTeacherCourse();
            listaCourseSection = serviceCourseSection.GetCourseSection();

            DataSource_Course();
            DataSource_Area();
            DataSource_Administrator();
            DataSource_Student();
            DataSource_Teacher();
            DataSource_User();
            DataSource_Carrer();
            DataSource_Debt();
            DataSource_Section();
            DataSource_TeacherCourse();
            DataSource_CourseSection();

            cbxArea.DataSource = listaArea;
            cbxCarrer.DataSource = listacarrer;
            cbxUserNameAdmin.DataSource = listaUser;
            cbxUserNameStudent.DataSource = listaUser;
            cbxUserNameTeacher.DataSource = listaUser;
            cbxCarrer.DataSource = listacarrer;
            rbtnFemale.Checked = true;
            cbxStudentNameDebt.DataSource = listaStudent;
            cbxCourse.DataSource = courseService.GetCourse();
            cbxTeacher.DataSource = serviceTeacher.GetTeacher();
            cbxEnableCourse.DataSource = courseService.GetCourse();
            cbxEnableSection.DataSource = serviceSection.GetSection();
        }


        /////////////////////////////////////////////////////////////////////
        //////////////// AREA
        ////////////////////////////////////////////////////////////////////

        //carga de datos de la grilla de area
        void DataSource_Area()
        {
            listaArea = areaService.GetArea();
            dGVArea.DataSource = listaArea;
        }


        //limpiar datos de area
        void Clear_data_Area()
        {
            txtAreaDescription.Clear();
            txtAreaDescription.Focus();
        }


        //cargar datos de area de la grilla seleccionada de area
        void load_Area(AREA obj)
        {
            txtAreaDescription.Text = Convert.ToString(obj.Description);
        }
        //guardar cambios en area
        void save_area(AREA obj)
        {
            obj.Description = txtAreaDescription.Text;
        }


        //determinar objeto seleccionado en la grilla
        private void dGVArea_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dGVArea.Columns[e.ColumnIndex].HeaderText.ToLower() == "select")
            {
                areaDeleteOrUpdate = (AREA)dGVArea.Rows[e.RowIndex].DataBoundItem;
                load_Area(areaDeleteOrUpdate);
            }
        }

        //agregar area
        private void btnAreaAdd_Click(object sender, EventArgs e)
        {
            areaDeleteOrUpdate = null;
            AREA objArea = new AREA();
            save_area(objArea);
            bool flag = areaService.CreateArea(objArea);
            if (flag)
            {
                DataSource_Area();
                cbxArea.DataSource = listaArea;
            }
            else
            {
                MessageBox.Show("It is not possible to save repeated data or empty data");
            }
            Clear_data_Area();
        }

        //eliminar area
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (areaDeleteOrUpdate != null)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    bool flag = areaService.DeleteArea(areaDeleteOrUpdate.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Area();
                    cbxArea.DataSource = listaArea;
                    areaDeleteOrUpdate = null;
                }
                Clear_data_Area();
            }
            else
            {
                MessageBox.Show("It is not possible to delete empty data. Select a data");
            }
        }

        //actualizar area
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (areaDeleteOrUpdate != null)
            {
                if (MessageBox.Show("Are you sure you want to update this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    save_area(areaDeleteOrUpdate);
                    bool flag = areaService.UpdateArea(areaDeleteOrUpdate);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to update this record");
                    }
                    DataSource_Area();
                    cbxArea.DataSource = listaArea;
                    areaDeleteOrUpdate = null;
                }
                Clear_data_Area();
            }
            else
            {
                MessageBox.Show("It is not possible to update empty data. Select a data");
            }
        }


        /////////////////////////////////////////////////////////////////////
        //////////////// CURSOS
        ////////////////////////////////////////////////////////////////////

        //carga de datos de la grilla de cursos
        void DataSource_Course()
        {
            listaCourse = courseService.GetCourse();
            dGVCourse.DataSource = listaCourse;
        }
        //limpiar datos de curso
        void Clear_data_Course()
        {
            txtCourseName.Clear();
            txtCredits.Clear();
            cbxObligatory.Checked = false;
            courseDeleteOrUpdate = null;
        }

        //cargar datos de area de la grilla seleccionada de cursos
        void load_Course(COURSE obj)
        {
            txtCourseName.Text = obj.Name;
            txtCredits.Text = Convert.ToString(obj.Credit);
            cbxObligatory.Checked = obj.Obligatory;
            cbxArea.SelectedValue = obj.AreaID;
        }

        //guardar cambios en area
        void save_Course(COURSE obj)
        {
            try
            {
                obj.Name = txtCourseName.Text;
                obj.Credit = Convert.ToInt32(txtCredits.Text);
                obj.Obligatory = cbxObligatory.Checked;
                obj.AreaID = Convert.ToInt32(cbxArea.SelectedValue);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                obj = null;
            }
        }


        // determinar objeto seleccionado de la grilla
        private void dGVCourse_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dGVCourse.Columns[e.ColumnIndex].HeaderText.ToLower() == "select")
            {
                courseDeleteOrUpdate = (COURSE)dGVCourse.Rows[e.RowIndex].DataBoundItem;
                load_Course(courseDeleteOrUpdate);
            }
        }

        //agregar curso
        private void btnCourseAdd_Click(object sender, EventArgs e)
        {
            courseDeleteOrUpdate = null;
            COURSE objCourse = new COURSE();
            save_Course(objCourse);

            bool flag = courseService.CreateCourse(objCourse);
            if (flag)
            {
                DataSource_Course();
            }
            else
            {
                MessageBox.Show("It is not possible to save repeated data or empty data");
            }
            Clear_data_Course();
            cbxCourse.DataSource = courseService.GetCourse();
            cbxEnableCourse.DataSource = courseService.GetCourse();
        }

        private void btnCourseUpdate_Click(object sender, EventArgs e)
        {
            if (courseDeleteOrUpdate != null)
            {
                if (MessageBox.Show("Are you sure you want to update this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    save_Course(courseDeleteOrUpdate);
                    bool flag = courseService.UpdateCourse(courseDeleteOrUpdate);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to update this record");
                    }
                    DataSource_Course();
                }
                Clear_data_Course();
                courseDeleteOrUpdate = null;
            }
            else
            {
                MessageBox.Show("It is not possible to update empty data. Select a data");
            }
        }

        private void btnCourseDelete_Click(object sender, EventArgs e)
        {
            if (courseDeleteOrUpdate != null)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    bool flag = courseService.DeleteCourse(courseDeleteOrUpdate.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Course();
                }
                Clear_data_Course();
                courseDeleteOrUpdate = null;
                cbxEnableCourse.DataSource = courseService.GetCourse();
            }
            else
            {
                MessageBox.Show("It is not possible to delete empty data. Select a data");
            }
        }


        /////////////////////////////////////////////////////////////////////
        //////////////// USERS
        ////////////////////////////////////////////////////////////////////
        //carga de datos de la grilla de cursos
        void DataSource_Administrator()
        {
            listaAdministrator = serviceAdministrator.GetAdministrator();
            dGVAdministrators.DataSource = listaAdministrator;
        }
        void DataSource_Teacher()
        {
            listaTeacher = serviceTeacher.GetTeacher();
            dGVTeacher.DataSource = listaTeacher;
        }
        void DataSource_Student()
        {
            listaStudent = serviceStudent.GetStudent();
            dgVStudent.DataSource = listaStudent;
        }
        void DataSource_User()
        {
            listaUser = serviceUser.GetUser();
            dgVUser.DataSource = listaUser;
        }


        void Clear_data_User()
        {
            txtName.Clear();
            txtLastName.Clear();
            txtUserName.Clear();
            txtPassword.Clear();
            txtDni.Clear();
            rbtnFemale.Checked = true;
            rbtnMale.Checked = false;

            //courseDeleteOrUpdate = null;
        }

        void Clear_data_Administrator()
        {
            txtWokArea.Clear();

            //courseDeleteOrUpdate = null;
        }
        void Clear_data_Student()
        {
            txtMaximumCredits.Clear();
            cbxForeigner.Checked = false;

            //courseDeleteOrUpdate = null;
        }
        void Clear_data_Teacher()
        {
            txtProfession.Clear();
            txtUniversityDegrees.Clear();

            //courseDeleteOrUpdate = null;
        }

        void save_User(USER obj)
        {
            try
            {
                obj.Name = txtName.Text;
                obj.LastName = txtLastName.Text;
                obj.UserName = txtUserName.Text;
                obj.Pasword = txtPassword.Text;
                obj.DNI = Convert.ToInt32(txtDni.Text);
                if (rbtnMale.Checked)
                {
                    obj.Gender = "Male";
                }
                else if (rbtnFemale.Checked)
                {
                    obj.Gender = "Female";
                }
                obj.DateOfBirth = dTPDateOfBirth.Value.ToString("dd/mm/yy");
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                obj = null;
            }
        }

        void save_Administrator(ADMINISTRATOR obj)
        {
            obj.UserID = Convert.ToInt32(cbxUserNameAdmin.SelectedValue);
            obj.WorkArea = txtWokArea.Text;
        }

        void save_Student(STUDENT obj)
        {
            try
            {
                obj.UserID = Convert.ToInt32(cbxUserNameStudent.SelectedValue);
                obj.CarrerID = Convert.ToInt32(cbxCarrer.SelectedValue);
                obj.MaximumCredits = Convert.ToInt32(txtMaximumCredits.Text);
                obj.Foreigner = cbxForeigner.Checked;
            }
            catch (Exception e)
            {
                obj = null;
                MessageBox.Show(e.Message);

            }
        }
        void save_Teacher(TEACHER obj)
        {
            obj.UserID = Convert.ToInt32(cbxUserNameTeacher.SelectedValue);
            obj.Profession = txtProfession.Text;
            obj.UniversityDegrees = txtUniversityDegrees.Text;
        }

        private void dGVTeacher_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dGVTeacher.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    TEACHER obj = (TEACHER)dGVTeacher.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceTeacher.DeleteTeacher(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Teacher();
                }
            }

        }

        private void dGVAdministrators_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dGVAdministrators.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    ADMINISTRATOR obj = (ADMINISTRATOR)dGVAdministrators.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceAdministrator.DeleteAdministrator(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Administrator();
                }
            }
        }

        private void dgVStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVStudent.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    STUDENT obj = (STUDENT)dgVStudent.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceStudent.DeleteStudent(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Student();
                    cbxStudentNameDebt.DataSource = serviceStudent.GetStudent();
                }
            }
        }
        private void btnAdministratorAdd_Click(object sender, EventArgs e)
        {
            ADMINISTRATOR obj = new ADMINISTRATOR();
            save_Administrator(obj);
            bool flag = serviceAdministrator.CreateAdministrator(obj);
            if (!flag)
            {
                MessageBox.Show("Could not save the data");
            }
            Clear_data_Administrator();
            DataSource_Administrator();
        }

        private void btnTeacherAdd_Click(object sender, EventArgs e)
        {
            TEACHER obj = new TEACHER();
            save_Teacher(obj);
            bool flag = serviceTeacher.CreateTeacher(obj);
            if (!flag)
            {
                MessageBox.Show("Could not save the data");
            }
            Clear_data_Teacher();
            DataSource_Teacher();
            cbxTeacher.DataSource = serviceTeacher.GetTeacher();
        }

        private void btnStudentADD_Click(object sender, EventArgs e)
        {
            STUDENT obj = new STUDENT();
            save_Student(obj);

            bool flag = serviceStudent.CreateStudent(obj);
            if (!flag)
            {
                MessageBox.Show("Could not save the data");
            }
            Clear_data_Student();
            DataSource_Student();
            cbxStudentNameDebt.DataSource = serviceStudent.GetStudent();
        }


        private void btnUserAdd_Click_1(object sender, EventArgs e)
        {
            USER obj = new USER();
            save_User(obj);
            if (obj != null)
            {
                serviceUser.CreateUser(obj);
                DataSource_User();
                Clear_data_User();
                cbxUserNameAdmin.DataSource = serviceUser.GetUser();
                cbxUserNameTeacher.DataSource = serviceUser.GetUser();
                cbxUserNameStudent.DataSource = serviceUser.GetUser();
            }
        }

        private void dgVUser_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVUser.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    USER obj = (USER)dgVUser.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceUser.DeleteUser(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_User();
                    cbxUserNameAdmin.DataSource = listaUser;
                    cbxUserNameStudent.DataSource = listaUser;
                    cbxUserNameTeacher.DataSource = listaUser;
                }
            }
        }

        /// <summary>
        /// / CARRER
        private void DataSource_Carrer()
        {
            listacarrer = carrerService.GetCarrer();
            dgVCarrer.DataSource = listacarrer;
        }
        private void btnCarrerAdd_Click(object sender, EventArgs e)
        {
            CAREER obj = new CAREER();
            obj.Name = txtCarrerName.Text;
            bool flag = carrerService.CreateCarrer(obj);
            if (!flag)
            {
                MessageBox.Show("It is not possible to save empty data");
            }
            DataSource_Carrer();
            txtCarrerName.Clear();
            cbxCarrer.DataSource = carrerService.GetCarrer();
        }

        private void dgVCarrer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVCarrer.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    CAREER obj = (CAREER)dgVCarrer.Rows[e.RowIndex].DataBoundItem;
                    bool flag = carrerService.DeleteCarrer(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Carrer();
                    cbxCarrer.DataSource = carrerService.GetCarrer();
                }
            }
        }

        /// <summary>
        /// debt
        void Clear_data_Debt()
        {
            txtReason.Clear();
            txtQuantity.Clear();
        }

        void DataSource_Debt()
        {
            listaDebt = serviceDebt.GetDebt();
            dgVDebs.DataSource = listaDebt;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DEBT obj = new DEBT();
            try
            {
                obj.Quantity = Convert.ToDecimal(txtQuantity.Text);
                obj.StudentID = Convert.ToInt32(cbxStudentNameDebt.SelectedValue);
                obj.Reason = txtReason.Text;
                bool flag = serviceDebt.CreateDebt(obj);
            }
            catch (Exception ex)
            {
                MessageBox.Show("It is not possible to save this record");
            }
            DataSource_Debt();
            Clear_data_Debt();
        }

        private void dgVDebs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVDebs.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DEBT obj = (DEBT)dgVDebs.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceDebt.DeleteDebt(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Debt();
                }
            }
        }

        //Section 
        private void DataSource_Section()
        {
            listaSection = serviceSection.GetSection();
            dgVSection.DataSource = listaSection;
        }
        private void btnSectionAdd_Click(object sender, EventArgs e)
        {
            SECTION obj = new SECTION();
            obj.SectionName = txtSectionName.Text;
            bool flag = serviceSection.CreateSection(obj);
            if (!flag)
            {
                MessageBox.Show("It's not posible to save this data");
            }
            DataSource_Section();
            txtSectionName.Clear();
            cbxEnableSection.DataSource = serviceSection.GetSection();
        }

        private void dgVSection_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVSection.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    SECTION obj = (SECTION)dgVSection.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceSection.DeleteSection(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_Section();
                }
            }
        }


        private void DataSource_TeacherCourse()
        {
            listaTeacherCourse = serviceTeacherCourse.GetTeacherCourse();
            dgVCourseTeacher.DataSource = listaTeacherCourse;
        }
        private void btnCourseSectionAdd_Click(object sender, EventArgs e)
        {
            TECHER_COURSE obj = new TECHER_COURSE();
            obj.TeacherID = Convert.ToInt32(cbxTeacher.SelectedValue);
            obj.CourseID = Convert.ToInt32(cbxCourse.SelectedValue);
            bool flag = serviceTeacherCourse.CreateTeacherCourse(obj);
            DataSource_TeacherCourse();
        }

        private void dgVCourseTeacher_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVCourseTeacher.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    TECHER_COURSE obj = (TECHER_COURSE)dgVCourseTeacher.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceTeacherCourse.DeleteTeacherCourse(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_TeacherCourse();
                }
            }
        }

        private void cbxEnableCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(cbxEnableCourse.SelectedValue);
            cbxEnableTeacher.DataSource = serviceTeacherCourse.TeachersXCourse(id);
        }


        private void DataSource_CourseSection()
        {
            listaCourseSection = serviceCourseSection.GetCourseSection();
            dgVCourseSection.DataSource = listaCourseSection;
        }


        private void dgVCourseSection_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgVCourseSection.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    COURSE_SECTION obj = (COURSE_SECTION)dgVCourseSection.Rows[e.RowIndex].DataBoundItem;
                    bool flag = serviceCourseSection.DeleteCourseSection(obj.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to delete this record");
                    }
                    DataSource_CourseSection();

                }
            }
        }
        void Clear_data_CourseSection()
        {
            txtHourStart.Clear();
            txtHourEnd.Clear();
            txtVacancesAvailable.Clear();
            txtClasroomName.Clear();
            txtDay.Clear();
        }

        void save_CourseSection(COURSE_SECTION obj)
        {
            try
            {
                int courseID = Convert.ToInt32(cbxEnableCourse.SelectedValue);
                int teacherID = Convert.ToInt32(cbxEnableTeacher.SelectedValue);

                obj.SectionID = Convert.ToInt32(cbxEnableSection.SelectedValue);
                obj.HourEnd = Convert.ToInt32(txtHourEnd.Text);
                obj.HourStart = Convert.ToInt32(txtHourStart.Text);
                obj.VacanciesAvailable = Convert.ToInt32(txtVacancesAvailable.Text);
                obj.ClasroomName = txtClasroomName.Text;
                obj.Day = txtDay.Text;
                obj.Teacher_CourseID = serviceTeacherCourse.GetTeacherCourseByIDs(teacherID, courseID).ID;
            }
            catch (Exception e)
            {
                obj = null;
                MessageBox.Show(e.Message);

            }
        }

        private void btnEneableSection_Click(object sender, EventArgs e)
        {
            COURSE_SECTION obj = new COURSE_SECTION();
            save_CourseSection(obj);
            bool flag = serviceCourseSection.CreateCourseSection(obj);
            if (!flag)
            {
                MessageBox.Show("It is not possible to save this record");
            }
            Clear_data_CourseSection();
            DataSource_CourseSection();
        }
    }
}