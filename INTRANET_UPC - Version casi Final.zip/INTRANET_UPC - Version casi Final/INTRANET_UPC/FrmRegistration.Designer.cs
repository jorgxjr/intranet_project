﻿namespace INTRANET_UPC
{
    partial class FrmRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgVResgistration = new System.Windows.Forms.DataGridView();
            this.cOURSESECTIONBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SectionName2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.horarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Registration = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Deregister = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgVResgistration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSESECTIONBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgVResgistration
            // 
            this.dgVResgistration.AllowUserToAddRows = false;
            this.dgVResgistration.AllowUserToDeleteRows = false;
            this.dgVResgistration.AutoGenerateColumns = false;
            this.dgVResgistration.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVResgistration.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.courseDataGridViewTextBoxColumn,
            this.SectionName2,
            this.teacherDataGridViewTextBoxColumn,
            this.horarioDataGridViewTextBoxColumn,
            this.Registration,
            this.Deregister});
            this.dgVResgistration.DataSource = this.cOURSESECTIONBindingSource;
            this.dgVResgistration.Location = new System.Drawing.Point(12, 12);
            this.dgVResgistration.Name = "dgVResgistration";
            this.dgVResgistration.ReadOnly = true;
            this.dgVResgistration.Size = new System.Drawing.Size(644, 471);
            this.dgVResgistration.TabIndex = 0;
            this.dgVResgistration.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVResgistration_CellContentClick);
            // 
            // cOURSESECTIONBindingSource
            // 
            this.cOURSESECTIONBindingSource.DataSource = typeof(ENTITIES.COURSE_SECTION);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // courseDataGridViewTextBoxColumn
            // 
            this.courseDataGridViewTextBoxColumn.DataPropertyName = "course";
            this.courseDataGridViewTextBoxColumn.HeaderText = "Course";
            this.courseDataGridViewTextBoxColumn.Name = "courseDataGridViewTextBoxColumn";
            this.courseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // SectionName2
            // 
            this.SectionName2.DataPropertyName = "SectionName2";
            this.SectionName2.HeaderText = "Section";
            this.SectionName2.Name = "SectionName2";
            this.SectionName2.ReadOnly = true;
            // 
            // teacherDataGridViewTextBoxColumn
            // 
            this.teacherDataGridViewTextBoxColumn.DataPropertyName = "teacher";
            this.teacherDataGridViewTextBoxColumn.HeaderText = "Teacher";
            this.teacherDataGridViewTextBoxColumn.Name = "teacherDataGridViewTextBoxColumn";
            this.teacherDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // horarioDataGridViewTextBoxColumn
            // 
            this.horarioDataGridViewTextBoxColumn.DataPropertyName = "Horario";
            this.horarioDataGridViewTextBoxColumn.HeaderText = "Horario";
            this.horarioDataGridViewTextBoxColumn.Name = "horarioDataGridViewTextBoxColumn";
            this.horarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Registration
            // 
            this.Registration.HeaderText = "Registration";
            this.Registration.Name = "Registration";
            this.Registration.ReadOnly = true;
            this.Registration.Text = "Registration";
            this.Registration.UseColumnTextForButtonValue = true;
            // 
            // Deregister
            // 
            this.Deregister.HeaderText = "Deregister";
            this.Deregister.Name = "Deregister";
            this.Deregister.ReadOnly = true;
            this.Deregister.Text = "Deregister";
            this.Deregister.UseColumnTextForButtonValue = true;
            // 
            // FrmRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 488);
            this.Controls.Add(this.dgVResgistration);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmRegistration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration";
            this.Load += new System.EventHandler(this.FrmRegistration_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgVResgistration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSESECTIONBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgVResgistration;
        private System.Windows.Forms.BindingSource cOURSESECTIONBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SectionName2;
        private System.Windows.Forms.DataGridViewTextBoxColumn teacherDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn horarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Registration;
        private System.Windows.Forms.DataGridViewButtonColumn Deregister;
    }
}