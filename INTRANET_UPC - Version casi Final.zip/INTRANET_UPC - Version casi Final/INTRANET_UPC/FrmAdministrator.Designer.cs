﻿namespace INTRANET_UPC
{
    partial class FrmAdministrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tab1 = new System.Windows.Forms.TabControl();
            this.tabUsers = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabAdministrators = new System.Windows.Forms.TabPage();
            this.cbxUserNameAdmin = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dGVAdministrators = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workAreaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSERDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.daybirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dniDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteAdministrator = new System.Windows.Forms.DataGridViewButtonColumn();
            this.aDMINISTRATORBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnAdministratorAdd = new System.Windows.Forms.Button();
            this.txtWokArea = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabTeachers = new System.Windows.Forms.TabPage();
            this.cbxUserNameTeacher = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dGVTeacher = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.professionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.universityDegreesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.daybirthDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dniDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteTeacher = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tEACHERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnTeacherAdd = new System.Windows.Forms.Button();
            this.txtUniversityDegrees = new System.Windows.Forms.TextBox();
            this.txtProfession = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabStudents = new System.Windows.Forms.TabPage();
            this.cbxUserNameStudent = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dgVStudent = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carrerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maximumCreditsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foreignerDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.nameDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastnameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.daybirthDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dniDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carrerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteStudent = new System.Windows.Forms.DataGridViewButtonColumn();
            this.sTUDENTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnStudentADD = new System.Windows.Forms.Button();
            this.cbxForeigner = new System.Windows.Forms.CheckBox();
            this.cbxCarrer = new System.Windows.Forms.ComboBox();
            this.txtMaximumCredits = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabCourses = new System.Windows.Forms.TabPage();
            this.dGVCourse = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CourseArea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obligatoryDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.creditDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectCourse = new System.Windows.Forms.DataGridViewButtonColumn();
            this.cOURSEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnCourseUpdate = new System.Windows.Forms.Button();
            this.btnCourseDelete = new System.Windows.Forms.Button();
            this.btnCourseAdd = new System.Windows.Forms.Button();
            this.cbxArea = new System.Windows.Forms.ComboBox();
            this.cbxObligatory = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCredits = new System.Windows.Forms.TextBox();
            this.txtCourseName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabArea = new System.Windows.Forms.TabPage();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dGVArea = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SelectArea = new System.Windows.Forms.DataGridViewButtonColumn();
            this.aREABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnAreaAdd = new System.Windows.Forms.Button();
            this.txtAreaDescription = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnUserAdd = new System.Windows.Forms.Button();
            this.dgVUser = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOfBirthDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userNameDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dNIDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paswordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.uSERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.dTPDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.txtDni = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgVCarrer = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteCarrer = new System.Windows.Forms.DataGridViewButtonColumn();
            this.cAREERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnCarrerAdd = new System.Windows.Forms.Button();
            this.txtCarrerName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtReason = new System.Windows.Forms.RichTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cbxStudentNameDebt = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dgVDebs = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reasonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteDebt = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dEBTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cbxTeacher = new System.Windows.Forms.ComboBox();
            this.cbxCourse = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.dgVCourseTeacher = new System.Windows.Forms.DataGridView();
            this.teacherIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.courseNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tECHERCOURSEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnCourseSectionAdd = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgVSection = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteSection = new System.Windows.Forms.DataGridViewButtonColumn();
            this.sECTIONBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnSectionAdd = new System.Windows.Forms.Button();
            this.txtSectionName = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dgVCourseSection = new System.Windows.Forms.DataGridView();
            this.cOURSESECTIONBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtDay = new System.Windows.Forms.TextBox();
            this.txtClasroomName = new System.Windows.Forms.TextBox();
            this.txtVacancesAvailable = new System.Windows.Forms.TextBox();
            this.txtHourEnd = new System.Windows.Forms.TextBox();
            this.txtHourStart = new System.Windows.Forms.TextBox();
            this.cbxEnableTeacher = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cbxEnableCourse = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.btnEneableSection = new System.Windows.Forms.Button();
            this.cbxEnableSection = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.aREABindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.courseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SectionName2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hourStartDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hourEndDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vacanciesAvailableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clasroomNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteCourseSection = new System.Windows.Forms.DataGridViewButtonColumn();
            this.iDDataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherCourseIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab1.SuspendLayout();
            this.tabUsers.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabAdministrators.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVAdministrators)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aDMINISTRATORBindingSource)).BeginInit();
            this.tabTeachers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVTeacher)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tEACHERBindingSource)).BeginInit();
            this.tabStudents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVStudent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTUDENTBindingSource)).BeginInit();
            this.tabCourses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVCourse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSEBindingSource)).BeginInit();
            this.tabArea.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVCarrer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAREERBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVDebs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBTBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVCourseTeacher)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tECHERCOURSEBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVSection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sECTIONBindingSource)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVCourseSection)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSESECTIONBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tab1
            // 
            this.tab1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tab1.Controls.Add(this.tabUsers);
            this.tab1.Controls.Add(this.tabCourses);
            this.tab1.Controls.Add(this.tabArea);
            this.tab1.Controls.Add(this.tabPage1);
            this.tab1.Controls.Add(this.tabPage2);
            this.tab1.Controls.Add(this.tabPage3);
            this.tab1.Controls.Add(this.tabPage4);
            this.tab1.Controls.Add(this.tabPage5);
            this.tab1.Location = new System.Drawing.Point(7, 19);
            this.tab1.Name = "tab1";
            this.tab1.SelectedIndex = 0;
            this.tab1.Size = new System.Drawing.Size(1090, 612);
            this.tab1.TabIndex = 1;
            // 
            // tabUsers
            // 
            this.tabUsers.Controls.Add(this.groupBox2);
            this.tabUsers.Location = new System.Drawing.Point(4, 22);
            this.tabUsers.Name = "tabUsers";
            this.tabUsers.Padding = new System.Windows.Forms.Padding(3);
            this.tabUsers.Size = new System.Drawing.Size(1082, 586);
            this.tabUsers.TabIndex = 2;
            this.tabUsers.Text = "Administrators, Teachers and Students";
            this.tabUsers.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1075, 574);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Types of Users";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabAdministrators);
            this.tabControl1.Controls.Add(this.tabTeachers);
            this.tabControl1.Controls.Add(this.tabStudents);
            this.tabControl1.Location = new System.Drawing.Point(6, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1063, 549);
            this.tabControl1.TabIndex = 0;
            // 
            // tabAdministrators
            // 
            this.tabAdministrators.Controls.Add(this.cbxUserNameAdmin);
            this.tabAdministrators.Controls.Add(this.label11);
            this.tabAdministrators.Controls.Add(this.dGVAdministrators);
            this.tabAdministrators.Controls.Add(this.btnAdministratorAdd);
            this.tabAdministrators.Controls.Add(this.txtWokArea);
            this.tabAdministrators.Controls.Add(this.label1);
            this.tabAdministrators.Location = new System.Drawing.Point(4, 22);
            this.tabAdministrators.Name = "tabAdministrators";
            this.tabAdministrators.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdministrators.Size = new System.Drawing.Size(1055, 523);
            this.tabAdministrators.TabIndex = 0;
            this.tabAdministrators.Text = "Administrators";
            this.tabAdministrators.UseVisualStyleBackColor = true;
            // 
            // cbxUserNameAdmin
            // 
            this.cbxUserNameAdmin.DisplayMember = "UserName";
            this.cbxUserNameAdmin.FormattingEnabled = true;
            this.cbxUserNameAdmin.Location = new System.Drawing.Point(507, 20);
            this.cbxUserNameAdmin.Name = "cbxUserNameAdmin";
            this.cbxUserNameAdmin.Size = new System.Drawing.Size(199, 21);
            this.cbxUserNameAdmin.TabIndex = 43;
            this.cbxUserNameAdmin.ValueMember = "ID";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(424, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 42;
            this.label11.Text = "User Name";
            // 
            // dGVAdministrators
            // 
            this.dGVAdministrators.AllowUserToAddRows = false;
            this.dGVAdministrators.AllowUserToDeleteRows = false;
            this.dGVAdministrators.AutoGenerateColumns = false;
            this.dGVAdministrators.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVAdministrators.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn2,
            this.userIDDataGridViewTextBoxColumn,
            this.workAreaDataGridViewTextBoxColumn,
            this.uSERDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn1,
            this.lastnameDataGridViewTextBoxColumn,
            this.daybirthDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn,
            this.dniDataGridViewTextBoxColumn,
            this.DeleteAdministrator});
            this.dGVAdministrators.DataSource = this.aDMINISTRATORBindingSource;
            this.dGVAdministrators.Location = new System.Drawing.Point(100, 86);
            this.dGVAdministrators.Name = "dGVAdministrators";
            this.dGVAdministrators.ReadOnly = true;
            this.dGVAdministrators.Size = new System.Drawing.Size(846, 431);
            this.dGVAdministrators.TabIndex = 31;
            this.dGVAdministrators.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGVAdministrators_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn2
            // 
            this.iDDataGridViewTextBoxColumn2.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn2.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn2.Name = "iDDataGridViewTextBoxColumn2";
            this.iDDataGridViewTextBoxColumn2.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn2.Visible = false;
            // 
            // userIDDataGridViewTextBoxColumn
            // 
            this.userIDDataGridViewTextBoxColumn.DataPropertyName = "UserID";
            this.userIDDataGridViewTextBoxColumn.HeaderText = "UserID";
            this.userIDDataGridViewTextBoxColumn.Name = "userIDDataGridViewTextBoxColumn";
            this.userIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.userIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // workAreaDataGridViewTextBoxColumn
            // 
            this.workAreaDataGridViewTextBoxColumn.DataPropertyName = "WorkArea";
            this.workAreaDataGridViewTextBoxColumn.HeaderText = "WorkArea";
            this.workAreaDataGridViewTextBoxColumn.Name = "workAreaDataGridViewTextBoxColumn";
            this.workAreaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // uSERDataGridViewTextBoxColumn
            // 
            this.uSERDataGridViewTextBoxColumn.DataPropertyName = "USER";
            this.uSERDataGridViewTextBoxColumn.HeaderText = "USER";
            this.uSERDataGridViewTextBoxColumn.Name = "uSERDataGridViewTextBoxColumn";
            this.uSERDataGridViewTextBoxColumn.ReadOnly = true;
            this.uSERDataGridViewTextBoxColumn.Visible = false;
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            this.nameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // lastnameDataGridViewTextBoxColumn
            // 
            this.lastnameDataGridViewTextBoxColumn.DataPropertyName = "lastname";
            this.lastnameDataGridViewTextBoxColumn.HeaderText = "lastname";
            this.lastnameDataGridViewTextBoxColumn.Name = "lastnameDataGridViewTextBoxColumn";
            this.lastnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // daybirthDataGridViewTextBoxColumn
            // 
            this.daybirthDataGridViewTextBoxColumn.DataPropertyName = "daybirth";
            this.daybirthDataGridViewTextBoxColumn.HeaderText = "day of birth";
            this.daybirthDataGridViewTextBoxColumn.Name = "daybirthDataGridViewTextBoxColumn";
            this.daybirthDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            this.genderDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dniDataGridViewTextBoxColumn
            // 
            this.dniDataGridViewTextBoxColumn.DataPropertyName = "dni";
            this.dniDataGridViewTextBoxColumn.HeaderText = "dni";
            this.dniDataGridViewTextBoxColumn.Name = "dniDataGridViewTextBoxColumn";
            this.dniDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // DeleteAdministrator
            // 
            this.DeleteAdministrator.HeaderText = "Delete";
            this.DeleteAdministrator.Name = "DeleteAdministrator";
            this.DeleteAdministrator.ReadOnly = true;
            // 
            // aDMINISTRATORBindingSource
            // 
            this.aDMINISTRATORBindingSource.DataSource = typeof(ENTITIES.ADMINISTRATOR);
            // 
            // btnAdministratorAdd
            // 
            this.btnAdministratorAdd.Location = new System.Drawing.Point(753, 20);
            this.btnAdministratorAdd.Name = "btnAdministratorAdd";
            this.btnAdministratorAdd.Size = new System.Drawing.Size(72, 25);
            this.btnAdministratorAdd.TabIndex = 28;
            this.btnAdministratorAdd.Text = "Add";
            this.btnAdministratorAdd.UseVisualStyleBackColor = true;
            this.btnAdministratorAdd.Click += new System.EventHandler(this.btnAdministratorAdd_Click);
            // 
            // txtWokArea
            // 
            this.txtWokArea.Location = new System.Drawing.Point(180, 19);
            this.txtWokArea.Name = "txtWokArea";
            this.txtWokArea.Size = new System.Drawing.Size(199, 20);
            this.txtWokArea.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Work Area";
            // 
            // tabTeachers
            // 
            this.tabTeachers.Controls.Add(this.cbxUserNameTeacher);
            this.tabTeachers.Controls.Add(this.label10);
            this.tabTeachers.Controls.Add(this.dGVTeacher);
            this.tabTeachers.Controls.Add(this.btnTeacherAdd);
            this.tabTeachers.Controls.Add(this.txtUniversityDegrees);
            this.tabTeachers.Controls.Add(this.txtProfession);
            this.tabTeachers.Controls.Add(this.label2);
            this.tabTeachers.Controls.Add(this.label3);
            this.tabTeachers.Location = new System.Drawing.Point(4, 22);
            this.tabTeachers.Name = "tabTeachers";
            this.tabTeachers.Padding = new System.Windows.Forms.Padding(3);
            this.tabTeachers.Size = new System.Drawing.Size(1055, 523);
            this.tabTeachers.TabIndex = 1;
            this.tabTeachers.Text = "Teachers";
            this.tabTeachers.UseVisualStyleBackColor = true;
            // 
            // cbxUserNameTeacher
            // 
            this.cbxUserNameTeacher.DisplayMember = "UserName";
            this.cbxUserNameTeacher.FormattingEnabled = true;
            this.cbxUserNameTeacher.Location = new System.Drawing.Point(803, 19);
            this.cbxUserNameTeacher.Name = "cbxUserNameTeacher";
            this.cbxUserNameTeacher.Size = new System.Drawing.Size(199, 21);
            this.cbxUserNameTeacher.TabIndex = 43;
            this.cbxUserNameTeacher.ValueMember = "ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(720, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 42;
            this.label10.Text = "User Name";
            // 
            // dGVTeacher
            // 
            this.dGVTeacher.AllowUserToAddRows = false;
            this.dGVTeacher.AllowUserToDeleteRows = false;
            this.dGVTeacher.AutoGenerateColumns = false;
            this.dGVTeacher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVTeacher.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn3,
            this.professionDataGridViewTextBoxColumn,
            this.universityDegreesDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn2,
            this.lastnameDataGridViewTextBoxColumn1,
            this.daybirthDataGridViewTextBoxColumn1,
            this.genderDataGridViewTextBoxColumn1,
            this.usernameDataGridViewTextBoxColumn1,
            this.dniDataGridViewTextBoxColumn1,
            this.userIDDataGridViewTextBoxColumn1,
            this.DeleteTeacher});
            this.dGVTeacher.DataSource = this.tEACHERBindingSource;
            this.dGVTeacher.Location = new System.Drawing.Point(6, 93);
            this.dGVTeacher.Name = "dGVTeacher";
            this.dGVTeacher.ReadOnly = true;
            this.dGVTeacher.Size = new System.Drawing.Size(1043, 424);
            this.dGVTeacher.TabIndex = 35;
            this.dGVTeacher.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGVTeacher_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn3
            // 
            this.iDDataGridViewTextBoxColumn3.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn3.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn3.Name = "iDDataGridViewTextBoxColumn3";
            this.iDDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // professionDataGridViewTextBoxColumn
            // 
            this.professionDataGridViewTextBoxColumn.DataPropertyName = "Profession";
            this.professionDataGridViewTextBoxColumn.HeaderText = "Profession";
            this.professionDataGridViewTextBoxColumn.Name = "professionDataGridViewTextBoxColumn";
            this.professionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // universityDegreesDataGridViewTextBoxColumn
            // 
            this.universityDegreesDataGridViewTextBoxColumn.DataPropertyName = "UniversityDegrees";
            this.universityDegreesDataGridViewTextBoxColumn.HeaderText = "UniversityDegrees";
            this.universityDegreesDataGridViewTextBoxColumn.Name = "universityDegreesDataGridViewTextBoxColumn";
            this.universityDegreesDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn2
            // 
            this.nameDataGridViewTextBoxColumn2.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn2.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn2.Name = "nameDataGridViewTextBoxColumn2";
            this.nameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // lastnameDataGridViewTextBoxColumn1
            // 
            this.lastnameDataGridViewTextBoxColumn1.DataPropertyName = "lastname";
            this.lastnameDataGridViewTextBoxColumn1.HeaderText = "lastname";
            this.lastnameDataGridViewTextBoxColumn1.Name = "lastnameDataGridViewTextBoxColumn1";
            this.lastnameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // daybirthDataGridViewTextBoxColumn1
            // 
            this.daybirthDataGridViewTextBoxColumn1.DataPropertyName = "daybirth";
            this.daybirthDataGridViewTextBoxColumn1.HeaderText = "day of birth";
            this.daybirthDataGridViewTextBoxColumn1.Name = "daybirthDataGridViewTextBoxColumn1";
            this.daybirthDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // genderDataGridViewTextBoxColumn1
            // 
            this.genderDataGridViewTextBoxColumn1.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn1.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn1.Name = "genderDataGridViewTextBoxColumn1";
            this.genderDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // usernameDataGridViewTextBoxColumn1
            // 
            this.usernameDataGridViewTextBoxColumn1.DataPropertyName = "username";
            this.usernameDataGridViewTextBoxColumn1.HeaderText = "username";
            this.usernameDataGridViewTextBoxColumn1.Name = "usernameDataGridViewTextBoxColumn1";
            this.usernameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dniDataGridViewTextBoxColumn1
            // 
            this.dniDataGridViewTextBoxColumn1.DataPropertyName = "dni";
            this.dniDataGridViewTextBoxColumn1.HeaderText = "dni";
            this.dniDataGridViewTextBoxColumn1.Name = "dniDataGridViewTextBoxColumn1";
            this.dniDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // userIDDataGridViewTextBoxColumn1
            // 
            this.userIDDataGridViewTextBoxColumn1.DataPropertyName = "UserID";
            this.userIDDataGridViewTextBoxColumn1.HeaderText = "UserID";
            this.userIDDataGridViewTextBoxColumn1.Name = "userIDDataGridViewTextBoxColumn1";
            this.userIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.userIDDataGridViewTextBoxColumn1.Visible = false;
            // 
            // DeleteTeacher
            // 
            this.DeleteTeacher.HeaderText = "Delete";
            this.DeleteTeacher.Name = "DeleteTeacher";
            this.DeleteTeacher.ReadOnly = true;
            // 
            // tEACHERBindingSource
            // 
            this.tEACHERBindingSource.DataSource = typeof(ENTITIES.TEACHER);
            // 
            // btnTeacherAdd
            // 
            this.btnTeacherAdd.Location = new System.Drawing.Point(930, 62);
            this.btnTeacherAdd.Name = "btnTeacherAdd";
            this.btnTeacherAdd.Size = new System.Drawing.Size(72, 25);
            this.btnTeacherAdd.TabIndex = 32;
            this.btnTeacherAdd.Text = "Add";
            this.btnTeacherAdd.UseVisualStyleBackColor = true;
            this.btnTeacherAdd.Click += new System.EventHandler(this.btnTeacherAdd_Click);
            // 
            // txtUniversityDegrees
            // 
            this.txtUniversityDegrees.Location = new System.Drawing.Point(469, 19);
            this.txtUniversityDegrees.Name = "txtUniversityDegrees";
            this.txtUniversityDegrees.Size = new System.Drawing.Size(199, 20);
            this.txtUniversityDegrees.TabIndex = 31;
            // 
            // txtProfession
            // 
            this.txtProfession.Location = new System.Drawing.Point(134, 19);
            this.txtProfession.Name = "txtProfession";
            this.txtProfession.Size = new System.Drawing.Size(199, 20);
            this.txtProfession.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(367, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "University Degrees";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Profession";
            // 
            // tabStudents
            // 
            this.tabStudents.Controls.Add(this.cbxUserNameStudent);
            this.tabStudents.Controls.Add(this.label9);
            this.tabStudents.Controls.Add(this.dgVStudent);
            this.tabStudents.Controls.Add(this.btnStudentADD);
            this.tabStudents.Controls.Add(this.cbxForeigner);
            this.tabStudents.Controls.Add(this.cbxCarrer);
            this.tabStudents.Controls.Add(this.txtMaximumCredits);
            this.tabStudents.Controls.Add(this.label7);
            this.tabStudents.Controls.Add(this.label4);
            this.tabStudents.Controls.Add(this.label5);
            this.tabStudents.Location = new System.Drawing.Point(4, 22);
            this.tabStudents.Name = "tabStudents";
            this.tabStudents.Padding = new System.Windows.Forms.Padding(3);
            this.tabStudents.Size = new System.Drawing.Size(1055, 523);
            this.tabStudents.TabIndex = 2;
            this.tabStudents.Text = "Students";
            this.tabStudents.UseVisualStyleBackColor = true;
            // 
            // cbxUserNameStudent
            // 
            this.cbxUserNameStudent.DisplayMember = "UserName";
            this.cbxUserNameStudent.FormattingEnabled = true;
            this.cbxUserNameStudent.Location = new System.Drawing.Point(99, 61);
            this.cbxUserNameStudent.Name = "cbxUserNameStudent";
            this.cbxUserNameStudent.Size = new System.Drawing.Size(199, 21);
            this.cbxUserNameStudent.TabIndex = 41;
            this.cbxUserNameStudent.ValueMember = "ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "User Name";
            // 
            // dgVStudent
            // 
            this.dgVStudent.AllowUserToAddRows = false;
            this.dgVStudent.AllowUserToDeleteRows = false;
            this.dgVStudent.AutoGenerateColumns = false;
            this.dgVStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVStudent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.carrerDataGridViewTextBoxColumn,
            this.maximumCreditsDataGridViewTextBoxColumn,
            this.foreignerDataGridViewCheckBoxColumn,
            this.nameDataGridViewTextBoxColumn3,
            this.lastnameDataGridViewTextBoxColumn2,
            this.daybirthDataGridViewTextBoxColumn2,
            this.genderDataGridViewTextBoxColumn2,
            this.usernameDataGridViewTextBoxColumn2,
            this.dniDataGridViewTextBoxColumn2,
            this.iDDataGridViewTextBoxColumn4,
            this.carrerIDDataGridViewTextBoxColumn,
            this.userIDDataGridViewTextBoxColumn2,
            this.DeleteStudent});
            this.dgVStudent.DataSource = this.sTUDENTBindingSource;
            this.dgVStudent.Location = new System.Drawing.Point(6, 113);
            this.dgVStudent.Name = "dgVStudent";
            this.dgVStudent.ReadOnly = true;
            this.dgVStudent.Size = new System.Drawing.Size(1044, 404);
            this.dgVStudent.TabIndex = 39;
            this.dgVStudent.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVStudent_CellContentClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 40;
            // 
            // carrerDataGridViewTextBoxColumn
            // 
            this.carrerDataGridViewTextBoxColumn.DataPropertyName = "carrer";
            this.carrerDataGridViewTextBoxColumn.HeaderText = "carrer";
            this.carrerDataGridViewTextBoxColumn.Name = "carrerDataGridViewTextBoxColumn";
            this.carrerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // maximumCreditsDataGridViewTextBoxColumn
            // 
            this.maximumCreditsDataGridViewTextBoxColumn.DataPropertyName = "MaximumCredits";
            this.maximumCreditsDataGridViewTextBoxColumn.HeaderText = "MaximumCredits";
            this.maximumCreditsDataGridViewTextBoxColumn.Name = "maximumCreditsDataGridViewTextBoxColumn";
            this.maximumCreditsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // foreignerDataGridViewCheckBoxColumn
            // 
            this.foreignerDataGridViewCheckBoxColumn.DataPropertyName = "Foreigner";
            this.foreignerDataGridViewCheckBoxColumn.HeaderText = "Foreigner";
            this.foreignerDataGridViewCheckBoxColumn.Name = "foreignerDataGridViewCheckBoxColumn";
            this.foreignerDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn3
            // 
            this.nameDataGridViewTextBoxColumn3.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn3.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn3.Name = "nameDataGridViewTextBoxColumn3";
            this.nameDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // lastnameDataGridViewTextBoxColumn2
            // 
            this.lastnameDataGridViewTextBoxColumn2.DataPropertyName = "lastname";
            this.lastnameDataGridViewTextBoxColumn2.HeaderText = "lastname";
            this.lastnameDataGridViewTextBoxColumn2.Name = "lastnameDataGridViewTextBoxColumn2";
            this.lastnameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // daybirthDataGridViewTextBoxColumn2
            // 
            this.daybirthDataGridViewTextBoxColumn2.DataPropertyName = "daybirth";
            this.daybirthDataGridViewTextBoxColumn2.HeaderText = "daybirth";
            this.daybirthDataGridViewTextBoxColumn2.Name = "daybirthDataGridViewTextBoxColumn2";
            this.daybirthDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // genderDataGridViewTextBoxColumn2
            // 
            this.genderDataGridViewTextBoxColumn2.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn2.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn2.Name = "genderDataGridViewTextBoxColumn2";
            this.genderDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // usernameDataGridViewTextBoxColumn2
            // 
            this.usernameDataGridViewTextBoxColumn2.DataPropertyName = "username";
            this.usernameDataGridViewTextBoxColumn2.HeaderText = "username";
            this.usernameDataGridViewTextBoxColumn2.Name = "usernameDataGridViewTextBoxColumn2";
            this.usernameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dniDataGridViewTextBoxColumn2
            // 
            this.dniDataGridViewTextBoxColumn2.DataPropertyName = "dni";
            this.dniDataGridViewTextBoxColumn2.HeaderText = "dni";
            this.dniDataGridViewTextBoxColumn2.Name = "dniDataGridViewTextBoxColumn2";
            this.dniDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // iDDataGridViewTextBoxColumn4
            // 
            this.iDDataGridViewTextBoxColumn4.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn4.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn4.Name = "iDDataGridViewTextBoxColumn4";
            this.iDDataGridViewTextBoxColumn4.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn4.Visible = false;
            // 
            // carrerIDDataGridViewTextBoxColumn
            // 
            this.carrerIDDataGridViewTextBoxColumn.DataPropertyName = "CarrerID";
            this.carrerIDDataGridViewTextBoxColumn.HeaderText = "CarrerID";
            this.carrerIDDataGridViewTextBoxColumn.Name = "carrerIDDataGridViewTextBoxColumn";
            this.carrerIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.carrerIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // userIDDataGridViewTextBoxColumn2
            // 
            this.userIDDataGridViewTextBoxColumn2.DataPropertyName = "UserID";
            this.userIDDataGridViewTextBoxColumn2.HeaderText = "UserID";
            this.userIDDataGridViewTextBoxColumn2.Name = "userIDDataGridViewTextBoxColumn2";
            this.userIDDataGridViewTextBoxColumn2.ReadOnly = true;
            this.userIDDataGridViewTextBoxColumn2.Visible = false;
            // 
            // DeleteStudent
            // 
            this.DeleteStudent.HeaderText = "Delete";
            this.DeleteStudent.Name = "DeleteStudent";
            this.DeleteStudent.ReadOnly = true;
            this.DeleteStudent.Width = 60;
            // 
            // sTUDENTBindingSource
            // 
            this.sTUDENTBindingSource.DataSource = typeof(ENTITIES.STUDENT);
            // 
            // btnStudentADD
            // 
            this.btnStudentADD.Location = new System.Drawing.Point(895, 16);
            this.btnStudentADD.Name = "btnStudentADD";
            this.btnStudentADD.Size = new System.Drawing.Size(72, 25);
            this.btnStudentADD.TabIndex = 36;
            this.btnStudentADD.Text = "Add";
            this.btnStudentADD.UseVisualStyleBackColor = true;
            this.btnStudentADD.Click += new System.EventHandler(this.btnStudentADD_Click);
            // 
            // cbxForeigner
            // 
            this.cbxForeigner.AutoSize = true;
            this.cbxForeigner.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbxForeigner.Location = new System.Drawing.Point(770, 21);
            this.cbxForeigner.Name = "cbxForeigner";
            this.cbxForeigner.Size = new System.Drawing.Size(44, 17);
            this.cbxForeigner.TabIndex = 35;
            this.cbxForeigner.Text = "Yes";
            this.cbxForeigner.UseVisualStyleBackColor = true;
            // 
            // cbxCarrer
            // 
            this.cbxCarrer.DisplayMember = "Name";
            this.cbxCarrer.FormattingEnabled = true;
            this.cbxCarrer.Location = new System.Drawing.Point(99, 14);
            this.cbxCarrer.Name = "cbxCarrer";
            this.cbxCarrer.Size = new System.Drawing.Size(199, 21);
            this.cbxCarrer.TabIndex = 34;
            this.cbxCarrer.ValueMember = "ID";
            // 
            // txtMaximumCredits
            // 
            this.txtMaximumCredits.Location = new System.Drawing.Point(445, 14);
            this.txtMaximumCredits.Name = "txtMaximumCredits";
            this.txtMaximumCredits.Size = new System.Drawing.Size(199, 20);
            this.txtMaximumCredits.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(353, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "Maximum Credits";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(696, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "Foreigner";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "Carrer";
            // 
            // tabCourses
            // 
            this.tabCourses.Controls.Add(this.dGVCourse);
            this.tabCourses.Controls.Add(this.btnCourseUpdate);
            this.tabCourses.Controls.Add(this.btnCourseDelete);
            this.tabCourses.Controls.Add(this.btnCourseAdd);
            this.tabCourses.Controls.Add(this.cbxArea);
            this.tabCourses.Controls.Add(this.cbxObligatory);
            this.tabCourses.Controls.Add(this.label18);
            this.tabCourses.Controls.Add(this.txtCredits);
            this.tabCourses.Controls.Add(this.txtCourseName);
            this.tabCourses.Controls.Add(this.label6);
            this.tabCourses.Controls.Add(this.label8);
            this.tabCourses.Controls.Add(this.label17);
            this.tabCourses.Location = new System.Drawing.Point(4, 22);
            this.tabCourses.Name = "tabCourses";
            this.tabCourses.Padding = new System.Windows.Forms.Padding(3);
            this.tabCourses.Size = new System.Drawing.Size(1082, 586);
            this.tabCourses.TabIndex = 3;
            this.tabCourses.Text = "Courses";
            this.tabCourses.UseVisualStyleBackColor = true;
            // 
            // dGVCourse
            // 
            this.dGVCourse.AllowUserToAddRows = false;
            this.dGVCourse.AllowUserToDeleteRows = false;
            this.dGVCourse.AutoGenerateColumns = false;
            this.dGVCourse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVCourse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.CourseArea,
            this.nameDataGridViewTextBoxColumn,
            this.obligatoryDataGridViewCheckBoxColumn,
            this.creditDataGridViewTextBoxColumn,
            this.SelectCourse});
            this.dGVCourse.DataSource = this.cOURSEBindingSource;
            this.dGVCourse.Location = new System.Drawing.Point(267, 163);
            this.dGVCourse.Name = "dGVCourse";
            this.dGVCourse.ReadOnly = true;
            this.dGVCourse.Size = new System.Drawing.Size(543, 417);
            this.dGVCourse.TabIndex = 43;
            this.dGVCourse.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGVCourse_CellClick);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Visible = false;
            // 
            // CourseArea
            // 
            this.CourseArea.DataPropertyName = "CourseArea";
            this.CourseArea.HeaderText = "Area";
            this.CourseArea.Name = "CourseArea";
            this.CourseArea.ReadOnly = true;
            this.CourseArea.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // obligatoryDataGridViewCheckBoxColumn
            // 
            this.obligatoryDataGridViewCheckBoxColumn.DataPropertyName = "Obligatory";
            this.obligatoryDataGridViewCheckBoxColumn.HeaderText = "Obligatory";
            this.obligatoryDataGridViewCheckBoxColumn.Name = "obligatoryDataGridViewCheckBoxColumn";
            this.obligatoryDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // creditDataGridViewTextBoxColumn
            // 
            this.creditDataGridViewTextBoxColumn.DataPropertyName = "Credit";
            this.creditDataGridViewTextBoxColumn.HeaderText = "Credit";
            this.creditDataGridViewTextBoxColumn.Name = "creditDataGridViewTextBoxColumn";
            this.creditDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // SelectCourse
            // 
            this.SelectCourse.HeaderText = "Select";
            this.SelectCourse.Name = "SelectCourse";
            this.SelectCourse.ReadOnly = true;
            // 
            // cOURSEBindingSource
            // 
            this.cOURSEBindingSource.DataSource = typeof(ENTITIES.COURSE);
            // 
            // btnCourseUpdate
            // 
            this.btnCourseUpdate.Location = new System.Drawing.Point(617, 110);
            this.btnCourseUpdate.Name = "btnCourseUpdate";
            this.btnCourseUpdate.Size = new System.Drawing.Size(72, 25);
            this.btnCourseUpdate.TabIndex = 42;
            this.btnCourseUpdate.Text = "Update";
            this.btnCourseUpdate.UseVisualStyleBackColor = true;
            this.btnCourseUpdate.Click += new System.EventHandler(this.btnCourseUpdate_Click);
            // 
            // btnCourseDelete
            // 
            this.btnCourseDelete.Location = new System.Drawing.Point(497, 110);
            this.btnCourseDelete.Name = "btnCourseDelete";
            this.btnCourseDelete.Size = new System.Drawing.Size(72, 25);
            this.btnCourseDelete.TabIndex = 41;
            this.btnCourseDelete.Text = "Delete";
            this.btnCourseDelete.UseVisualStyleBackColor = true;
            this.btnCourseDelete.Click += new System.EventHandler(this.btnCourseDelete_Click);
            // 
            // btnCourseAdd
            // 
            this.btnCourseAdd.Location = new System.Drawing.Point(374, 110);
            this.btnCourseAdd.Name = "btnCourseAdd";
            this.btnCourseAdd.Size = new System.Drawing.Size(72, 25);
            this.btnCourseAdd.TabIndex = 40;
            this.btnCourseAdd.Text = "Add";
            this.btnCourseAdd.UseVisualStyleBackColor = true;
            this.btnCourseAdd.Click += new System.EventHandler(this.btnCourseAdd_Click);
            // 
            // cbxArea
            // 
            this.cbxArea.DisplayMember = "Description";
            this.cbxArea.FormattingEnabled = true;
            this.cbxArea.Location = new System.Drawing.Point(627, 56);
            this.cbxArea.Name = "cbxArea";
            this.cbxArea.Size = new System.Drawing.Size(199, 21);
            this.cbxArea.TabIndex = 38;
            this.cbxArea.ValueMember = "ID";
            // 
            // cbxObligatory
            // 
            this.cbxObligatory.AutoSize = true;
            this.cbxObligatory.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbxObligatory.Location = new System.Drawing.Point(332, 55);
            this.cbxObligatory.Name = "cbxObligatory";
            this.cbxObligatory.Size = new System.Drawing.Size(44, 17);
            this.cbxObligatory.TabIndex = 37;
            this.cbxObligatory.Text = "Yes";
            this.cbxObligatory.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(255, 59);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 13);
            this.label18.TabIndex = 36;
            this.label18.Text = "Obligatory";
            // 
            // txtCredits
            // 
            this.txtCredits.Location = new System.Drawing.Point(627, 25);
            this.txtCredits.Name = "txtCredits";
            this.txtCredits.Size = new System.Drawing.Size(199, 20);
            this.txtCredits.TabIndex = 32;
            // 
            // txtCourseName
            // 
            this.txtCourseName.Location = new System.Drawing.Point(332, 25);
            this.txtCourseName.Name = "txtCourseName";
            this.txtCourseName.Size = new System.Drawing.Size(199, 20);
            this.txtCourseName.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(575, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "Area";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(565, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "Credits";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(274, 32);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "Name";
            // 
            // tabArea
            // 
            this.tabArea.Controls.Add(this.btnUpdate);
            this.tabArea.Controls.Add(this.btnDelete);
            this.tabArea.Controls.Add(this.dGVArea);
            this.tabArea.Controls.Add(this.btnAreaAdd);
            this.tabArea.Controls.Add(this.txtAreaDescription);
            this.tabArea.Controls.Add(this.label21);
            this.tabArea.Location = new System.Drawing.Point(4, 22);
            this.tabArea.Name = "tabArea";
            this.tabArea.Padding = new System.Windows.Forms.Padding(3);
            this.tabArea.Size = new System.Drawing.Size(1082, 586);
            this.tabArea.TabIndex = 4;
            this.tabArea.Text = "Area";
            this.tabArea.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(644, 81);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(72, 25);
            this.btnUpdate.TabIndex = 55;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(505, 81);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(72, 25);
            this.btnDelete.TabIndex = 54;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // dGVArea
            // 
            this.dGVArea.AllowUserToAddRows = false;
            this.dGVArea.AllowUserToDeleteRows = false;
            this.dGVArea.AutoGenerateColumns = false;
            this.dGVArea.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVArea.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn1,
            this.descriptionDataGridViewTextBoxColumn,
            this.SelectArea});
            this.dGVArea.DataSource = this.aREABindingSource;
            this.dGVArea.Location = new System.Drawing.Point(318, 134);
            this.dGVArea.Name = "dGVArea";
            this.dGVArea.ReadOnly = true;
            this.dGVArea.Size = new System.Drawing.Size(445, 446);
            this.dGVArea.TabIndex = 53;
            this.dGVArea.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGVArea_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn1
            // 
            this.iDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn1.Name = "iDDataGridViewTextBoxColumn1";
            this.iDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn1.Visible = false;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            this.descriptionDataGridViewTextBoxColumn.Width = 300;
            // 
            // SelectArea
            // 
            this.SelectArea.HeaderText = "Select";
            this.SelectArea.Name = "SelectArea";
            this.SelectArea.ReadOnly = true;
            // 
            // aREABindingSource
            // 
            this.aREABindingSource.DataSource = typeof(ENTITIES.AREA);
            // 
            // btnAreaAdd
            // 
            this.btnAreaAdd.Location = new System.Drawing.Point(353, 81);
            this.btnAreaAdd.Name = "btnAreaAdd";
            this.btnAreaAdd.Size = new System.Drawing.Size(72, 25);
            this.btnAreaAdd.TabIndex = 50;
            this.btnAreaAdd.Text = "Add";
            this.btnAreaAdd.UseVisualStyleBackColor = true;
            this.btnAreaAdd.Click += new System.EventHandler(this.btnAreaAdd_Click);
            // 
            // txtAreaDescription
            // 
            this.txtAreaDescription.Location = new System.Drawing.Point(494, 24);
            this.txtAreaDescription.Name = "txtAreaDescription";
            this.txtAreaDescription.Size = new System.Drawing.Size(188, 20);
            this.txtAreaDescription.TabIndex = 47;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(416, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 13);
            this.label21.TabIndex = 46;
            this.label21.Text = "Description";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnUserAdd);
            this.tabPage1.Controls.Add(this.dgVUser);
            this.tabPage1.Controls.Add(this.rbtnMale);
            this.tabPage1.Controls.Add(this.rbtnFemale);
            this.tabPage1.Controls.Add(this.dTPDateOfBirth);
            this.tabPage1.Controls.Add(this.txtDni);
            this.tabPage1.Controls.Add(this.txtPassword);
            this.tabPage1.Controls.Add(this.txtUserName);
            this.tabPage1.Controls.Add(this.txtLastName);
            this.tabPage1.Controls.Add(this.txtName);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1082, 586);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "User";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnUserAdd
            // 
            this.btnUserAdd.Location = new System.Drawing.Point(886, 151);
            this.btnUserAdd.Name = "btnUserAdd";
            this.btnUserAdd.Size = new System.Drawing.Size(75, 23);
            this.btnUserAdd.TabIndex = 50;
            this.btnUserAdd.Text = "Add";
            this.btnUserAdd.UseVisualStyleBackColor = true;
            this.btnUserAdd.Click += new System.EventHandler(this.btnUserAdd_Click_1);
            // 
            // dgVUser
            // 
            this.dgVUser.AllowUserToAddRows = false;
            this.dgVUser.AllowUserToDeleteRows = false;
            this.dgVUser.AutoGenerateColumns = false;
            this.dgVUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVUser.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn5,
            this.nameDataGridViewTextBoxColumn4,
            this.lastNameDataGridViewTextBoxColumn3,
            this.dateOfBirthDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn3,
            this.userNameDataGridViewTextBoxColumn3,
            this.dNIDataGridViewTextBoxColumn3,
            this.paswordDataGridViewTextBoxColumn,
            this.Delete});
            this.dgVUser.DataSource = this.uSERBindingSource;
            this.dgVUser.Location = new System.Drawing.Point(117, 208);
            this.dgVUser.Name = "dgVUser";
            this.dgVUser.ReadOnly = true;
            this.dgVUser.Size = new System.Drawing.Size(844, 372);
            this.dgVUser.TabIndex = 49;
            this.dgVUser.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVUser_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn5
            // 
            this.iDDataGridViewTextBoxColumn5.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn5.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn5.Name = "iDDataGridViewTextBoxColumn5";
            this.iDDataGridViewTextBoxColumn5.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn5.Visible = false;
            // 
            // nameDataGridViewTextBoxColumn4
            // 
            this.nameDataGridViewTextBoxColumn4.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn4.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn4.Name = "nameDataGridViewTextBoxColumn4";
            this.nameDataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // lastNameDataGridViewTextBoxColumn3
            // 
            this.lastNameDataGridViewTextBoxColumn3.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn3.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn3.Name = "lastNameDataGridViewTextBoxColumn3";
            this.lastNameDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dateOfBirthDataGridViewTextBoxColumn
            // 
            this.dateOfBirthDataGridViewTextBoxColumn.DataPropertyName = "DateOfBirth";
            this.dateOfBirthDataGridViewTextBoxColumn.HeaderText = "DateOfBirth";
            this.dateOfBirthDataGridViewTextBoxColumn.Name = "dateOfBirthDataGridViewTextBoxColumn";
            this.dateOfBirthDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // genderDataGridViewTextBoxColumn3
            // 
            this.genderDataGridViewTextBoxColumn3.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn3.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn3.Name = "genderDataGridViewTextBoxColumn3";
            this.genderDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // userNameDataGridViewTextBoxColumn3
            // 
            this.userNameDataGridViewTextBoxColumn3.DataPropertyName = "UserName";
            this.userNameDataGridViewTextBoxColumn3.HeaderText = "UserName";
            this.userNameDataGridViewTextBoxColumn3.Name = "userNameDataGridViewTextBoxColumn3";
            this.userNameDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dNIDataGridViewTextBoxColumn3
            // 
            this.dNIDataGridViewTextBoxColumn3.DataPropertyName = "DNI";
            this.dNIDataGridViewTextBoxColumn3.HeaderText = "DNI";
            this.dNIDataGridViewTextBoxColumn3.Name = "dNIDataGridViewTextBoxColumn3";
            this.dNIDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // paswordDataGridViewTextBoxColumn
            // 
            this.paswordDataGridViewTextBoxColumn.DataPropertyName = "Pasword";
            this.paswordDataGridViewTextBoxColumn.HeaderText = "Pasword";
            this.paswordDataGridViewTextBoxColumn.Name = "paswordDataGridViewTextBoxColumn";
            this.paswordDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Delete
            // 
            this.Delete.HeaderText = "Delete";
            this.Delete.Name = "Delete";
            this.Delete.ReadOnly = true;
            // 
            // uSERBindingSource
            // 
            this.uSERBindingSource.DataSource = typeof(ENTITIES.USER);
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.Location = new System.Drawing.Point(553, 26);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(48, 17);
            this.rbtnMale.TabIndex = 48;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = true;
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.Location = new System.Drawing.Point(478, 26);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(59, 17);
            this.rbtnFemale.TabIndex = 47;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = true;
            // 
            // dTPDateOfBirth
            // 
            this.dTPDateOfBirth.Location = new System.Drawing.Point(157, 117);
            this.dTPDateOfBirth.Name = "dTPDateOfBirth";
            this.dTPDateOfBirth.Size = new System.Drawing.Size(199, 20);
            this.dTPDateOfBirth.TabIndex = 46;
            // 
            // txtDni
            // 
            this.txtDni.Location = new System.Drawing.Point(805, 24);
            this.txtDni.Name = "txtDni";
            this.txtDni.Size = new System.Drawing.Size(199, 20);
            this.txtDni.TabIndex = 45;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(478, 120);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(199, 20);
            this.txtPassword.TabIndex = 44;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(478, 74);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(199, 20);
            this.txtUserName.TabIndex = 43;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(157, 74);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(199, 20);
            this.txtLastName.TabIndex = 42;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(157, 28);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(199, 20);
            this.txtName.TabIndex = 41;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(756, 31);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "DNI";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(402, 127);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 39;
            this.label19.Text = "Password";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(395, 81);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 13);
            this.label20.TabIndex = 38;
            this.label20.Text = "User Name";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(413, 31);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(42, 13);
            this.label22.TabIndex = 37;
            this.label22.Text = "Gender";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(68, 124);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 13);
            this.label23.TabIndex = 36;
            this.label23.Text = "Date of Birth";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(76, 81);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(58, 13);
            this.label24.TabIndex = 35;
            this.label24.Text = "Last Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(99, 35);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 13);
            this.label25.TabIndex = 34;
            this.label25.Text = "Name";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgVCarrer);
            this.tabPage2.Controls.Add(this.btnCarrerAdd);
            this.tabPage2.Controls.Add(this.txtCarrerName);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1082, 586);
            this.tabPage2.TabIndex = 6;
            this.tabPage2.Text = "Carrer";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgVCarrer
            // 
            this.dgVCarrer.AllowUserToAddRows = false;
            this.dgVCarrer.AllowUserToDeleteRows = false;
            this.dgVCarrer.AutoGenerateColumns = false;
            this.dgVCarrer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVCarrer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn6,
            this.nameDataGridViewTextBoxColumn5,
            this.DeleteCarrer});
            this.dgVCarrer.DataSource = this.cAREERBindingSource;
            this.dgVCarrer.Location = new System.Drawing.Point(337, 120);
            this.dgVCarrer.Name = "dgVCarrer";
            this.dgVCarrer.ReadOnly = true;
            this.dgVCarrer.Size = new System.Drawing.Size(444, 460);
            this.dgVCarrer.TabIndex = 45;
            this.dgVCarrer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVCarrer_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn6
            // 
            this.iDDataGridViewTextBoxColumn6.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn6.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn6.Name = "iDDataGridViewTextBoxColumn6";
            this.iDDataGridViewTextBoxColumn6.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn6.Visible = false;
            // 
            // nameDataGridViewTextBoxColumn5
            // 
            this.nameDataGridViewTextBoxColumn5.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn5.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn5.Name = "nameDataGridViewTextBoxColumn5";
            this.nameDataGridViewTextBoxColumn5.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn5.Width = 300;
            // 
            // DeleteCarrer
            // 
            this.DeleteCarrer.HeaderText = "Delete";
            this.DeleteCarrer.Name = "DeleteCarrer";
            this.DeleteCarrer.ReadOnly = true;
            // 
            // cAREERBindingSource
            // 
            this.cAREERBindingSource.DataSource = typeof(ENTITIES.CAREER);
            // 
            // btnCarrerAdd
            // 
            this.btnCarrerAdd.Location = new System.Drawing.Point(662, 36);
            this.btnCarrerAdd.Name = "btnCarrerAdd";
            this.btnCarrerAdd.Size = new System.Drawing.Size(75, 23);
            this.btnCarrerAdd.TabIndex = 44;
            this.btnCarrerAdd.Text = "Add";
            this.btnCarrerAdd.UseVisualStyleBackColor = true;
            this.btnCarrerAdd.Click += new System.EventHandler(this.btnCarrerAdd_Click);
            // 
            // txtCarrerName
            // 
            this.txtCarrerName.Location = new System.Drawing.Point(417, 39);
            this.txtCarrerName.Name = "txtCarrerName";
            this.txtCarrerName.Size = new System.Drawing.Size(199, 20);
            this.txtCarrerName.TabIndex = 43;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(359, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 42;
            this.label12.Text = "Name";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnAdd);
            this.tabPage3.Controls.Add(this.txtReason);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.txtQuantity);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.cbxStudentNameDebt);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.dgVDebs);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1082, 586);
            this.tabPage3.TabIndex = 7;
            this.tabPage3.Text = "Debts";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(788, 174);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 7;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtReason
            // 
            this.txtReason.Location = new System.Drawing.Point(563, 40);
            this.txtReason.Name = "txtReason";
            this.txtReason.Size = new System.Drawing.Size(300, 96);
            this.txtReason.TabIndex = 6;
            this.txtReason.Text = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(497, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "Reason";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(289, 107);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(157, 20);
            this.txtQuantity.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(225, 107);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Quantity";
            // 
            // cbxStudentNameDebt
            // 
            this.cbxStudentNameDebt.DisplayMember = "name";
            this.cbxStudentNameDebt.FormattingEnabled = true;
            this.cbxStudentNameDebt.Location = new System.Drawing.Point(289, 40);
            this.cbxStudentNameDebt.Name = "cbxStudentNameDebt";
            this.cbxStudentNameDebt.Size = new System.Drawing.Size(157, 21);
            this.cbxStudentNameDebt.TabIndex = 2;
            this.cbxStudentNameDebt.ValueMember = "ID";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(225, 48);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Student";
            // 
            // dgVDebs
            // 
            this.dgVDebs.AllowUserToAddRows = false;
            this.dgVDebs.AllowUserToDeleteRows = false;
            this.dgVDebs.AutoGenerateColumns = false;
            this.dgVDebs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVDebs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn7,
            this.studentNameDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.reasonDataGridViewTextBoxColumn,
            this.studentIDDataGridViewTextBoxColumn,
            this.DeleteDebt});
            this.dgVDebs.DataSource = this.dEBTBindingSource;
            this.dgVDebs.Location = new System.Drawing.Point(218, 231);
            this.dgVDebs.Name = "dgVDebs";
            this.dgVDebs.ReadOnly = true;
            this.dgVDebs.Size = new System.Drawing.Size(645, 349);
            this.dgVDebs.TabIndex = 0;
            this.dgVDebs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVDebs_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn7
            // 
            this.iDDataGridViewTextBoxColumn7.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn7.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn7.Name = "iDDataGridViewTextBoxColumn7";
            this.iDDataGridViewTextBoxColumn7.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn7.Visible = false;
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "studentName";
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "Student ID";
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            this.studentNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // reasonDataGridViewTextBoxColumn
            // 
            this.reasonDataGridViewTextBoxColumn.DataPropertyName = "Reason";
            this.reasonDataGridViewTextBoxColumn.HeaderText = "Reason";
            this.reasonDataGridViewTextBoxColumn.Name = "reasonDataGridViewTextBoxColumn";
            this.reasonDataGridViewTextBoxColumn.ReadOnly = true;
            this.reasonDataGridViewTextBoxColumn.Width = 300;
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "StudentID";
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            this.studentIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.studentIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // DeleteDebt
            // 
            this.DeleteDebt.HeaderText = "Delete";
            this.DeleteDebt.Name = "DeleteDebt";
            this.DeleteDebt.ReadOnly = true;
            // 
            // dEBTBindingSource
            // 
            this.dEBTBindingSource.DataSource = typeof(ENTITIES.DEBT);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1082, 586);
            this.tabPage4.TabIndex = 8;
            this.tabPage4.Text = "Assing course and sections";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cbxTeacher);
            this.groupBox4.Controls.Add(this.cbxCourse);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.dgVCourseTeacher);
            this.groupBox4.Controls.Add(this.btnCourseSectionAdd);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Location = new System.Drawing.Point(494, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(541, 574);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Assign courses to teachers";
            // 
            // cbxTeacher
            // 
            this.cbxTeacher.DisplayMember = "name";
            this.cbxTeacher.FormattingEnabled = true;
            this.cbxTeacher.Location = new System.Drawing.Point(172, 19);
            this.cbxTeacher.Name = "cbxTeacher";
            this.cbxTeacher.Size = new System.Drawing.Size(164, 21);
            this.cbxTeacher.TabIndex = 6;
            this.cbxTeacher.ValueMember = "ID";
            // 
            // cbxCourse
            // 
            this.cbxCourse.DisplayMember = "Name";
            this.cbxCourse.FormattingEnabled = true;
            this.cbxCourse.Location = new System.Drawing.Point(172, 55);
            this.cbxCourse.Name = "cbxCourse";
            this.cbxCourse.Size = new System.Drawing.Size(164, 21);
            this.cbxCourse.TabIndex = 5;
            this.cbxCourse.ValueMember = "ID";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(106, 27);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(47, 13);
            this.label28.TabIndex = 4;
            this.label28.Text = "Teacher";
            // 
            // dgVCourseTeacher
            // 
            this.dgVCourseTeacher.AllowUserToAddRows = false;
            this.dgVCourseTeacher.AllowUserToDeleteRows = false;
            this.dgVCourseTeacher.AutoGenerateColumns = false;
            this.dgVCourseTeacher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVCourseTeacher.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.teacherIDDataGridViewTextBoxColumn,
            this.courseNameDataGridViewTextBoxColumn,
            this.iDDataGridViewTextBoxColumn9,
            this.dataGridViewButtonColumn1});
            this.dgVCourseTeacher.DataSource = this.tECHERCOURSEBindingSource;
            this.dgVCourseTeacher.Location = new System.Drawing.Point(88, 137);
            this.dgVCourseTeacher.Name = "dgVCourseTeacher";
            this.dgVCourseTeacher.ReadOnly = true;
            this.dgVCourseTeacher.Size = new System.Drawing.Size(344, 431);
            this.dgVCourseTeacher.TabIndex = 3;
            this.dgVCourseTeacher.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVCourseTeacher_CellContentClick);
            // 
            // teacherIDDataGridViewTextBoxColumn
            // 
            this.teacherIDDataGridViewTextBoxColumn.DataPropertyName = "TeacherID";
            this.teacherIDDataGridViewTextBoxColumn.HeaderText = "Teacher ID";
            this.teacherIDDataGridViewTextBoxColumn.Name = "teacherIDDataGridViewTextBoxColumn";
            this.teacherIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // courseNameDataGridViewTextBoxColumn
            // 
            this.courseNameDataGridViewTextBoxColumn.DataPropertyName = "courseName";
            this.courseNameDataGridViewTextBoxColumn.HeaderText = "courseName";
            this.courseNameDataGridViewTextBoxColumn.Name = "courseNameDataGridViewTextBoxColumn";
            this.courseNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // iDDataGridViewTextBoxColumn9
            // 
            this.iDDataGridViewTextBoxColumn9.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn9.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn9.Name = "iDDataGridViewTextBoxColumn9";
            this.iDDataGridViewTextBoxColumn9.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn9.Visible = false;
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.HeaderText = "Delete";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            this.dataGridViewButtonColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewButtonColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // tECHERCOURSEBindingSource
            // 
            this.tECHERCOURSEBindingSource.DataSource = typeof(ENTITIES.TECHER_COURSE);
            // 
            // btnCourseSectionAdd
            // 
            this.btnCourseSectionAdd.Location = new System.Drawing.Point(357, 90);
            this.btnCourseSectionAdd.Name = "btnCourseSectionAdd";
            this.btnCourseSectionAdd.Size = new System.Drawing.Size(75, 23);
            this.btnCourseSectionAdd.TabIndex = 2;
            this.btnCourseSectionAdd.Text = "Add";
            this.btnCourseSectionAdd.UseVisualStyleBackColor = true;
            this.btnCourseSectionAdd.Click += new System.EventHandler(this.btnCourseSectionAdd_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(113, 63);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 13);
            this.label27.TabIndex = 0;
            this.label27.Text = "Course";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgVSection);
            this.groupBox3.Controls.Add(this.btnSectionAdd);
            this.groupBox3.Controls.Add(this.txtSectionName);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Location = new System.Drawing.Point(63, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(327, 574);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Section";
            // 
            // dgVSection
            // 
            this.dgVSection.AllowUserToAddRows = false;
            this.dgVSection.AllowUserToDeleteRows = false;
            this.dgVSection.AutoGenerateColumns = false;
            this.dgVSection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVSection.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn8,
            this.sectionNameDataGridViewTextBoxColumn,
            this.DeleteSection});
            this.dgVSection.DataSource = this.sECTIONBindingSource;
            this.dgVSection.Location = new System.Drawing.Point(42, 137);
            this.dgVSection.Name = "dgVSection";
            this.dgVSection.ReadOnly = true;
            this.dgVSection.Size = new System.Drawing.Size(244, 431);
            this.dgVSection.TabIndex = 3;
            this.dgVSection.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVSection_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn8
            // 
            this.iDDataGridViewTextBoxColumn8.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn8.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn8.Name = "iDDataGridViewTextBoxColumn8";
            this.iDDataGridViewTextBoxColumn8.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn8.Visible = false;
            // 
            // sectionNameDataGridViewTextBoxColumn
            // 
            this.sectionNameDataGridViewTextBoxColumn.DataPropertyName = "SectionName";
            this.sectionNameDataGridViewTextBoxColumn.HeaderText = "SectionName";
            this.sectionNameDataGridViewTextBoxColumn.Name = "sectionNameDataGridViewTextBoxColumn";
            this.sectionNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // DeleteSection
            // 
            this.DeleteSection.HeaderText = "Delete";
            this.DeleteSection.Name = "DeleteSection";
            this.DeleteSection.ReadOnly = true;
            this.DeleteSection.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DeleteSection.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // sECTIONBindingSource
            // 
            this.sECTIONBindingSource.DataSource = typeof(ENTITIES.SECTION);
            // 
            // btnSectionAdd
            // 
            this.btnSectionAdd.Location = new System.Drawing.Point(211, 90);
            this.btnSectionAdd.Name = "btnSectionAdd";
            this.btnSectionAdd.Size = new System.Drawing.Size(75, 23);
            this.btnSectionAdd.TabIndex = 2;
            this.btnSectionAdd.Text = "Add";
            this.btnSectionAdd.UseVisualStyleBackColor = true;
            this.btnSectionAdd.Click += new System.EventHandler(this.btnSectionAdd_Click);
            // 
            // txtSectionName
            // 
            this.txtSectionName.Location = new System.Drawing.Point(110, 31);
            this.txtSectionName.Name = "txtSectionName";
            this.txtSectionName.Size = new System.Drawing.Size(190, 20);
            this.txtSectionName.TabIndex = 1;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(20, 38);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(74, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "Section Name";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dgVCourseSection);
            this.tabPage5.Controls.Add(this.txtDay);
            this.tabPage5.Controls.Add(this.txtClasroomName);
            this.tabPage5.Controls.Add(this.txtVacancesAvailable);
            this.tabPage5.Controls.Add(this.txtHourEnd);
            this.tabPage5.Controls.Add(this.txtHourStart);
            this.tabPage5.Controls.Add(this.cbxEnableTeacher);
            this.tabPage5.Controls.Add(this.label36);
            this.tabPage5.Controls.Add(this.cbxEnableCourse);
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.btnEneableSection);
            this.tabPage5.Controls.Add(this.cbxEnableSection);
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this.label33);
            this.tabPage5.Controls.Add(this.label32);
            this.tabPage5.Controls.Add(this.label31);
            this.tabPage5.Controls.Add(this.label30);
            this.tabPage5.Controls.Add(this.label29);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1082, 586);
            this.tabPage5.TabIndex = 9;
            this.tabPage5.Text = "Enable Sections";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dgVCourseSection
            // 
            this.dgVCourseSection.AllowUserToAddRows = false;
            this.dgVCourseSection.AllowUserToDeleteRows = false;
            this.dgVCourseSection.AutoGenerateColumns = false;
            this.dgVCourseSection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVCourseSection.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.courseDataGridViewTextBoxColumn,
            this.teacherDataGridViewTextBoxColumn,
            this.SectionName2,
            this.hourStartDataGridViewTextBoxColumn,
            this.hourEndDataGridViewTextBoxColumn,
            this.vacanciesAvailableDataGridViewTextBoxColumn,
            this.clasroomNameDataGridViewTextBoxColumn,
            this.dayDataGridViewTextBoxColumn,
            this.DeleteCourseSection,
            this.iDDataGridViewTextBoxColumn10,
            this.sectionIDDataGridViewTextBoxColumn,
            this.teacherCourseIDDataGridViewTextBoxColumn});
            this.dgVCourseSection.DataSource = this.cOURSESECTIONBindingSource;
            this.dgVCourseSection.Location = new System.Drawing.Point(45, 209);
            this.dgVCourseSection.Name = "dgVCourseSection";
            this.dgVCourseSection.ReadOnly = true;
            this.dgVCourseSection.Size = new System.Drawing.Size(994, 371);
            this.dgVCourseSection.TabIndex = 17;
            this.dgVCourseSection.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgVCourseSection_CellContentClick);
            // 
            // cOURSESECTIONBindingSource
            // 
            this.cOURSESECTIONBindingSource.DataSource = typeof(ENTITIES.COURSE_SECTION);
            // 
            // txtDay
            // 
            this.txtDay.Location = new System.Drawing.Point(723, 88);
            this.txtDay.Name = "txtDay";
            this.txtDay.Size = new System.Drawing.Size(100, 20);
            this.txtDay.TabIndex = 16;
            // 
            // txtClasroomName
            // 
            this.txtClasroomName.Location = new System.Drawing.Point(723, 43);
            this.txtClasroomName.Name = "txtClasroomName";
            this.txtClasroomName.Size = new System.Drawing.Size(100, 20);
            this.txtClasroomName.TabIndex = 15;
            // 
            // txtVacancesAvailable
            // 
            this.txtVacancesAvailable.Location = new System.Drawing.Point(453, 137);
            this.txtVacancesAvailable.Name = "txtVacancesAvailable";
            this.txtVacancesAvailable.Size = new System.Drawing.Size(100, 20);
            this.txtVacancesAvailable.TabIndex = 14;
            // 
            // txtHourEnd
            // 
            this.txtHourEnd.Location = new System.Drawing.Point(453, 92);
            this.txtHourEnd.Name = "txtHourEnd";
            this.txtHourEnd.Size = new System.Drawing.Size(100, 20);
            this.txtHourEnd.TabIndex = 13;
            // 
            // txtHourStart
            // 
            this.txtHourStart.Location = new System.Drawing.Point(453, 47);
            this.txtHourStart.Name = "txtHourStart";
            this.txtHourStart.Size = new System.Drawing.Size(100, 20);
            this.txtHourStart.TabIndex = 12;
            // 
            // cbxEnableTeacher
            // 
            this.cbxEnableTeacher.DisplayMember = "name";
            this.cbxEnableTeacher.FormattingEnabled = true;
            this.cbxEnableTeacher.Location = new System.Drawing.Point(163, 92);
            this.cbxEnableTeacher.Name = "cbxEnableTeacher";
            this.cbxEnableTeacher.Size = new System.Drawing.Size(121, 21);
            this.cbxEnableTeacher.TabIndex = 11;
            this.cbxEnableTeacher.ValueMember = "ID";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(87, 100);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(47, 13);
            this.label36.TabIndex = 10;
            this.label36.Text = "Teacher";
            // 
            // cbxEnableCourse
            // 
            this.cbxEnableCourse.DisplayMember = "Name";
            this.cbxEnableCourse.FormattingEnabled = true;
            this.cbxEnableCourse.Location = new System.Drawing.Point(163, 47);
            this.cbxEnableCourse.Name = "cbxEnableCourse";
            this.cbxEnableCourse.Size = new System.Drawing.Size(121, 21);
            this.cbxEnableCourse.TabIndex = 9;
            this.cbxEnableCourse.ValueMember = "ID";
            this.cbxEnableCourse.SelectedIndexChanged += new System.EventHandler(this.cbxEnableCourse_SelectedIndexChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(94, 55);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(40, 13);
            this.label35.TabIndex = 8;
            this.label35.Text = "Course";
            // 
            // btnEneableSection
            // 
            this.btnEneableSection.Location = new System.Drawing.Point(918, 134);
            this.btnEneableSection.Name = "btnEneableSection";
            this.btnEneableSection.Size = new System.Drawing.Size(75, 23);
            this.btnEneableSection.TabIndex = 7;
            this.btnEneableSection.Text = "Add";
            this.btnEneableSection.UseVisualStyleBackColor = true;
            this.btnEneableSection.Click += new System.EventHandler(this.btnEneableSection_Click);
            // 
            // cbxEnableSection
            // 
            this.cbxEnableSection.DisplayMember = "SectionName";
            this.cbxEnableSection.FormattingEnabled = true;
            this.cbxEnableSection.Location = new System.Drawing.Point(163, 136);
            this.cbxEnableSection.Name = "cbxEnableSection";
            this.cbxEnableSection.Size = new System.Drawing.Size(121, 21);
            this.cbxEnableSection.TabIndex = 6;
            this.cbxEnableSection.ValueMember = "ID";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(669, 95);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(26, 13);
            this.label34.TabIndex = 5;
            this.label34.Text = "Day";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(609, 50);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(86, 13);
            this.label33.TabIndex = 4;
            this.label33.Text = "Classroom Name";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(321, 144);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(105, 13);
            this.label32.TabIndex = 3;
            this.label32.Text = "Vacancies Avalilable";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(374, 100);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(52, 13);
            this.label31.TabIndex = 2;
            this.label31.Text = "Hour End";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(371, 55);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 13);
            this.label30.TabIndex = 1;
            this.label30.Text = "Hour Start";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(91, 144);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(43, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Section";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.tab1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1102, 637);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Magnament";
            // 
            // aREABindingSource1
            // 
            this.aREABindingSource1.DataSource = typeof(ENTITIES.AREA);
            // 
            // courseDataGridViewTextBoxColumn
            // 
            this.courseDataGridViewTextBoxColumn.DataPropertyName = "course";
            this.courseDataGridViewTextBoxColumn.HeaderText = "Course";
            this.courseDataGridViewTextBoxColumn.Name = "courseDataGridViewTextBoxColumn";
            this.courseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // teacherDataGridViewTextBoxColumn
            // 
            this.teacherDataGridViewTextBoxColumn.DataPropertyName = "teacher";
            this.teacherDataGridViewTextBoxColumn.HeaderText = "Teacher";
            this.teacherDataGridViewTextBoxColumn.Name = "teacherDataGridViewTextBoxColumn";
            this.teacherDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // SectionName2
            // 
            this.SectionName2.DataPropertyName = "SectionName2";
            this.SectionName2.HeaderText = "Section";
            this.SectionName2.Name = "SectionName2";
            this.SectionName2.ReadOnly = true;
            // 
            // hourStartDataGridViewTextBoxColumn
            // 
            this.hourStartDataGridViewTextBoxColumn.DataPropertyName = "HourStart";
            this.hourStartDataGridViewTextBoxColumn.HeaderText = "HourStart";
            this.hourStartDataGridViewTextBoxColumn.Name = "hourStartDataGridViewTextBoxColumn";
            this.hourStartDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // hourEndDataGridViewTextBoxColumn
            // 
            this.hourEndDataGridViewTextBoxColumn.DataPropertyName = "HourEnd";
            this.hourEndDataGridViewTextBoxColumn.HeaderText = "HourEnd";
            this.hourEndDataGridViewTextBoxColumn.Name = "hourEndDataGridViewTextBoxColumn";
            this.hourEndDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vacanciesAvailableDataGridViewTextBoxColumn
            // 
            this.vacanciesAvailableDataGridViewTextBoxColumn.DataPropertyName = "VacanciesAvailable";
            this.vacanciesAvailableDataGridViewTextBoxColumn.HeaderText = "VacanciesAvailable";
            this.vacanciesAvailableDataGridViewTextBoxColumn.Name = "vacanciesAvailableDataGridViewTextBoxColumn";
            this.vacanciesAvailableDataGridViewTextBoxColumn.ReadOnly = true;
            this.vacanciesAvailableDataGridViewTextBoxColumn.Width = 150;
            // 
            // clasroomNameDataGridViewTextBoxColumn
            // 
            this.clasroomNameDataGridViewTextBoxColumn.DataPropertyName = "ClasroomName";
            this.clasroomNameDataGridViewTextBoxColumn.HeaderText = "ClasroomName";
            this.clasroomNameDataGridViewTextBoxColumn.Name = "clasroomNameDataGridViewTextBoxColumn";
            this.clasroomNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dayDataGridViewTextBoxColumn
            // 
            this.dayDataGridViewTextBoxColumn.DataPropertyName = "Day";
            this.dayDataGridViewTextBoxColumn.HeaderText = "Day";
            this.dayDataGridViewTextBoxColumn.Name = "dayDataGridViewTextBoxColumn";
            this.dayDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // DeleteCourseSection
            // 
            this.DeleteCourseSection.HeaderText = "Delete";
            this.DeleteCourseSection.Name = "DeleteCourseSection";
            this.DeleteCourseSection.ReadOnly = true;
            // 
            // iDDataGridViewTextBoxColumn10
            // 
            this.iDDataGridViewTextBoxColumn10.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn10.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn10.Name = "iDDataGridViewTextBoxColumn10";
            this.iDDataGridViewTextBoxColumn10.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn10.Visible = false;
            // 
            // sectionIDDataGridViewTextBoxColumn
            // 
            this.sectionIDDataGridViewTextBoxColumn.DataPropertyName = "SectionID";
            this.sectionIDDataGridViewTextBoxColumn.HeaderText = "SectionID";
            this.sectionIDDataGridViewTextBoxColumn.Name = "sectionIDDataGridViewTextBoxColumn";
            this.sectionIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.sectionIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // teacherCourseIDDataGridViewTextBoxColumn
            // 
            this.teacherCourseIDDataGridViewTextBoxColumn.DataPropertyName = "Teacher_CourseID";
            this.teacherCourseIDDataGridViewTextBoxColumn.HeaderText = "Teacher_CourseID";
            this.teacherCourseIDDataGridViewTextBoxColumn.Name = "teacherCourseIDDataGridViewTextBoxColumn";
            this.teacherCourseIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.teacherCourseIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // FrmAdministrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1126, 661);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "FrmAdministrator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administrator";
            this.Load += new System.EventHandler(this.FrmAdministrator_Load);
            this.tab1.ResumeLayout(false);
            this.tabUsers.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabAdministrators.ResumeLayout(false);
            this.tabAdministrators.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVAdministrators)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aDMINISTRATORBindingSource)).EndInit();
            this.tabTeachers.ResumeLayout(false);
            this.tabTeachers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVTeacher)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tEACHERBindingSource)).EndInit();
            this.tabStudents.ResumeLayout(false);
            this.tabStudents.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVStudent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTUDENTBindingSource)).EndInit();
            this.tabCourses.ResumeLayout(false);
            this.tabCourses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVCourse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSEBindingSource)).EndInit();
            this.tabArea.ResumeLayout(false);
            this.tabArea.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVCarrer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cAREERBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVDebs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dEBTBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVCourseTeacher)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tECHERCOURSEBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVSection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sECTIONBindingSource)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVCourseSection)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSESECTIONBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tab1;
        private System.Windows.Forms.TabPage tabUsers;
        private System.Windows.Forms.TabPage tabCourses;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabAdministrators;
        private System.Windows.Forms.TabPage tabTeachers;
        private System.Windows.Forms.TabPage tabStudents;
        private System.Windows.Forms.DataGridView dGVAdministrators;
        private System.Windows.Forms.Button btnAdministratorAdd;
        private System.Windows.Forms.TextBox txtWokArea;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dGVTeacher;
        private System.Windows.Forms.Button btnTeacherAdd;
        private System.Windows.Forms.TextBox txtUniversityDegrees;
        private System.Windows.Forms.TextBox txtProfession;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgVStudent;
        private System.Windows.Forms.Button btnStudentADD;
        private System.Windows.Forms.CheckBox cbxForeigner;
        private System.Windows.Forms.ComboBox cbxCarrer;
        private System.Windows.Forms.TextBox txtMaximumCredits;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dGVCourse;
        private System.Windows.Forms.Button btnCourseUpdate;
        private System.Windows.Forms.Button btnCourseDelete;
        private System.Windows.Forms.Button btnCourseAdd;
        private System.Windows.Forms.ComboBox cbxArea;
        private System.Windows.Forms.CheckBox cbxObligatory;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtCredits;
        private System.Windows.Forms.TextBox txtCourseName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.BindingSource cOURSEBindingSource;
        private System.Windows.Forms.TabPage tabArea;
        private System.Windows.Forms.TextBox txtAreaDescription;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView dGVArea;
        private System.Windows.Forms.BindingSource aREABindingSource;
        private System.Windows.Forms.Button btnAreaAdd;
        private System.Windows.Forms.BindingSource aREABindingSource1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn SelectArea;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CourseArea;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn obligatoryDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn creditDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn SelectCourse;
        private System.Windows.Forms.BindingSource aDMINISTRATORBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn userIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn workAreaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSERDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn daybirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dniDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteAdministrator;
        private System.Windows.Forms.BindingSource tEACHERBindingSource;
        private System.Windows.Forms.BindingSource sTUDENTBindingSource;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.DateTimePicker dTPDateOfBirth;
        private System.Windows.Forms.TextBox txtDni;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnUserAdd;
        private System.Windows.Forms.DataGridView dgVUser;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOfBirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dNIDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn paswordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Delete;
        private System.Windows.Forms.BindingSource uSERBindingSource;
        private System.Windows.Forms.ComboBox cbxUserNameAdmin;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbxUserNameTeacher;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbxUserNameStudent;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgVCarrer;
        private System.Windows.Forms.BindingSource cAREERBindingSource;
        private System.Windows.Forms.Button btnCarrerAdd;
        private System.Windows.Forms.TextBox txtCarrerName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteCarrer;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgVDebs;
        private System.Windows.Forms.ComboBox cbxStudentNameDebt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.BindingSource dEBTBindingSource;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.RichTextBox txtReason;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reasonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteDebt;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn carrerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maximumCreditsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn foreignerDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn daybirthDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dniDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn carrerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteStudent;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.DataGridView dgVCourseTeacher;
        private System.Windows.Forms.Button btnCourseSectionAdd;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DataGridView dgVSection;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteSection;
        private System.Windows.Forms.BindingSource sECTIONBindingSource;
        private System.Windows.Forms.Button btnSectionAdd;
        private System.Windows.Forms.TextBox txtSectionName;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn professionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn universityDegreesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn daybirthDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dniDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn userIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteTeacher;
        private System.Windows.Forms.BindingSource tECHERCOURSEBindingSource;
        private System.Windows.Forms.ComboBox cbxTeacher;
        private System.Windows.Forms.ComboBox cbxCourse;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridViewTextBoxColumn teacherIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.ComboBox cbxEnableSection;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnEneableSection;
        private System.Windows.Forms.ComboBox cbxEnableTeacher;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cbxEnableCourse;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DataGridView dgVCourseSection;
        private System.Windows.Forms.TextBox txtDay;
        private System.Windows.Forms.TextBox txtClasroomName;
        private System.Windows.Forms.TextBox txtVacancesAvailable;
        private System.Windows.Forms.TextBox txtHourEnd;
        private System.Windows.Forms.TextBox txtHourStart;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource cOURSESECTIONBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn courseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn teacherDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SectionName2;
        private System.Windows.Forms.DataGridViewTextBoxColumn hourStartDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hourEndDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vacanciesAvailableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clasroomNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteCourseSection;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn teacherCourseIDDataGridViewTextBoxColumn;
    }
}