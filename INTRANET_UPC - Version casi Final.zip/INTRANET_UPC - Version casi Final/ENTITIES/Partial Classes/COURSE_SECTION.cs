﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class COURSE_SECTION
    {
        public string course
        {
            set
            {

            }
            get
            {
                return this.TECHER_COURSE.COURSE.Name;
            }
        }
        public string CourseSection
        {
            set { }
            get
            {
                return this.SECTION.SectionName + " " +
                    this.TECHER_COURSE.COURSE.Name;
            }
        }
        public string teacher
        {
            set
            {

            }
            get
            {
                return this.TECHER_COURSE.TEACHER.USER.Name;
            }
        }
        public string SectionName2
        {
            set
            {

            }
            get
            {
                return this.SECTION.SectionName;
            }
        }
        public string Horario
        {
            set
            {

            }
            get
            {
                string horario = this.Day + " " + this.HourStart + " : " + this.HourEnd;
                return horario;
            }
        }
    }
}
