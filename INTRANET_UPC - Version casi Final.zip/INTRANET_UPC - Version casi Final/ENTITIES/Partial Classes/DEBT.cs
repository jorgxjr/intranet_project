﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class DEBT
    {
        public int studentName
        {
            set
            {

            }
            get
            {
                return this.STUDENT.ID;
            }
        }
    }
}
