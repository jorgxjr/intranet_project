﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.CourseCarrers
{
    public class CourseCarrerRepository : ICourseCarrerRepository
    {
        public bool CreatedCourseCarrer(COURSE_CARRER OB)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.COURSE_CARRER.Add(OB);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }
        public bool DeleteCourseCarrer(int id)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var courseCarrera = from c in dataContext.COURSE_CARRER where c.ID == id select c;
                    COURSE_CARRER obj = courseCarrera.FirstOrDefault();

                    dataContext.COURSE_CARRER.Remove(obj);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<COURSE_CARRER> GetCourseCarrer()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var courseCarrera = from c in dataContext.COURSE_CARRER.Include("COURSE").Include("CAREER") select c;

                return courseCarrera.ToList();
            }
        }

        public List<COURSE_CARRER> GetCourseCarrer(int carrerID)
        {
            List<COURSE_CARRER> original = GetCourseCarrer();
            List<COURSE_CARRER> result = new List<COURSE_CARRER>();
            foreach(var item in original)
            {
                if(item.CarrerID==carrerID)
                {
                    result.Add(item);
                }
            }
            return result;
        }
    }
}
