﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.StudentCourseSections
{
    public class StudentCourseSectionRepository : IStudentCourseSectionRepository
    {
        public bool CreateStudentCourseSection(STUDENT__COURSE_SECTION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.STUDENT__COURSE_SECTION.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteStudentCourseSection(int StudentCourseSectionID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var StudentCourseSection = from c in dataContext.STUDENT__COURSE_SECTION
                                        where c.ID == StudentCourseSectionID
                                               select c;
                    STUDENT__COURSE_SECTION objStudentCourseSection = StudentCourseSection.FirstOrDefault();

                    dataContext.STUDENT__COURSE_SECTION.Remove(objStudentCourseSection);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteStudentCourseSection(int IDCourseSection, int IDStudent)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var StudentCourseSection = from c in dataContext.STUDENT__COURSE_SECTION
                                               where c.StudentID == IDStudent &&
                                               c.Course_SectionID == IDCourseSection
                                               select c;
                    STUDENT__COURSE_SECTION objStudentCourseSection = StudentCourseSection.FirstOrDefault();

                    dataContext.STUDENT__COURSE_SECTION.Remove(objStudentCourseSection);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<STUDENT__COURSE_SECTION> GetStudentCourseSection()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var StudentCourseSection = from c in dataContext.STUDENT__COURSE_SECTION.Include("STUDENT").Include("STUDENT.USER").Include("SCORE").Include("COURSE_SECTION").Include("COURSE_SECTION.COURSE").Include("COURSE_SECTION.SECTION")
                                           select c;

                return StudentCourseSection.ToList();
            }
        }

        public STUDENT__COURSE_SECTION GetStudentCourseSection(int id)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var scs = dataContext.STUDENT__COURSE_SECTION.First(i => i.ID == id);

                return scs;
            }
        }

        public List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXcsID(int csID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var scs = from c in dataContext.STUDENT__COURSE_SECTION.
                         Include("STUDENT.USER").
                         Include("STUDENT.CAREER")
                          where c.Course_SectionID.Equals(csID)
                          select c;

                return scs.ToList();
            }
        }

        public List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXTeacherID(int teacherID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var scs = from c in dataContext.STUDENT__COURSE_SECTION.
                         Include("STUDENT.USER").
                         Include("SCORE").
                         Include("COURSE_SECTION.TECHER_COURSE.COURSE").
                         Include("COURSE_SECTION.SECTION")
                          where c.COURSE_SECTION.TECHER_COURSE.TeacherID.Equals(teacherID)
                          select c;

                return scs.ToList();
            }
        }

        public bool UpdateStudentCourseSection(int id, int scoreID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var scs = dataContext.STUDENT__COURSE_SECTION.First(i => i.ID == id);
                    scs.ScoreID = scoreID;
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool ValidateData(int IDCourseSection, int IDStudent)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                
                var StudentCourseSection = from c in dataContext.STUDENT__COURSE_SECTION
                                           where c.StudentID == IDStudent &&
                                           c.Course_SectionID == IDCourseSection
                                           select c;
                STUDENT__COURSE_SECTION obj = StudentCourseSection.FirstOrDefault();
                if (obj != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
