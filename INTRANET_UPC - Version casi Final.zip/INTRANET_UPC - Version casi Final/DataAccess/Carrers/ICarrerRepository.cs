﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Carrers
{
    public interface ICarrerRepository
    {
        bool CreateCarrer(CAREER obj);
        bool UpdateCarrer(CAREER obj);
        bool DeleteCarrer(int carrerId);
        List<CAREER> GetCarrer();
    }
}
