﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.TeacherCourses
{
    public class TeacherCourseRepository : ITeacherCourseRepository
    {
       
        public bool CreateTeacherCourse(TECHER_COURSE obj)
        {
        
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.TECHER_COURSE.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteTeacherCourse(int teachercourseId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var courseTeacher = from c in dataContext.TECHER_COURSE where c.ID == teachercourseId select c;
                    TECHER_COURSE objCourseTeacher = courseTeacher.FirstOrDefault();

                    dataContext.TECHER_COURSE.Remove(objCourseTeacher);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<TECHER_COURSE> GetTeacherCourse()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var courseTeacher = from c in dataContext.TECHER_COURSE.Include("COURSE").Include("TEACHER") select c;

                return courseTeacher.ToList();
            }
        }

        public TECHER_COURSE GetTeacherCourseByIDs(int teacherID, int courseID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var courseTeacher = from c in dataContext.TECHER_COURSE
                                    where c.CourseID == courseID && c.TeacherID == teacherID
                                    select c;
                TECHER_COURSE obj = courseTeacher.FirstOrDefault();
                return obj;
            }
        }

        public List<TECHER_COURSE> ListTeacherXCourse(int courseID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var courseTeacher = from c in dataContext.TECHER_COURSE.Include("COURSE").Include("TEACHER")
                                    where c.CourseID == courseID select c;
               
                return courseTeacher.ToList();
            }
        }
    }
}
