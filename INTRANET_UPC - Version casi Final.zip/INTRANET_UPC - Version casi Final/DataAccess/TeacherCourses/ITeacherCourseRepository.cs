﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.TeacherCourses
{
    public interface ITeacherCourseRepository
    {
        bool CreateTeacherCourse(TECHER_COURSE obj);
        bool DeleteTeacherCourse(int teachercourseId);
        List<TECHER_COURSE> GetTeacherCourse();
        List<TECHER_COURSE> ListTeacherXCourse(int courseID);
        TECHER_COURSE GetTeacherCourseByIDs(int teacherID, int courseID);
    }
}
