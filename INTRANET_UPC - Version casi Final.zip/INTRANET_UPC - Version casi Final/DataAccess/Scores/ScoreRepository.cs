﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Scores
{
    public class ScoreRepository : IScoreRepository
    {
        public bool CreateScore(SCORE obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.SCOREs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteScore(int scoreID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var Score = from c in dataContext.SCOREs where c.ID == scoreID select c;

                    SCORE objScore = Score.FirstOrDefault();

                    dataContext.SCOREs.Remove(objScore);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public SCORE GetLastScore()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var Score = from c in dataContext.SCOREs select c;
                int id = 0;
                SCORE obj = new SCORE();
                foreach (var item in Score.ToList())
                {
                    if (item.ID > id)
                    {
                        obj = item;
                        id = item.ID;
                    }
                }
          
                return obj;
            }
        }

        public List<SCORE> GetScore()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var Score = from c in dataContext.SCOREs select c;

                return Score.ToList();
            }
        }
    }
}
