﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Areas
{
    public interface IAreaRepository
    {
        bool CreateArea(AREA obj);
        bool UpdateArea(AREA obj);
        bool DeleteArea(int areaId);
        AREA GetArea(int areaId);
        AREA GetArea(AREA areaDescription);
        List<AREA> GetArea();
    }
}
