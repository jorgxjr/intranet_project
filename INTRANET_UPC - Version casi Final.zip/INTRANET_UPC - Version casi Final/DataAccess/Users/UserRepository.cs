﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Users
{
    public class UserRepository : IUsersRepository
    {
        public bool CreateUser(USER obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.USERs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch(Exception e)
                {
                    
                    return false;
                }
            }
        }

        public bool DeleteUser(int userId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var user = from c in dataContext.USERs where c.ID == userId select c;
                    USER objUser = user.FirstOrDefault();

                    dataContext.USERs.Remove(objUser);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public USER GetUser(int userId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var user = from c in dataContext.USERs where c.ID == userId select c;
                USER objUser = user.FirstOrDefault();

                return objUser;
            }
        }

        public List<USER> GetUser()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var user = from c in dataContext.USERs select c;

                return user.ToList();
            }
        }

        public bool UpdateUser(USER obj)
        {
            throw new NotImplementedException();
        }
    }
}
