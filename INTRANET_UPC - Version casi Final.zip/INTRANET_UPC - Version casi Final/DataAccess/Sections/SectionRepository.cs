﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Sections
{
    public class SectionRepository : ISectionRepository
    {
        public bool CreateSection(SECTION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.SECTIONs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {

                    return false;
                }
            }
        }

        public bool DeleteSection(int sectionId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var section = from c in dataContext.SECTIONs where c.ID == sectionId select c;
                    SECTION objSection = section.FirstOrDefault();

                    dataContext.SECTIONs.Remove(objSection);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<SECTION> GetSection()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var section = from c in dataContext.SECTIONs select c;

                return section.ToList();
            }
        }
    }
}
