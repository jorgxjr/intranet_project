﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Scores
{
    public interface IScoreService
    {
        bool CreateScore(SCORE obj);
        bool DeleteScore(int scoreID);
        List<SCORE> GetScore();
        SCORE GetLastScore();
    }
}
