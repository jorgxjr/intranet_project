﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Users
{
    public interface IUserServices
    {
        bool CreateUser(USER obj);
        bool UpdateUser(USER obj);
        bool DeleteUser(int userId);
        USER GetUser(int userId);
        List<USER> GetUser();
    }
}
