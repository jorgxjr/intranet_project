﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.StudentCourseSections;
using ENTITIES;

namespace BusinessLogic.StudentCourseSections
{
    public class StudentCourseSectionService:IStudentCourseSectionService
    {
        IStudentCourseSectionRepository service = new StudentCourseSectionRepository();

        public bool CreateStudentCourseSection(STUDENT__COURSE_SECTION obj)
        {
            if (!service.ValidateData(obj.Course_SectionID, obj.StudentID))
            {
                return service.CreateStudentCourseSection(obj);
            }
            else { return false; }
        }

        public bool DeleteStudentCourseSection(int StudentCourseSectionID)
        {
            return service.DeleteStudentCourseSection(StudentCourseSectionID);
        }

        public bool DeleteStudentCourseSection(int IDCourseSection, int IDStudent)
        {
            return service.DeleteStudentCourseSection(IDCourseSection, IDStudent);
        }

        public List<STUDENT__COURSE_SECTION> GetStudentCourseSection()
        {
            return service.GetStudentCourseSection();
        }

        public STUDENT__COURSE_SECTION GetStudentCourseSection(int id)
        {
            return service.GetStudentCourseSection(id);
        }

        public List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXcsID(int csID)
        {
            return service.GetStudentCourseSectionXcsID(csID);
        }

        public List<STUDENT__COURSE_SECTION> GetStudentCourseSectionXTeacherID(int teacherID)
        {
            return service.GetStudentCourseSectionXTeacherID(teacherID);
        }

        public bool UpdateStudentCourseSection(int id, int scoreID)
        {
            return service.UpdateStudentCourseSection(id, scoreID);
        }

        public bool ValidateData(int IDCourseSection, int IDStudent)
        {
            return service.ValidateData(IDCourseSection, IDStudent);
        }
    }
}
