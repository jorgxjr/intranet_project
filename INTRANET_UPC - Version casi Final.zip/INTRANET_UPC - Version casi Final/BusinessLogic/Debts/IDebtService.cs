﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Debts
{
    public interface IDebtService
    {
        bool CreateDebt(DEBT obj);
        bool DeleteDebt(int debtId);
        List<DEBT> GetDebt();
    }
}
