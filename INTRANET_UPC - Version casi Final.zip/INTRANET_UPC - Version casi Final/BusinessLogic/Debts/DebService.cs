﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Debts;
using ENTITIES;

namespace BusinessLogic.Debts
{
    public class DebService : IDebtService
    {
        IDebtRepository service = new DebtRepository();

        public bool CreateDebt(DEBT obj)
        {
            return service.CreateDebt(obj);
        }

        public bool DeleteDebt(int debtId)
        {
            return service.DeleteDebt(debtId);
        }

        public List<DEBT> GetDebt()
        {
            return service.GetDebt();
        }
    }
}
