﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.Administrators;
using BusinessLogic.Students;
using BusinessLogic.Teachers;
using BusinessLogic.Users;
using ENTITIES;

namespace BusinessLogic.Methods
{
    public class Method : IMethod
    { 
        IUserServices serviceUser = new UserServices();
        IAdministratorService serviceAdministrator = new AdministratorService();
        ITeacherService servicTeacher = new TeacherService();
        IStudentService serviceStudent = new StudentService();
        Tuple<char, STUDENT, TEACHER, ADMINISTRATOR> tuple;
        ADMINISTRATOR a = null;
        STUDENT s = null;
        TEACHER t = null;
        char TypeOfUser;
        public Tuple<char, STUDENT, TEACHER, ADMINISTRATOR> GetTypeOfUser(int userID)
        {
            a = serviceAdministrator.GetAdministrator(userID);
            if (a != null) 
            {
                TypeOfUser = 'A';
            }
            else
            {
                t = servicTeacher.GetTeacher(userID);
                if (t != null)
                {
                    TypeOfUser = 'T';
                }
                else
                {
                    s = serviceStudent.GetStudent(userID);
                    TypeOfUser = 'S';
                }
            }
            tuple = new Tuple<char, STUDENT, TEACHER, ADMINISTRATOR>(TypeOfUser, s, t, a);
            return tuple;
        }

        public int ValidateUser(string UserName, string Password, out string error)
        {
            int reslut = -1;
            error = string.Empty;
            try
            {
                List<USER> lista;
                lista = serviceUser.GetUser();
                foreach (var c in lista)
                {
                    if (c.UserName == UserName && c.Pasword == Password)
                    {
                        reslut = c.ID;
                        break;
                    }
                }
            }
            catch(Exception e)
            {
                error = "There is a problem with the application or database. The more common error is the instance of the database. " +
                    "Please, try later.\n\n" + "Problem: " + e.Message;
            }
            return reslut;
        }
    }
}
