﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Teachers;
using ENTITIES;

namespace BusinessLogic.Teachers
{
    public class TeacherService : ITeacherService
    {
        ITeacherRepository teacherRepository = new TeacherRepository();

        public bool CreateTeacher(TEACHER obj)
        {
            if (obj.Profession != "" && obj.UniversityDegrees != "")
            {
                return teacherRepository.CreateTeacher(obj);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteTeacher(int teacherId)
        {
            return teacherRepository.DeleteTeacher(teacherId);
        }

        public TEACHER GetTeacher(int userID)
        {
            return teacherRepository.GetTeacher(userID);
        }

        public List<TEACHER> GetTeacher()
        {
            return teacherRepository.GetTeacher();
        }

        public TEACHER GetTeacherXID(int teacherID)
        {
            return teacherRepository.GetTeacherXID(teacherID);
        }

        public bool UpdateTeacher(TEACHER obj)
        {
            return teacherRepository.UpdateTeacher(obj);
        }
    }
}
