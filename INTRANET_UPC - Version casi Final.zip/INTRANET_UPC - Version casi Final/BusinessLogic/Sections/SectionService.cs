﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Sections;
using ENTITIES;

namespace BusinessLogic.Sections
{
    public class SectionService : ISectionService
    {
        ISectionRepository service = new SectionRepository();
        public bool CreateSection(SECTION obj)
        {
            if (obj.SectionName != "")
            {
                return service.CreateSection(obj);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteSection(int sectionId)
        {
            return service.DeleteSection(sectionId);
        }

        public List<SECTION> GetSection()
        {
            return service.GetSection();
        }
    }
}
