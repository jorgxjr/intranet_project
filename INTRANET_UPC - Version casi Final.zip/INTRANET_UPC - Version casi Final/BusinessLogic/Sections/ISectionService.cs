﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Sections
{
    public interface ISectionService
    {
        bool CreateSection(SECTION obj);
        bool DeleteSection(int sectionId);
        List<SECTION> GetSection();
    }
}
