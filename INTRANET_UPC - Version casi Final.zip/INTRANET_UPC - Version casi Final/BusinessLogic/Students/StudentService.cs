﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Students;
using ENTITIES;

namespace BusinessLogic.Students
{
    public class StudentService : IStudentService
    {
        IStudentRepository studentRepository = new StudentRepository();

        public bool CreateStudent(STUDENT obj)
        {
            if (obj.MaximumCredits > 0)
            {
                return studentRepository.CreateStudent(obj);
            }
            else
            {
                return false;
            }
        }

        public bool DeleteStudent(int studentId)
        {
            return studentRepository.DeleteStudent(studentId);
        }

        public STUDENT GetStudent(int studentrId)
        {
            return studentRepository.GetStudent(studentrId);
        }

        public List<STUDENT> GetStudent()
        {
            return studentRepository.GetStudent();
        }

        public bool UpdateStudent(STUDENT obj)
        {
            return studentRepository.UpdateStudent(obj);
        }
    }
}
