﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.CourseCarrers
{
    public interface ICourseCarrerService
    {
        bool CreatedCourseCarrer(COURSE_CARRER OB);
        bool DeleteCourseCarrer(int id);
        List<COURSE_CARRER> GetCourseCarrer();
        List<COURSE_CARRER> GetCourseCarrer(int carrerID);
    }
}
