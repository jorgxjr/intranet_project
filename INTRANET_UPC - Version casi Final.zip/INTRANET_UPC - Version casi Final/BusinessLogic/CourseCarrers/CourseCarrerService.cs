﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.CourseCarrers;
using ENTITIES;

namespace BusinessLogic.CourseCarrers
{
    public class CourseCarrerService:ICourseCarrerService
    {
        ICourseCarrerRepository service = new CourseCarrerRepository();

        public bool CreatedCourseCarrer(COURSE_CARRER OB)
        {
            return service.CreatedCourseCarrer(OB);
        }

        public bool DeleteCourseCarrer(int id)
        {
            return service.DeleteCourseCarrer(id);
        }

        public List<COURSE_CARRER> GetCourseCarrer()
        {
            return service.GetCourseCarrer();
        }

        public List<COURSE_CARRER> GetCourseCarrer(int carrerID)
        {
            return service.GetCourseCarrer(carrerID);
        }
    }
}
