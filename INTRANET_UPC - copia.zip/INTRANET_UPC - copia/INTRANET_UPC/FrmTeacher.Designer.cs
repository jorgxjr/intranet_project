﻿namespace INTRANET_UPC
{
    partial class FrmTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcTeacher = new System.Windows.Forms.TabControl();
            this.tbGrades = new System.Windows.Forms.TabPage();
            this.btnRegisterGrades = new System.Windows.Forms.Button();
            this.tlpGrades = new System.Windows.Forms.TableLayoutPanel();
            this.lblFE = new System.Windows.Forms.Label();
            this.txtFE = new System.Windows.Forms.TextBox();
            this.lblME = new System.Windows.Forms.Label();
            this.txtME = new System.Windows.Forms.TextBox();
            this.lblPC03 = new System.Windows.Forms.Label();
            this.txtPC03 = new System.Windows.Forms.TextBox();
            this.lblPC02 = new System.Windows.Forms.Label();
            this.txtPC02 = new System.Windows.Forms.TextBox();
            this.lblPC01 = new System.Windows.Forms.Label();
            this.txtPC01 = new System.Windows.Forms.TextBox();
            this.lblStudent = new System.Windows.Forms.Label();
            this.cbStudent = new System.Windows.Forms.ComboBox();
            this.lblSection = new System.Windows.Forms.Label();
            this.cbSection = new System.Windows.Forms.ComboBox();
            this.tbSections = new System.Windows.Forms.TabPage();
            this.gbStudentGrades = new System.Windows.Forms.GroupBox();
            this.dgvStudentGrades = new System.Windows.Forms.DataGridView();
            this.lblSectionList = new System.Windows.Forms.Label();
            this.cbSectionList = new System.Windows.Forms.ComboBox();
            this.dgvStudentBySection = new System.Windows.Forms.DataGridView();
            this.gbStudentsBySection = new System.Windows.Forms.GroupBox();
            this.gbControls = new System.Windows.Forms.GroupBox();
            this.tlpSections = new System.Windows.Forms.TableLayoutPanel();
            this.tbcTeacher.SuspendLayout();
            this.tbGrades.SuspendLayout();
            this.tlpGrades.SuspendLayout();
            this.tbSections.SuspendLayout();
            this.gbStudentGrades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentGrades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentBySection)).BeginInit();
            this.gbStudentsBySection.SuspendLayout();
            this.gbControls.SuspendLayout();
            this.tlpSections.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcTeacher
            // 
            this.tbcTeacher.Controls.Add(this.tbGrades);
            this.tbcTeacher.Controls.Add(this.tbSections);
            this.tbcTeacher.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcTeacher.Location = new System.Drawing.Point(0, 0);
            this.tbcTeacher.Name = "tbcTeacher";
            this.tbcTeacher.SelectedIndex = 0;
            this.tbcTeacher.Size = new System.Drawing.Size(485, 510);
            this.tbcTeacher.TabIndex = 0;
            // 
            // tbGrades
            // 
            this.tbGrades.Controls.Add(this.gbControls);
            this.tbGrades.Controls.Add(this.gbStudentGrades);
            this.tbGrades.Controls.Add(this.tlpGrades);
            this.tbGrades.Location = new System.Drawing.Point(4, 22);
            this.tbGrades.Name = "tbGrades";
            this.tbGrades.Padding = new System.Windows.Forms.Padding(3);
            this.tbGrades.Size = new System.Drawing.Size(477, 484);
            this.tbGrades.TabIndex = 0;
            this.tbGrades.Text = "Grades";
            this.tbGrades.UseVisualStyleBackColor = true;
            // 
            // btnRegisterGrades
            // 
            this.btnRegisterGrades.Location = new System.Drawing.Point(177, 19);
            this.btnRegisterGrades.Name = "btnRegisterGrades";
            this.btnRegisterGrades.Size = new System.Drawing.Size(106, 23);
            this.btnRegisterGrades.TabIndex = 1;
            this.btnRegisterGrades.Text = "Register Grades";
            this.btnRegisterGrades.UseVisualStyleBackColor = true;
            // 
            // tlpGrades
            // 
            this.tlpGrades.ColumnCount = 2;
            this.tlpGrades.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.66438F));
            this.tlpGrades.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 81.33562F));
            this.tlpGrades.Controls.Add(this.lblFE, 0, 6);
            this.tlpGrades.Controls.Add(this.txtFE, 1, 6);
            this.tlpGrades.Controls.Add(this.lblME, 0, 5);
            this.tlpGrades.Controls.Add(this.txtME, 1, 5);
            this.tlpGrades.Controls.Add(this.lblPC03, 0, 4);
            this.tlpGrades.Controls.Add(this.txtPC03, 1, 4);
            this.tlpGrades.Controls.Add(this.lblPC02, 0, 3);
            this.tlpGrades.Controls.Add(this.txtPC02, 1, 3);
            this.tlpGrades.Controls.Add(this.lblPC01, 0, 2);
            this.tlpGrades.Controls.Add(this.txtPC01, 1, 2);
            this.tlpGrades.Controls.Add(this.lblStudent, 0, 1);
            this.tlpGrades.Controls.Add(this.cbStudent, 1, 1);
            this.tlpGrades.Controls.Add(this.lblSection, 0, 0);
            this.tlpGrades.Controls.Add(this.cbSection, 1, 0);
            this.tlpGrades.Dock = System.Windows.Forms.DockStyle.Top;
            this.tlpGrades.Location = new System.Drawing.Point(3, 3);
            this.tlpGrades.Name = "tlpGrades";
            this.tlpGrades.RowCount = 7;
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28713F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28713F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28713F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28713F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28713F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28355F));
            this.tlpGrades.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28082F));
            this.tlpGrades.Size = new System.Drawing.Size(471, 196);
            this.tlpGrades.TabIndex = 0;
            // 
            // lblFE
            // 
            this.lblFE.AutoSize = true;
            this.lblFE.Location = new System.Drawing.Point(3, 167);
            this.lblFE.Name = "lblFE";
            this.lblFE.Size = new System.Drawing.Size(61, 13);
            this.lblFE.TabIndex = 10;
            this.lblFE.Text = "Final Exam:";
            // 
            // txtFE
            // 
            this.txtFE.Location = new System.Drawing.Point(90, 170);
            this.txtFE.Name = "txtFE";
            this.txtFE.Size = new System.Drawing.Size(100, 20);
            this.txtFE.TabIndex = 30;
            // 
            // lblME
            // 
            this.lblME.AutoSize = true;
            this.lblME.Location = new System.Drawing.Point(3, 140);
            this.lblME.Name = "lblME";
            this.lblME.Size = new System.Drawing.Size(76, 13);
            this.lblME.TabIndex = 4;
            this.lblME.Text = "Midterm Exam:";
            // 
            // txtME
            // 
            this.txtME.Location = new System.Drawing.Point(90, 143);
            this.txtME.Name = "txtME";
            this.txtME.Size = new System.Drawing.Size(100, 20);
            this.txtME.TabIndex = 25;
            // 
            // lblPC03
            // 
            this.lblPC03.AutoSize = true;
            this.lblPC03.Location = new System.Drawing.Point(3, 112);
            this.lblPC03.Name = "lblPC03";
            this.lblPC03.Size = new System.Drawing.Size(33, 13);
            this.lblPC03.TabIndex = 3;
            this.lblPC03.Text = "PC03";
            // 
            // txtPC03
            // 
            this.txtPC03.Location = new System.Drawing.Point(90, 115);
            this.txtPC03.Name = "txtPC03";
            this.txtPC03.Size = new System.Drawing.Size(100, 20);
            this.txtPC03.TabIndex = 20;
            // 
            // lblPC02
            // 
            this.lblPC02.AutoSize = true;
            this.lblPC02.Location = new System.Drawing.Point(3, 84);
            this.lblPC02.Name = "lblPC02";
            this.lblPC02.Size = new System.Drawing.Size(33, 13);
            this.lblPC02.TabIndex = 2;
            this.lblPC02.Text = "PC02";
            // 
            // txtPC02
            // 
            this.txtPC02.Location = new System.Drawing.Point(90, 87);
            this.txtPC02.Name = "txtPC02";
            this.txtPC02.Size = new System.Drawing.Size(100, 20);
            this.txtPC02.TabIndex = 15;
            // 
            // lblPC01
            // 
            this.lblPC01.AutoSize = true;
            this.lblPC01.Location = new System.Drawing.Point(3, 56);
            this.lblPC01.Name = "lblPC01";
            this.lblPC01.Size = new System.Drawing.Size(33, 13);
            this.lblPC01.TabIndex = 1;
            this.lblPC01.Text = "PC01";
            // 
            // txtPC01
            // 
            this.txtPC01.Location = new System.Drawing.Point(90, 59);
            this.txtPC01.Name = "txtPC01";
            this.txtPC01.Size = new System.Drawing.Size(100, 20);
            this.txtPC01.TabIndex = 10;
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Location = new System.Drawing.Point(3, 28);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(47, 13);
            this.lblStudent.TabIndex = 0;
            this.lblStudent.Text = "Student:";
            // 
            // cbStudent
            // 
            this.cbStudent.FormattingEnabled = true;
            this.cbStudent.Location = new System.Drawing.Point(90, 31);
            this.cbStudent.Name = "cbStudent";
            this.cbStudent.Size = new System.Drawing.Size(265, 21);
            this.cbStudent.TabIndex = 5;
            // 
            // lblSection
            // 
            this.lblSection.AutoSize = true;
            this.lblSection.Location = new System.Drawing.Point(3, 0);
            this.lblSection.Name = "lblSection";
            this.lblSection.Size = new System.Drawing.Size(46, 13);
            this.lblSection.TabIndex = 12;
            this.lblSection.Text = "Section:";
            // 
            // cbSection
            // 
            this.cbSection.DisplayMember = "SectionID";
            this.cbSection.FormattingEnabled = true;
            this.cbSection.Location = new System.Drawing.Point(90, 3);
            this.cbSection.Name = "cbSection";
            this.cbSection.Size = new System.Drawing.Size(121, 21);
            this.cbSection.TabIndex = 1;
            this.cbSection.ValueMember = "ID";
            // 
            // tbSections
            // 
            this.tbSections.Controls.Add(this.tlpSections);
            this.tbSections.Controls.Add(this.gbStudentsBySection);
            this.tbSections.Location = new System.Drawing.Point(4, 22);
            this.tbSections.Name = "tbSections";
            this.tbSections.Padding = new System.Windows.Forms.Padding(3);
            this.tbSections.Size = new System.Drawing.Size(477, 484);
            this.tbSections.TabIndex = 1;
            this.tbSections.Text = "Sections";
            this.tbSections.UseVisualStyleBackColor = true;
            // 
            // gbStudentGrades
            // 
            this.gbStudentGrades.Controls.Add(this.dgvStudentGrades);
            this.gbStudentGrades.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gbStudentGrades.Location = new System.Drawing.Point(3, 262);
            this.gbStudentGrades.Name = "gbStudentGrades";
            this.gbStudentGrades.Size = new System.Drawing.Size(471, 219);
            this.gbStudentGrades.TabIndex = 1;
            this.gbStudentGrades.TabStop = false;
            this.gbStudentGrades.Text = "Students";
            // 
            // dgvStudentGrades
            // 
            this.dgvStudentGrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudentGrades.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStudentGrades.Location = new System.Drawing.Point(3, 16);
            this.dgvStudentGrades.Name = "dgvStudentGrades";
            this.dgvStudentGrades.Size = new System.Drawing.Size(465, 200);
            this.dgvStudentGrades.TabIndex = 0;
            // 
            // lblSectionList
            // 
            this.lblSectionList.AutoSize = true;
            this.lblSectionList.Location = new System.Drawing.Point(3, 0);
            this.lblSectionList.Name = "lblSectionList";
            this.lblSectionList.Size = new System.Drawing.Size(46, 13);
            this.lblSectionList.TabIndex = 0;
            this.lblSectionList.Text = "Section:";
            // 
            // cbSectionList
            // 
            this.cbSectionList.DisplayMember = "SectionID";
            this.cbSectionList.FormattingEnabled = true;
            this.cbSectionList.Location = new System.Drawing.Point(68, 3);
            this.cbSectionList.Name = "cbSectionList";
            this.cbSectionList.Size = new System.Drawing.Size(136, 21);
            this.cbSectionList.TabIndex = 1;
            this.cbSectionList.ValueMember = "ID";
            // 
            // dgvStudentBySection
            // 
            this.dgvStudentBySection.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudentBySection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStudentBySection.Location = new System.Drawing.Point(3, 16);
            this.dgvStudentBySection.Name = "dgvStudentBySection";
            this.dgvStudentBySection.Size = new System.Drawing.Size(465, 361);
            this.dgvStudentBySection.TabIndex = 2;
            // 
            // gbStudentsBySection
            // 
            this.gbStudentsBySection.Controls.Add(this.dgvStudentBySection);
            this.gbStudentsBySection.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gbStudentsBySection.Location = new System.Drawing.Point(3, 101);
            this.gbStudentsBySection.Name = "gbStudentsBySection";
            this.gbStudentsBySection.Size = new System.Drawing.Size(471, 380);
            this.gbStudentsBySection.TabIndex = 3;
            this.gbStudentsBySection.TabStop = false;
            this.gbStudentsBySection.Text = "Students";
            // 
            // gbControls
            // 
            this.gbControls.Controls.Add(this.btnRegisterGrades);
            this.gbControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbControls.Location = new System.Drawing.Point(3, 199);
            this.gbControls.Name = "gbControls";
            this.gbControls.Size = new System.Drawing.Size(471, 63);
            this.gbControls.TabIndex = 2;
            this.gbControls.TabStop = false;
            // 
            // tlpSections
            // 
            this.tlpSections.ColumnCount = 3;
            this.tlpSections.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.96078F));
            this.tlpSections.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.03922F));
            this.tlpSections.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 229F));
            this.tlpSections.Controls.Add(this.lblSectionList, 0, 0);
            this.tlpSections.Controls.Add(this.cbSectionList, 1, 0);
            this.tlpSections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSections.Location = new System.Drawing.Point(3, 3);
            this.tlpSections.Name = "tlpSections";
            this.tlpSections.RowCount = 2;
            this.tlpSections.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSections.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSections.Size = new System.Drawing.Size(471, 98);
            this.tlpSections.TabIndex = 4;
            // 
            // FrmTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 510);
            this.Controls.Add(this.tbcTeacher);
            this.MaximizeBox = false;
            this.Name = "FrmTeacher";
            this.Text = "Teacher";
            this.Load += new System.EventHandler(this.FrmTeacher_Load);
            this.tbcTeacher.ResumeLayout(false);
            this.tbGrades.ResumeLayout(false);
            this.tlpGrades.ResumeLayout(false);
            this.tlpGrades.PerformLayout();
            this.tbSections.ResumeLayout(false);
            this.gbStudentGrades.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentGrades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudentBySection)).EndInit();
            this.gbStudentsBySection.ResumeLayout(false);
            this.gbControls.ResumeLayout(false);
            this.tlpSections.ResumeLayout(false);
            this.tlpSections.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcTeacher;
        private System.Windows.Forms.TabPage tbGrades;
        private System.Windows.Forms.TabPage tbSections;
        private System.Windows.Forms.TableLayoutPanel tlpGrades;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblPC01;
        private System.Windows.Forms.Label lblPC02;
        private System.Windows.Forms.Label lblPC03;
        private System.Windows.Forms.Label lblME;
        private System.Windows.Forms.ComboBox cbStudent;
        private System.Windows.Forms.TextBox txtPC01;
        private System.Windows.Forms.TextBox txtPC02;
        private System.Windows.Forms.TextBox txtPC03;
        private System.Windows.Forms.TextBox txtME;
        private System.Windows.Forms.Label lblFE;
        private System.Windows.Forms.TextBox txtFE;
        private System.Windows.Forms.Button btnRegisterGrades;
        private System.Windows.Forms.GroupBox gbStudentGrades;
        private System.Windows.Forms.DataGridView dgvStudentGrades;
        private System.Windows.Forms.Label lblSection;
        private System.Windows.Forms.ComboBox cbSection;
        private System.Windows.Forms.GroupBox gbStudentsBySection;
        private System.Windows.Forms.DataGridView dgvStudentBySection;
        private System.Windows.Forms.ComboBox cbSectionList;
        private System.Windows.Forms.Label lblSectionList;
        private System.Windows.Forms.GroupBox gbControls;
        private System.Windows.Forms.TableLayoutPanel tlpSections;
    }
}