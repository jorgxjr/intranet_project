﻿namespace INTRANET_UPC
{
    partial class FrmAdministrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tab1 = new System.Windows.Forms.TabControl();
            this.tabUsers = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabAdministrators = new System.Windows.Forms.TabPage();
            this.dGVAdministrators = new System.Windows.Forms.DataGridView();
            this.btnAdministratorUpdate = new System.Windows.Forms.Button();
            this.btnAdministratorDelete = new System.Windows.Forms.Button();
            this.btnAdministratorAdd = new System.Windows.Forms.Button();
            this.txtWokArea = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabTeachers = new System.Windows.Forms.TabPage();
            this.dGVTeacher = new System.Windows.Forms.DataGridView();
            this.btnTeacherUpdate = new System.Windows.Forms.Button();
            this.btnTeacherDelete = new System.Windows.Forms.Button();
            this.btnTeacherAdd = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabStudents = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.cbxForeigner = new System.Windows.Forms.CheckBox();
            this.cbCarrer = new System.Windows.Forms.ComboBox();
            this.txtMaximumCredits = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.dTPDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.txtDni = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabCourses = new System.Windows.Forms.TabPage();
            this.txtCourseID = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.dGVCourse = new System.Windows.Forms.DataGridView();
            this.cOURSEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnCourseUpdate = new System.Windows.Forms.Button();
            this.btnCourseDelete = new System.Windows.Forms.Button();
            this.btnCourseAdd = new System.Windows.Forms.Button();
            this.cbxArea = new System.Windows.Forms.ComboBox();
            this.cbxObligatory = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtCredits = new System.Windows.Forms.TextBox();
            this.txtCourseName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabArea = new System.Windows.Forms.TabPage();
            this.dGVArea = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteArea = new System.Windows.Forms.DataGridViewButtonColumn();
            this.UpdateArea = new System.Windows.Forms.DataGridViewButtonColumn();
            this.aREABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnAreaAdd = new System.Windows.Forms.Button();
            this.txtAreaDescription = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.aREABindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CourseArea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obligatoryDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.creditDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteCourse = new System.Windows.Forms.DataGridViewButtonColumn();
            this.UpdateCourse = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tab1.SuspendLayout();
            this.tabUsers.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabAdministrators.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVAdministrators)).BeginInit();
            this.tabTeachers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVTeacher)).BeginInit();
            this.tabStudents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabCourses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVCourse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSEBindingSource)).BeginInit();
            this.tabArea.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tab1
            // 
            this.tab1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tab1.Controls.Add(this.tabUsers);
            this.tab1.Controls.Add(this.tabCourses);
            this.tab1.Controls.Add(this.tabArea);
            this.tab1.Location = new System.Drawing.Point(6, 19);
            this.tab1.Name = "tab1";
            this.tab1.SelectedIndex = 0;
            this.tab1.Size = new System.Drawing.Size(765, 558);
            this.tab1.TabIndex = 1;
            // 
            // tabUsers
            // 
            this.tabUsers.Controls.Add(this.groupBox2);
            this.tabUsers.Controls.Add(this.rbtnMale);
            this.tabUsers.Controls.Add(this.rbtnFemale);
            this.tabUsers.Controls.Add(this.dTPDateOfBirth);
            this.tabUsers.Controls.Add(this.txtDni);
            this.tabUsers.Controls.Add(this.txtPassword);
            this.tabUsers.Controls.Add(this.txtUserName);
            this.tabUsers.Controls.Add(this.txtLastName);
            this.tabUsers.Controls.Add(this.txtName);
            this.tabUsers.Controls.Add(this.txtID);
            this.tabUsers.Controls.Add(this.label9);
            this.tabUsers.Controls.Add(this.label10);
            this.tabUsers.Controls.Add(this.label11);
            this.tabUsers.Controls.Add(this.label12);
            this.tabUsers.Controls.Add(this.label13);
            this.tabUsers.Controls.Add(this.label14);
            this.tabUsers.Controls.Add(this.label15);
            this.tabUsers.Controls.Add(this.label16);
            this.tabUsers.Location = new System.Drawing.Point(4, 22);
            this.tabUsers.Name = "tabUsers";
            this.tabUsers.Padding = new System.Windows.Forms.Padding(3);
            this.tabUsers.Size = new System.Drawing.Size(757, 532);
            this.tabUsers.TabIndex = 2;
            this.tabUsers.Text = "Users";
            this.tabUsers.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Location = new System.Drawing.Point(6, 158);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(627, 368);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Types of Users";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabAdministrators);
            this.tabControl1.Controls.Add(this.tabTeachers);
            this.tabControl1.Controls.Add(this.tabStudents);
            this.tabControl1.Location = new System.Drawing.Point(6, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(615, 343);
            this.tabControl1.TabIndex = 0;
            // 
            // tabAdministrators
            // 
            this.tabAdministrators.Controls.Add(this.dGVAdministrators);
            this.tabAdministrators.Controls.Add(this.btnAdministratorUpdate);
            this.tabAdministrators.Controls.Add(this.btnAdministratorDelete);
            this.tabAdministrators.Controls.Add(this.btnAdministratorAdd);
            this.tabAdministrators.Controls.Add(this.txtWokArea);
            this.tabAdministrators.Controls.Add(this.label1);
            this.tabAdministrators.Location = new System.Drawing.Point(4, 22);
            this.tabAdministrators.Name = "tabAdministrators";
            this.tabAdministrators.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdministrators.Size = new System.Drawing.Size(607, 317);
            this.tabAdministrators.TabIndex = 0;
            this.tabAdministrators.Text = "Administrators";
            this.tabAdministrators.UseVisualStyleBackColor = true;
            // 
            // dGVAdministrators
            // 
            this.dGVAdministrators.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVAdministrators.Location = new System.Drawing.Point(6, 86);
            this.dGVAdministrators.Name = "dGVAdministrators";
            this.dGVAdministrators.Size = new System.Drawing.Size(595, 225);
            this.dGVAdministrators.TabIndex = 31;
            // 
            // btnAdministratorUpdate
            // 
            this.btnAdministratorUpdate.Location = new System.Drawing.Point(354, 55);
            this.btnAdministratorUpdate.Name = "btnAdministratorUpdate";
            this.btnAdministratorUpdate.Size = new System.Drawing.Size(72, 25);
            this.btnAdministratorUpdate.TabIndex = 30;
            this.btnAdministratorUpdate.Text = "Update";
            this.btnAdministratorUpdate.UseVisualStyleBackColor = true;
            // 
            // btnAdministratorDelete
            // 
            this.btnAdministratorDelete.Location = new System.Drawing.Point(263, 55);
            this.btnAdministratorDelete.Name = "btnAdministratorDelete";
            this.btnAdministratorDelete.Size = new System.Drawing.Size(72, 25);
            this.btnAdministratorDelete.TabIndex = 29;
            this.btnAdministratorDelete.Text = "Delete";
            this.btnAdministratorDelete.UseVisualStyleBackColor = true;
            // 
            // btnAdministratorAdd
            // 
            this.btnAdministratorAdd.Location = new System.Drawing.Point(176, 55);
            this.btnAdministratorAdd.Name = "btnAdministratorAdd";
            this.btnAdministratorAdd.Size = new System.Drawing.Size(72, 25);
            this.btnAdministratorAdd.TabIndex = 28;
            this.btnAdministratorAdd.Text = "Add";
            this.btnAdministratorAdd.UseVisualStyleBackColor = true;
            // 
            // txtWokArea
            // 
            this.txtWokArea.Location = new System.Drawing.Point(99, 17);
            this.txtWokArea.Name = "txtWokArea";
            this.txtWokArea.Size = new System.Drawing.Size(199, 20);
            this.txtWokArea.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Work Area";
            // 
            // tabTeachers
            // 
            this.tabTeachers.Controls.Add(this.dGVTeacher);
            this.tabTeachers.Controls.Add(this.btnTeacherUpdate);
            this.tabTeachers.Controls.Add(this.btnTeacherDelete);
            this.tabTeachers.Controls.Add(this.btnTeacherAdd);
            this.tabTeachers.Controls.Add(this.textBox1);
            this.tabTeachers.Controls.Add(this.textBox2);
            this.tabTeachers.Controls.Add(this.label2);
            this.tabTeachers.Controls.Add(this.label3);
            this.tabTeachers.Location = new System.Drawing.Point(4, 22);
            this.tabTeachers.Name = "tabTeachers";
            this.tabTeachers.Padding = new System.Windows.Forms.Padding(3);
            this.tabTeachers.Size = new System.Drawing.Size(607, 317);
            this.tabTeachers.TabIndex = 1;
            this.tabTeachers.Text = "Teachers";
            this.tabTeachers.UseVisualStyleBackColor = true;
            // 
            // dGVTeacher
            // 
            this.dGVTeacher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVTeacher.Location = new System.Drawing.Point(7, 86);
            this.dGVTeacher.Name = "dGVTeacher";
            this.dGVTeacher.Size = new System.Drawing.Size(595, 225);
            this.dGVTeacher.TabIndex = 35;
            // 
            // btnTeacherUpdate
            // 
            this.btnTeacherUpdate.Location = new System.Drawing.Point(355, 55);
            this.btnTeacherUpdate.Name = "btnTeacherUpdate";
            this.btnTeacherUpdate.Size = new System.Drawing.Size(72, 25);
            this.btnTeacherUpdate.TabIndex = 34;
            this.btnTeacherUpdate.Text = "Update";
            this.btnTeacherUpdate.UseVisualStyleBackColor = true;
            // 
            // btnTeacherDelete
            // 
            this.btnTeacherDelete.Location = new System.Drawing.Point(264, 55);
            this.btnTeacherDelete.Name = "btnTeacherDelete";
            this.btnTeacherDelete.Size = new System.Drawing.Size(72, 25);
            this.btnTeacherDelete.TabIndex = 33;
            this.btnTeacherDelete.Text = "Delete";
            this.btnTeacherDelete.UseVisualStyleBackColor = true;
            // 
            // btnTeacherAdd
            // 
            this.btnTeacherAdd.Location = new System.Drawing.Point(177, 55);
            this.btnTeacherAdd.Name = "btnTeacherAdd";
            this.btnTeacherAdd.Size = new System.Drawing.Size(72, 25);
            this.btnTeacherAdd.TabIndex = 32;
            this.btnTeacherAdd.Text = "Add";
            this.btnTeacherAdd.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(402, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(199, 20);
            this.textBox1.TabIndex = 31;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(95, 16);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(199, 20);
            this.textBox2.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(300, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "University Degrees";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Profession";
            // 
            // tabStudents
            // 
            this.tabStudents.Controls.Add(this.dataGridView1);
            this.tabStudents.Controls.Add(this.button1);
            this.tabStudents.Controls.Add(this.button2);
            this.tabStudents.Controls.Add(this.button3);
            this.tabStudents.Controls.Add(this.cbxForeigner);
            this.tabStudents.Controls.Add(this.cbCarrer);
            this.tabStudents.Controls.Add(this.txtMaximumCredits);
            this.tabStudents.Controls.Add(this.label7);
            this.tabStudents.Controls.Add(this.label4);
            this.tabStudents.Controls.Add(this.label5);
            this.tabStudents.Location = new System.Drawing.Point(4, 22);
            this.tabStudents.Name = "tabStudents";
            this.tabStudents.Padding = new System.Windows.Forms.Padding(3);
            this.tabStudents.Size = new System.Drawing.Size(607, 317);
            this.tabStudents.TabIndex = 2;
            this.tabStudents.Text = "Students";
            this.tabStudents.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 111);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(595, 200);
            this.dataGridView1.TabIndex = 39;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(351, 78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 25);
            this.button1.TabIndex = 38;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(260, 78);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(72, 25);
            this.button2.TabIndex = 37;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(173, 78);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(72, 25);
            this.button3.TabIndex = 36;
            this.button3.Text = "Add";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // cbxForeigner
            // 
            this.cbxForeigner.AutoSize = true;
            this.cbxForeigner.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbxForeigner.Location = new System.Drawing.Point(99, 50);
            this.cbxForeigner.Name = "cbxForeigner";
            this.cbxForeigner.Size = new System.Drawing.Size(44, 17);
            this.cbxForeigner.TabIndex = 35;
            this.cbxForeigner.Text = "Yes";
            this.cbxForeigner.UseVisualStyleBackColor = true;
            // 
            // cbCarrer
            // 
            this.cbCarrer.FormattingEnabled = true;
            this.cbCarrer.Location = new System.Drawing.Point(99, 14);
            this.cbCarrer.Name = "cbCarrer";
            this.cbCarrer.Size = new System.Drawing.Size(199, 21);
            this.cbCarrer.TabIndex = 34;
            // 
            // txtMaximumCredits
            // 
            this.txtMaximumCredits.Location = new System.Drawing.Point(402, 15);
            this.txtMaximumCredits.Name = "txtMaximumCredits";
            this.txtMaximumCredits.Size = new System.Drawing.Size(199, 20);
            this.txtMaximumCredits.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(310, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "Maximum Credits";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "Foreigner";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "Carrer";
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.Location = new System.Drawing.Point(493, 25);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(48, 17);
            this.rbtnMale.TabIndex = 33;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = true;
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.Location = new System.Drawing.Point(418, 25);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(59, 17);
            this.rbtnFemale.TabIndex = 32;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = true;
            // 
            // dTPDateOfBirth
            // 
            this.dTPDateOfBirth.Location = new System.Drawing.Point(115, 116);
            this.dTPDateOfBirth.Name = "dTPDateOfBirth";
            this.dTPDateOfBirth.Size = new System.Drawing.Size(199, 20);
            this.dTPDateOfBirth.TabIndex = 31;
            // 
            // txtDni
            // 
            this.txtDni.Location = new System.Drawing.Point(418, 114);
            this.txtDni.Name = "txtDni";
            this.txtDni.Size = new System.Drawing.Size(199, 20);
            this.txtDni.TabIndex = 30;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(418, 81);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(199, 20);
            this.txtPassword.TabIndex = 29;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(418, 53);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(199, 20);
            this.txtUserName.TabIndex = 28;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(115, 86);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(199, 20);
            this.txtLastName.TabIndex = 27;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(115, 54);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(199, 20);
            this.txtName.TabIndex = 26;
            // 
            // txtID
            // 
            this.txtID.Enabled = false;
            this.txtID.Location = new System.Drawing.Point(115, 25);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(199, 20);
            this.txtID.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(369, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "DNI";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(342, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "Password";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(335, 60);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "User Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(353, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "Gender";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(26, 123);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "Date of Birth";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(34, 93);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Last Name";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(57, 61);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Name";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(74, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(18, 13);
            this.label16.TabIndex = 17;
            this.label16.Text = "ID";
            // 
            // tabCourses
            // 
            this.tabCourses.Controls.Add(this.txtCourseID);
            this.tabCourses.Controls.Add(this.label19);
            this.tabCourses.Controls.Add(this.dGVCourse);
            this.tabCourses.Controls.Add(this.btnCourseUpdate);
            this.tabCourses.Controls.Add(this.btnCourseDelete);
            this.tabCourses.Controls.Add(this.btnCourseAdd);
            this.tabCourses.Controls.Add(this.cbxArea);
            this.tabCourses.Controls.Add(this.cbxObligatory);
            this.tabCourses.Controls.Add(this.label18);
            this.tabCourses.Controls.Add(this.txtCredits);
            this.tabCourses.Controls.Add(this.txtCourseName);
            this.tabCourses.Controls.Add(this.label6);
            this.tabCourses.Controls.Add(this.label8);
            this.tabCourses.Controls.Add(this.label17);
            this.tabCourses.Location = new System.Drawing.Point(4, 22);
            this.tabCourses.Name = "tabCourses";
            this.tabCourses.Padding = new System.Windows.Forms.Padding(3);
            this.tabCourses.Size = new System.Drawing.Size(757, 532);
            this.tabCourses.TabIndex = 3;
            this.tabCourses.Text = "Courses";
            this.tabCourses.UseVisualStyleBackColor = true;
            // 
            // txtCourseID
            // 
            this.txtCourseID.Enabled = false;
            this.txtCourseID.Location = new System.Drawing.Point(94, 23);
            this.txtCourseID.Name = "txtCourseID";
            this.txtCourseID.Size = new System.Drawing.Size(199, 20);
            this.txtCourseID.TabIndex = 45;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Location = new System.Drawing.Point(36, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 13);
            this.label19.TabIndex = 44;
            this.label19.Text = "ID";
            // 
            // dGVCourse
            // 
            this.dGVCourse.AutoGenerateColumns = false;
            this.dGVCourse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVCourse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.CourseArea,
            this.nameDataGridViewTextBoxColumn,
            this.obligatoryDataGridViewCheckBoxColumn,
            this.creditDataGridViewTextBoxColumn,
            this.DeleteCourse,
            this.UpdateCourse});
            this.dGVCourse.DataSource = this.cOURSEBindingSource;
            this.dGVCourse.Location = new System.Drawing.Point(6, 149);
            this.dGVCourse.Name = "dGVCourse";
            this.dGVCourse.Size = new System.Drawing.Size(743, 377);
            this.dGVCourse.TabIndex = 43;
            this.dGVCourse.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGVCourse_CellClick);
            // 
            // cOURSEBindingSource
            // 
            this.cOURSEBindingSource.DataSource = typeof(ENTITIES.COURSE);
            // 
            // btnCourseUpdate
            // 
            this.btnCourseUpdate.Location = new System.Drawing.Point(289, 80);
            this.btnCourseUpdate.Name = "btnCourseUpdate";
            this.btnCourseUpdate.Size = new System.Drawing.Size(72, 25);
            this.btnCourseUpdate.TabIndex = 42;
            this.btnCourseUpdate.Text = "Update";
            this.btnCourseUpdate.UseVisualStyleBackColor = true;
            this.btnCourseUpdate.Click += new System.EventHandler(this.btnCourseUpdate_Click);
            // 
            // btnCourseDelete
            // 
            this.btnCourseDelete.Location = new System.Drawing.Point(198, 80);
            this.btnCourseDelete.Name = "btnCourseDelete";
            this.btnCourseDelete.Size = new System.Drawing.Size(72, 25);
            this.btnCourseDelete.TabIndex = 41;
            this.btnCourseDelete.Text = "Delete";
            this.btnCourseDelete.UseVisualStyleBackColor = true;
            // 
            // btnCourseAdd
            // 
            this.btnCourseAdd.Location = new System.Drawing.Point(638, 39);
            this.btnCourseAdd.Name = "btnCourseAdd";
            this.btnCourseAdd.Size = new System.Drawing.Size(72, 25);
            this.btnCourseAdd.TabIndex = 40;
            this.btnCourseAdd.Text = "Add";
            this.btnCourseAdd.UseVisualStyleBackColor = true;
            this.btnCourseAdd.Click += new System.EventHandler(this.btnCourseAdd_Click);
            // 
            // cbxArea
            // 
            this.cbxArea.DisplayMember = "Description";
            this.cbxArea.FormattingEnabled = true;
            this.cbxArea.Location = new System.Drawing.Point(393, 54);
            this.cbxArea.Name = "cbxArea";
            this.cbxArea.Size = new System.Drawing.Size(199, 21);
            this.cbxArea.TabIndex = 38;
            this.cbxArea.ValueMember = "ID";
            // 
            // cbxObligatory
            // 
            this.cbxObligatory.AutoSize = true;
            this.cbxObligatory.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbxObligatory.Location = new System.Drawing.Point(94, 85);
            this.cbxObligatory.Name = "cbxObligatory";
            this.cbxObligatory.Size = new System.Drawing.Size(44, 17);
            this.cbxObligatory.TabIndex = 37;
            this.cbxObligatory.Text = "Yes";
            this.cbxObligatory.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(17, 89);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 13);
            this.label18.TabIndex = 36;
            this.label18.Text = "Obligatory";
            // 
            // txtCredits
            // 
            this.txtCredits.Location = new System.Drawing.Point(393, 23);
            this.txtCredits.Name = "txtCredits";
            this.txtCredits.Size = new System.Drawing.Size(199, 20);
            this.txtCredits.TabIndex = 32;
            // 
            // txtCourseName
            // 
            this.txtCourseName.Location = new System.Drawing.Point(94, 55);
            this.txtCourseName.Name = "txtCourseName";
            this.txtCourseName.Size = new System.Drawing.Size(199, 20);
            this.txtCourseName.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(341, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "Area";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(331, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "Credits";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(36, 62);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "Name";
            // 
            // tabArea
            // 
            this.tabArea.Controls.Add(this.dGVArea);
            this.tabArea.Controls.Add(this.btnAreaAdd);
            this.tabArea.Controls.Add(this.txtAreaDescription);
            this.tabArea.Controls.Add(this.label21);
            this.tabArea.Location = new System.Drawing.Point(4, 22);
            this.tabArea.Name = "tabArea";
            this.tabArea.Padding = new System.Windows.Forms.Padding(3);
            this.tabArea.Size = new System.Drawing.Size(757, 532);
            this.tabArea.TabIndex = 4;
            this.tabArea.Text = "Area";
            this.tabArea.UseVisualStyleBackColor = true;
            // 
            // dGVArea
            // 
            this.dGVArea.AutoGenerateColumns = false;
            this.dGVArea.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVArea.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn1,
            this.descriptionDataGridViewTextBoxColumn,
            this.DeleteArea,
            this.UpdateArea});
            this.dGVArea.DataSource = this.aREABindingSource;
            this.dGVArea.Location = new System.Drawing.Point(110, 91);
            this.dGVArea.Name = "dGVArea";
            this.dGVArea.Size = new System.Drawing.Size(525, 427);
            this.dGVArea.TabIndex = 53;
            this.dGVArea.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGVArea_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn1
            // 
            this.iDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn1.Name = "iDDataGridViewTextBoxColumn1";
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 180;
            // 
            // DeleteArea
            // 
            this.DeleteArea.HeaderText = "Delete";
            this.DeleteArea.Name = "DeleteArea";
            // 
            // UpdateArea
            // 
            this.UpdateArea.HeaderText = "Update";
            this.UpdateArea.Name = "UpdateArea";
            // 
            // aREABindingSource
            // 
            this.aREABindingSource.DataSource = typeof(ENTITIES.AREA);
            // 
            // btnAreaAdd
            // 
            this.btnAreaAdd.Location = new System.Drawing.Point(464, 19);
            this.btnAreaAdd.Name = "btnAreaAdd";
            this.btnAreaAdd.Size = new System.Drawing.Size(72, 25);
            this.btnAreaAdd.TabIndex = 50;
            this.btnAreaAdd.Text = "Add";
            this.btnAreaAdd.UseVisualStyleBackColor = true;
            this.btnAreaAdd.Click += new System.EventHandler(this.btnAreaAdd_Click);
            // 
            // txtAreaDescription
            // 
            this.txtAreaDescription.Location = new System.Drawing.Point(255, 24);
            this.txtAreaDescription.Name = "txtAreaDescription";
            this.txtAreaDescription.Size = new System.Drawing.Size(188, 20);
            this.txtAreaDescription.TabIndex = 47;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(177, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 13);
            this.label21.TabIndex = 46;
            this.label21.Text = "Description";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.tab1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(777, 583);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Magnament";
            // 
            // aREABindingSource1
            // 
            this.aREABindingSource1.DataSource = typeof(ENTITIES.AREA);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // CourseArea
            // 
            this.CourseArea.DataPropertyName = "CourseArea";
            this.CourseArea.HeaderText = "Area";
            this.CourseArea.Name = "CourseArea";
            this.CourseArea.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // obligatoryDataGridViewCheckBoxColumn
            // 
            this.obligatoryDataGridViewCheckBoxColumn.DataPropertyName = "Obligatory";
            this.obligatoryDataGridViewCheckBoxColumn.HeaderText = "Obligatory";
            this.obligatoryDataGridViewCheckBoxColumn.Name = "obligatoryDataGridViewCheckBoxColumn";
            // 
            // creditDataGridViewTextBoxColumn
            // 
            this.creditDataGridViewTextBoxColumn.DataPropertyName = "Credit";
            this.creditDataGridViewTextBoxColumn.HeaderText = "Credit";
            this.creditDataGridViewTextBoxColumn.Name = "creditDataGridViewTextBoxColumn";
            // 
            // DeleteCourse
            // 
            this.DeleteCourse.HeaderText = "Delete";
            this.DeleteCourse.Name = "DeleteCourse";
            // 
            // UpdateCourse
            // 
            this.UpdateCourse.HeaderText = "Update";
            this.UpdateCourse.Name = "UpdateCourse";
            // 
            // FrmAdministrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 607);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "FrmAdministrator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administrator";
            this.Load += new System.EventHandler(this.FrmAdministrator_Load);
            this.tab1.ResumeLayout(false);
            this.tabUsers.ResumeLayout(false);
            this.tabUsers.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabAdministrators.ResumeLayout(false);
            this.tabAdministrators.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVAdministrators)).EndInit();
            this.tabTeachers.ResumeLayout(false);
            this.tabTeachers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVTeacher)).EndInit();
            this.tabStudents.ResumeLayout(false);
            this.tabStudents.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabCourses.ResumeLayout(false);
            this.tabCourses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVCourse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cOURSEBindingSource)).EndInit();
            this.tabArea.ResumeLayout(false);
            this.tabArea.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGVArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aREABindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tab1;
        private System.Windows.Forms.TabPage tabUsers;
        private System.Windows.Forms.TabPage tabCourses;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabAdministrators;
        private System.Windows.Forms.TabPage tabTeachers;
        private System.Windows.Forms.TabPage tabStudents;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.DateTimePicker dTPDateOfBirth;
        private System.Windows.Forms.TextBox txtDni;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView dGVAdministrators;
        private System.Windows.Forms.Button btnAdministratorUpdate;
        private System.Windows.Forms.Button btnAdministratorDelete;
        private System.Windows.Forms.Button btnAdministratorAdd;
        private System.Windows.Forms.TextBox txtWokArea;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dGVTeacher;
        private System.Windows.Forms.Button btnTeacherUpdate;
        private System.Windows.Forms.Button btnTeacherDelete;
        private System.Windows.Forms.Button btnTeacherAdd;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox cbxForeigner;
        private System.Windows.Forms.ComboBox cbCarrer;
        private System.Windows.Forms.TextBox txtMaximumCredits;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCourseID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView dGVCourse;
        private System.Windows.Forms.Button btnCourseUpdate;
        private System.Windows.Forms.Button btnCourseDelete;
        private System.Windows.Forms.Button btnCourseAdd;
        private System.Windows.Forms.ComboBox cbxArea;
        private System.Windows.Forms.CheckBox cbxObligatory;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtCredits;
        private System.Windows.Forms.TextBox txtCourseName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.BindingSource cOURSEBindingSource;
        private System.Windows.Forms.TabPage tabArea;
        private System.Windows.Forms.TextBox txtAreaDescription;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView dGVArea;
        private System.Windows.Forms.BindingSource aREABindingSource;
        private System.Windows.Forms.Button btnAreaAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteArea;
        private System.Windows.Forms.DataGridViewButtonColumn UpdateArea;
        private System.Windows.Forms.BindingSource aREABindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CourseArea;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn obligatoryDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn creditDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteCourse;
        private System.Windows.Forms.DataGridViewButtonColumn UpdateCourse;
    }
}