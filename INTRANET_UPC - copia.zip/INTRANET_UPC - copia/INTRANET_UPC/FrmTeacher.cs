﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ENTITIES;
using BusinessLogic.Scores;
using BusinessLogic.Student_Course_Section;
using BusinessLogic.Teachers;
using BusinessLogic.Course_Section;
using BusinessLogic.Teacher_Course;

namespace INTRANET_UPC
{
    public partial class FrmTeacher : Form
    {
        public TEACHER objTeacher;
        
        //public TECHER_COURSE objTC;
        IScoreService servScore;
        ISCSService servSCS;
        ITeacherService servTeacher;
        ICSService servCS;
        ITCService servTC;
        List<COURSE_SECTION> sections;
        List<STUDENT__COURSE_SECTION> students;
        public FrmTeacher(int UserID)
        {
            InitializeComponent();
            servScore = new ScoreService();
            servSCS = new SCSService();
            servTeacher = new TeacherService();
            servCS = new CSService();
            servTC = new TCService();
            
            objTeacher = servTeacher.GetTeacherByUserID(UserID);
            //objTC = servTC.GetTCByTeacherID(objTeacher.ID);

        }

        private void FrmTeacher_Load(object sender, EventArgs e)
        {
            //cargo las secciones asociadas al profesor, usando una lista de Course-Section
            sections = servCS.GetListCSByTeacherID(objTeacher.ID);
            cbSection.DataSource = sections;
            cbSection.SelectedIndex = 0;

            cbSectionList.DataSource = sections;
            cbSectionList.SelectedIndex = 0;

            this.LoadStudentGrades();

            //cargo los estudiantes asociados a la sección seleccionada???, uso lista de Student-Course-Section
            //students =
            //    servSCS.GetListSCSByCSID(Convert.ToInt32(cbSection.SelectedValue));
            //cbStudent.DataSource = students;
            //cbStudent.SelectedIndex = 0;
        }

        private void btnRegisterGrades_Click(object sender, EventArgs e)
        {
            SCORE objScore = new SCORE();
            objScore.PC01 = Convert.ToInt32(txtPC01.Text);
            objScore.PC02 = Convert.ToInt32(txtPC02.Text);
            objScore.PC03 = Convert.ToInt32(txtPC03.Text);
            objScore.MidtermExam = Convert.ToInt32(txtME.Text);
            objScore.FinalExam = Convert.ToInt32(txtFE.Text);
            servScore.CreateScore(objScore);
            
            SCORE lastScore = servScore.GetLastScore();
            STUDENT__COURSE_SECTION selectedSCS =
                servSCS.GetSCS(Convert.ToInt32(cbStudent.SelectedValue));
            servSCS.UpdateSCS(selectedSCS.ID, lastScore.ID);
            this.LoadStudentGrades();
        }

        private void LoadStudentGrades()
        {
            students = servSCS.GetListSCS();
            dgvStudentGrades.DataSource = students;
        }
        private void LoadStudentBySection()
        {
            students = servSCS.GetListSCSByCSID(Convert.ToInt32(cbSectionList.SelectedValue));
            dgvStudentBySection.DataSource = students;
        }

        private void cbStudent_SelectedValueChanged(object sender, EventArgs e)
        {
            //students = servSCS.GetListSCSByCSID(Convert.ToInt32(cbSection.SelectedValue));
            //cbStudent.DataSource = students;
            //cbStudent.SelectedIndex = 0;
        }

        private void cbSection_SelectedValueChanged(object sender, EventArgs e)
        {
            //students = servSCS.GetListSCSByCSID(Convert.ToInt32(cbSection.SelectedValue));
            //cbStudent.DataSource = students;
            //cbStudent.SelectedIndex = 0;
        }

        private void cbSection_SelectedIndexChanged(object sender, EventArgs e)
        {
            students = servSCS.GetListSCSByCSID(Convert.ToInt32(cbSection.SelectedValue));
            cbStudent.DataSource = students;
        }

        private void btnShowStudents_Click(object sender, EventArgs e)
        {
            this.LoadStudentBySection();
        }
    }
}
