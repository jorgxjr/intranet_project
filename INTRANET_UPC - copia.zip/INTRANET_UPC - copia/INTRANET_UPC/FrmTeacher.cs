﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ENTITIES;
using BusinessLogic.Scores;
using BusinessLogic.Student_Course_Section;
using BusinessLogic.Teachers;
using BusinessLogic.Course_Section;
using BusinessLogic.Teacher_Course;

namespace INTRANET_UPC
{
    public partial class FrmTeacher : Form
    {
        public TEACHER objTeacher;
        public SCORE objScore;
        //public TECHER_COURSE objTC;
        IScoreService servScore;
        ISCSService servSCS;
        ITeacherService servTeacher;
        ICSService servCS;
        ITCService servTC;
        public FrmTeacher(int UserID)
        {
            InitializeComponent();
            servScore = new ScoreService();
            servSCS = new SCSService();
            servTeacher = new TeacherService();
            servCS = new CSService();
            servTC = new TCService();
            objScore = new SCORE();
            objTeacher = servTeacher.GetTeacherByUserID(UserID);
            //objTC = servTC.GetTCByTeacherID(objTeacher.ID);

        }

        private void FrmTeacher_Load(object sender, EventArgs e)
        {
            //List<COURSE_SECTION> sections = servCS.GetListCSByTCID(objTC.ID);
            List<COURSE_SECTION> sections = servCS.GetListCSByTeacherID(objTeacher.ID);
            cbSection.DataSource = sections;
            cbSection.SelectedIndex = 0;
            cbSectionList.DataSource = sections;
            cbSectionList.SelectedIndex = 0;
        }
    }
}
