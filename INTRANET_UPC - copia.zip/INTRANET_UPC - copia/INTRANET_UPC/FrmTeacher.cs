﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ENTITIES;
using BusinessLogic.Scores;
using BusinessLogic.Student_Course_Section;

namespace INTRANET_UPC
{
    public partial class FrmTeacher : Form
    {
        public TEACHER objTeacher;
        public SCORE objScore;
        IScoreService servScore;
        ISCSService servSCS;
        public FrmTeacher()
        {
            InitializeComponent();
            objScore = new SCORE();
            servScore = new ScoreService();
            servSCS = new SCSService();
            //objTeacher = new TEACHER();
        }
    }
}
