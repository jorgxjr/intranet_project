﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.Areas;
using BusinessLogic.Courses;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmAdministrator : Form
    {
        public ADMINISTRATOR OBJAdministrator;
        List<COURSE> listaCourse;
        List<AREA> listaArea;
        ICourseService courseService = new CourseService();
        IAreaService areaService = new AreaService();
        AREA areaDeleteOrUpdate = null;
        COURSE courseDeleteOrUpdate = null;

        //constructor
        public FrmAdministrator()
        {
            InitializeComponent();
        }

        //LOAD
        private void FrmAdministrator_Load(object sender, EventArgs e)
        {
            listaArea = areaService.GetArea();
            DataSource_Course();
            DataSource_Area();
            cbxArea.DataSource = listaArea;
        }


        /////////////////////////////////////////////////////////////////////
        //////////////// AREA
        ////////////////////////////////////////////////////////////////////

        //carga de datos de la grilla de area
        void DataSource_Area()
        {
            listaArea = areaService.GetArea();
            dGVArea.DataSource = listaArea;
        }


        //limpiar datos de area
        void Clear_data_Area()
        {
            txtAreaDescription.Clear();
            txtAreaDescription.Focus();
        }


        //cargar datos de area de la grilla seleccionada de area
        void load_Area(AREA obj)
        {
            txtAreaDescription.Text = Convert.ToString(obj.Description);
        }
        //guardar cambios en area
        void save_area(AREA obj)
        {
            obj.Description = txtAreaDescription.Text;
        }


        //eliminar o actualizar 
        private void dGVArea_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            bool flag;
            if (dGVArea.Columns[e.ColumnIndex].HeaderText.ToLower() == "delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    areaDeleteOrUpdate = (AREA)dGVArea.Rows[e.RowIndex].DataBoundItem;
                    flag = areaService.DeleteArea(areaDeleteOrUpdate.ID);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to eliminate, because there is a course with this area id. First, delete that course and try again");
                    }
                    DataSource_Area();
                    cbxArea.DataSource = listaArea;
                }
                Clear_data_Area();
            }
            else if (dGVArea.Columns[e.ColumnIndex].HeaderText.ToLower() == "update")
            {
                if (MessageBox.Show("Are you sure you want to update this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    areaDeleteOrUpdate = (AREA)dGVArea.Rows[e.RowIndex].DataBoundItem;
                    flag = areaService.UpdateArea(areaDeleteOrUpdate);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to update repeated data or empty data");
                    }
                    DataSource_Area();
                    cbxArea.DataSource = listaArea;
                }
                Clear_data_Area();
            }
        }

        //agregar area
        private void btnAreaAdd_Click(object sender, EventArgs e)
        {
            AREA objArea = new AREA();
            save_area(objArea);
            bool flag = areaService.CreateArea(objArea);
            if (flag)
            {
                DataSource_Area();
                cbxArea.DataSource = listaArea;
            }
            else
            {
                MessageBox.Show("It is not possible to save repeated data or empty data");
            }
            Clear_data_Area();
        }



        /////////////////////////////////////////////////////////////////////
        //////////////// CURSOS
        ////////////////////////////////////////////////////////////////////

        //carga de datos de la grilla de cursos
        void DataSource_Course()
        {
            listaCourse = courseService.GetCourse();
            dGVCourse.DataSource = listaCourse;
        }
        //limpiar datos de curso
        void Clear_data_Course()
        {
            txtCourseID.Clear();
            txtCourseName.Clear();
            txtCredits.Clear();
            cbxObligatory.Checked = false;
            courseDeleteOrUpdate = null;
        }

        //cargar datos de area de la grilla seleccionada de cursos
        void load_Course(COURSE obj)
        {
            txtCourseID.Text = Convert.ToString(obj.ID);
            txtCourseName.Text = obj.Name;
            txtCredits.Text = Convert.ToString(obj.Credit);
            cbxObligatory.Checked = obj.Obligatory;
            cbxArea.SelectedValue = obj.AreaID;
        }

        //guardar cambios en area
        void save_Course(COURSE obj)
        {
            if (txtCredits.Text != "" && txtCourseName.Text != "")
            {
                obj.Name = txtCourseName.Text;
                obj.Credit = Convert.ToInt32(txtCredits.Text);
                obj.Obligatory = cbxObligatory.Checked;
                obj.AreaID = Convert.ToInt32(cbxArea.SelectedValue);
            }
            else{
                obj = null;
            }
        }


        // determinar objeto seleccionado de la grilla
        private void dGVCourse_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dGVCourse.Columns[e.ColumnIndex].HeaderText.ToLower() == "id")
            {
                courseDeleteOrUpdate = (COURSE)dGVCourse.Rows[e.RowIndex].DataBoundItem;
                load_Course(courseDeleteOrUpdate);
            }
        }

        //agregar curso
        private void btnCourseAdd_Click(object sender, EventArgs e)
        {
            courseDeleteOrUpdate = null;
            COURSE objCourse = new COURSE();
            save_Course(objCourse);

            bool flag = courseService.CreateCourse(objCourse);
            if (flag)
            {
                DataSource_Course();
            }
            else
            {
                MessageBox.Show("It is not possible to save repeated data or empty data");
            }
            Clear_data_Course();
        }

        private void btnCourseUpdate_Click(object sender, EventArgs e)
        {
            if (courseDeleteOrUpdate != null)
            {
                if (MessageBox.Show("Are you sure you want to update this record?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    // areaDeleteOrUpdate.Description = txtAreaDescription.Text;
                    save_Course(courseDeleteOrUpdate);
                    bool flag = courseService.UpdateCourse(courseDeleteOrUpdate);
                    if (!flag)
                    {
                        MessageBox.Show("It is not possible to update repeated data or empty data");
                    }
                    DataSource_Course();
                }
                Clear_data_Course();
            }
            else
            {
                MessageBox.Show("It is not possible to update empty data. Select a data");
            }
        }
    }
}
