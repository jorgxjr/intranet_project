﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogic.Methods;
using BusinessLogic.Users;
using ENTITIES;

namespace INTRANET_UPC
{
    public partial class FrmLogin : Form
    {
        private String UserName;
        private String Password;
        IMethod serviceMethod = new Method();
        Tuple<char, STUDENT, TEACHER, ADMINISTRATOR> tupleUser;
        FrmAdministrator formAdministrator;
        FrmStudent formStudent;
        FrmTeacher formTeacher;
        int UserID;
        string error = string.Empty;
        public FrmLogin()
        {
            InitializeComponent();
            lblMessage.Visible = false;
            UserID = -1;
        }

        private void ClearLabels()
        {
            txtUserName.Clear();
            txtPassword.Clear();
            txtUserName.Focus();
        }

        private void CreateForm()
        {
            tupleUser = serviceMethod.GetTypeOfUser(UserID);
            this.Visible = false;
            switch(tupleUser.Item1)
            {
                case 'A':
                    formAdministrator = new FrmAdministrator();
                    formAdministrator.OBJAdministrator = tupleUser.Item4;
                    formAdministrator.ShowDialog();
                    break;
                case 'S':
                    formStudent = new FrmStudent();
                    formStudent.OBJStudent = tupleUser.Item2;
                    formStudent.ShowDialog();
                    break;
                case 'T':
                    formTeacher = new FrmTeacher();
                    formTeacher.OBJTeacher = tupleUser.Item3;
                    formStudent.ShowDialog();
                    break;
            }
            this.Visible = true;
        }

        private void btnLoggin_Click(object sender, EventArgs e)
        {
            UserName = txtUserName.Text;
            Password = txtPassword.Text;
            
            UserID = serviceMethod.ValidateUser(UserName, Password, out error);
            if (UserID != -1)
            {
                lblMessage.Visible = false;
                ClearLabels();
                CreateForm();
            }
            else
            {
                if (error == "")
                {
                    lblMessage.Visible = true;
                    ClearLabels();
                }
                else
                {
                    MessageBox.Show(error, "ERROR");
                }
            }
        }
    }
}
