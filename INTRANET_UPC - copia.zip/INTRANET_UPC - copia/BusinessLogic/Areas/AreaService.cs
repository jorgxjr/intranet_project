﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.Courses;
using DataAccess.Areas;
using ENTITIES;

namespace BusinessLogic.Areas
{
    public class AreaService : IAreaService
    {
        IAreaRepository areaRepository = new AreaRepository();
        ICourseService coursoServices = new CourseService();

        public bool CreateArea(AREA obj)
        {
            if (obj.Description != "" && GetArea(obj) == null)
            {
                return areaRepository.CreateArea(obj);
            }
            return false;
        }

        public bool DeleteArea(int areaId)
        {
            if (coursoServices.GetCourse_AreaID(areaId) == null)
            {
                return areaRepository.DeleteArea(areaId);
            }
            return false;
        }

        public AREA GetArea(int areaId)
        {
            return areaRepository.GetArea(areaId);
        }

        public List<AREA> GetArea()
        {
            return areaRepository.GetArea();
        }

        public bool UpdateArea(AREA obj)
        {
            if (GetArea(obj) == null && obj.Description != "") 
            {
                return areaRepository.UpdateArea(obj);
            }
            return false;
        }

        private AREA GetArea(AREA description)
        {
            return areaRepository.GetArea(description);
        }
    }
}
