﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Areas
{
    public interface IAreaService
    {
        bool CreateArea(AREA obj);
        bool UpdateArea(AREA obj);
        bool DeleteArea(int areaId);
        AREA GetArea(int areaId);
        List<AREA> GetArea();
    }
}
