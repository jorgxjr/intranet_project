﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Users;
using ENTITIES;

namespace BusinessLogic.Users
{
    public class UserServices : IUserServices
    {
        IUsersRepository Repository = new UserRepository();
        public bool CreateUser(USER obj)
        {
            return Repository.CreateUser(obj);
        }

        public bool DeleteUser(int userId)
        {
            return Repository.DeleteUser(userId);
        }

        public USER GetUser(int userId)
        {
            return Repository.GetUser(userId);
        }

        public List<USER> GetUser()
        {
            return Repository.GetUser();
        }

        public bool UpdateUser(USER obj)
        {
            return Repository.UpdateUser(obj);
        }
    }
}
