﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace BusinessLogic.Students
{
    public interface IStudentService
    {
        bool CreateStudent(STUDENT obj);
        bool UpdateStudent(STUDENT obj);
        bool DeleteStudent(int studentId);
        STUDENT GetStudent(int studentrId);
        List<STUDENT> GetStudent();
    }
}
