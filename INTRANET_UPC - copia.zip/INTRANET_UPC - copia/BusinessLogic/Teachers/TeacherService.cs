﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Teachers;
using ENTITIES;

namespace BusinessLogic.Teachers
{
    public class TeacherService : ITeacherService
    {
        ITeacherRepository teacherRepository = new TeacherRepository();

        public bool CreateTeacher(TEACHER obj)
        {
            return teacherRepository.CreateTeacher(obj);
        }

        public bool DeleteTeacher(int teacherId)
        {
            return teacherRepository.DeleteTeacher(teacherId);
        }

        public TEACHER GetTeacher(int teacherId)
        {
            return teacherRepository.GetTeacher(teacherId);
        }

        public List<TEACHER> GetTeacher()
        {
            return teacherRepository.GetTeacher();
        }

        public bool UpdateTeacher(TEACHER obj)
        {
            return teacherRepository.UpdateTeacher(obj);
        }

        public TEACHER GetTeacherByUserID(int userId)
        {
            return teacherRepository.GetTeacher(userId);
        }
    }
}
