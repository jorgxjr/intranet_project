﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;
using DataAccess.Scores;

namespace BusinessLogic.Scores
{
    public class ScoreService : IScoreService
    {
        public bool CreateScore(SCORE obj)
        {
            IScoreRepository repository = new ScoreRepository();
            return repository.CreateScore(obj);
        }

        public SCORE GetScore(int id)
        {
            throw new NotImplementedException();
        }

        public List<SCORE> GetScores()
        {
            throw new NotImplementedException();
        }
    }
}
