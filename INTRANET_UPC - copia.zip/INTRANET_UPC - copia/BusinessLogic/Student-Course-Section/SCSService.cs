﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;
using DataAccess.Student_Course_Section;

namespace BusinessLogic.Student_Course_Section
{
    public class SCSService : ISCSService
    {
        public bool CreateSCS(STUDENT__COURSE_SECTION obj)
        {
            ISCSRepository repository = new SCSRepository();
            return repository.CreateSCS(obj);
        }

        public List<STUDENT__COURSE_SECTION> GetListSCS()
        {
            ISCSRepository repository = new SCSRepository();
            return repository.GetListSCS();
        }

        public List<STUDENT__COURSE_SECTION> GetListSCSByCSID(int csID)
        {
            ISCSRepository repository = new SCSRepository();
            return repository.GetListSCSByCSID(csID);
        }

        public List<STUDENT__COURSE_SECTION> GetListSCSByTeacherID(int teacherID)
        {
            ISCSRepository repository = new SCSRepository();
            return repository.GetListSCSByTeacherID(teacherID);
        }

        public STUDENT__COURSE_SECTION GetSCS(int id)
        {
            ISCSRepository repository = new SCSRepository();
            return repository.GetSCS(id);
        }
        public bool UpdateSCS(int id, int scoreID)
        {
            ISCSRepository repository = new SCSRepository();
            return repository.UpdateSCS(id, scoreID);
        }
    }
}
