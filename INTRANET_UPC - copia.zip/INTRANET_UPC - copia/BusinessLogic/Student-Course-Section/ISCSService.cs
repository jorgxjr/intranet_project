﻿using ENTITIES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Student_Course_Section
{
    public interface ISCSService
    {
        bool CreateSCS(STUDENT__COURSE_SECTION obj);
        STUDENT__COURSE_SECTION GetSCS(int id);
        List<STUDENT__COURSE_SECTION> GetListSCS();
        List<STUDENT__COURSE_SECTION> GetListSCSByCSID(int csID);
        bool UpdateSCS(int id, int scoreID);
    }
}
