﻿using ENTITIES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Course_Section
{
    public interface ICSService
    {
        bool CreateCS(COURSE_SECTION obj);
        COURSE_SECTION GetCS(int id);
        List<COURSE_SECTION> GetListCS();
        List<COURSE_SECTION> GetListCSByTCID(int tcID);
        List<COURSE_SECTION> GetListCSByTeacherID(int teacherID);
    }
}
