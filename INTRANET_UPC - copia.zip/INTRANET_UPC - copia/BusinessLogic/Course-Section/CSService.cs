﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;
using DataAccess.Course_Section;

namespace BusinessLogic.Course_Section
{
    public class CSService : ICSService
    {
        public bool CreateCS(COURSE_SECTION obj)
        {
            ICSRepository repository = new CSRepository();
            return repository.CreateCS(obj);
        }

        public COURSE_SECTION GetCS(int id)
        {
            throw new NotImplementedException();
        }

        public List<COURSE_SECTION> GetListCS()
        {
            ICSRepository repository = new CSRepository();
            return repository.GetListCS();
        }

        public List<COURSE_SECTION> GetListCSByTCID(int tcID)
        {
            ICSRepository repository = new CSRepository();
            return repository.GetListCSByTCID(tcID);
        }

        public List<COURSE_SECTION> GetListCSByTeacherID(int teacherID)
        {
            ICSRepository repository = new CSRepository();
            return repository.GetListCSByTeacherID(teacherID);
        }
    }
}
