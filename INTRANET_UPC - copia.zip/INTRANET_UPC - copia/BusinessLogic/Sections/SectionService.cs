﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;
using DataAccess.Sections;

namespace BusinessLogic.Sections
{
    public class SectionService : ISectionService
    {
        public bool CreateSection(SECTION obj)
        {
            ISectionRepository repository = new SectionRepository();
            return repository.CreateSection(obj);
        }

        public SECTION GetSection(int id)
        {
            throw new NotImplementedException();
        }

        public List<SECTION> GetSections()
        {
            ISectionRepository repository = new SectionRepository();
            return repository.GetSections();
        }
    }
}
