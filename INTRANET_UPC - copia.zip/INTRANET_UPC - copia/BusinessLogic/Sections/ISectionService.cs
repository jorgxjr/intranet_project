﻿using ENTITIES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Sections
{
    public interface ISectionService
    {
        bool CreateSection(SECTION obj);
        SECTION GetSection(int id);
        List<SECTION> GetSections();
    }
}
