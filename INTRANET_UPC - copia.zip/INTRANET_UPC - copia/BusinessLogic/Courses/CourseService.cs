﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Courses;
using ENTITIES;

namespace BusinessLogic.Courses
{
    public class CourseService : ICourseService
    {
        ICourseRepository courseRepository = new CourseRepository();
        public bool CreateCourse(COURSE obj)
        {
            if (GetCourse(obj.Name) == null)
            {
                return courseRepository.CreateCourse(obj);
            }
            return false;
        }

        public bool DeleteCourse(int courseId)
        {
            return courseRepository.DeleteCourse(courseId);
        }

        public COURSE GetCourse(int courseId)
        {
            return courseRepository.GetCourse(courseId);
        }

        public List<COURSE> GetCourse()
        {
            return courseRepository.GetCourse();
        }

        public COURSE GetCourse(string courseName)
        {
            return courseRepository.GetCourse(courseName);
        }

        public COURSE GetCourse_AreaID(int areaId)
        {
            return courseRepository.GetCourse_AreaID(areaId);
        }

        public bool UpdateCourse(COURSE obj)
        {
            if (GetCourse(obj.Name) == null)
            {
                return courseRepository.UpdateCourse(obj);
            }
            else
            {
                return false;
            }
        }
    }
}
