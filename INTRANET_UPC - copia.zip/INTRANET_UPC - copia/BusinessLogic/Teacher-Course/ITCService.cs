﻿using ENTITIES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Teacher_Course
{
    public interface ITCService
    {
        TECHER_COURSE GetTCByTeacherID(int teacherID);
    }
}
