﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;
using DataAccess.Teacher_Course;

namespace BusinessLogic.Teacher_Course
{
    public class TCService : ITCService
    {
        public TECHER_COURSE GetTCByTeacherID(int teacherID)
        {
            ITCRepository repository = new TCRepository();
            return repository.GetTCByTeacherID(teacherID);
        }
    }
}
