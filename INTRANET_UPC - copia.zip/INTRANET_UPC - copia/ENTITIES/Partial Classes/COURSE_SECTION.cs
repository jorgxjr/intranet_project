﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class COURSE_SECTION
    {
        public string SectionName
        {
            set { }
            get
            {
                return this.SECTION.SectionName;
            }
        }
        public int TeacherID
        {
            set { }
            get
            {
                return this.TECHER_COURSE.TeacherID;
            }
        }
    }
}
