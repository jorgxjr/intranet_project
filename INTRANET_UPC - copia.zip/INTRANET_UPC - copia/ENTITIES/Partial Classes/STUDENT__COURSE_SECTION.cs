﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class STUDENT__COURSE_SECTION
    {
        public string UserName
        {
            set { }
            get
            {
                return this.STUDENT.USER.UserName;
            }
        }
        public string FullName
        {
            set { }
            get
            {
                return this.STUDENT.USER.Name + " " + this.STUDENT.USER.LastName;
            }
        }
        public string SectionCourse
        {
            set { }
            get
            {
                return this.COURSE_SECTION.SECTION.SectionName + " " +
                    this.COURSE_SECTION.TECHER_COURSE.COURSE.Name;
            }
        }
        public decimal PC01
        {
            set { }
            get
            {
                return this.SCORE.PC01;
            }
        }
        public decimal PC02
        {
            set { }
            get
            {
                return this.SCORE.PC02;
            }
        }
        public decimal PC03
        {
            set { }
            get
            {
                return this.SCORE.PC03;
            }
        }
        public decimal MidtermExam
        {
            set { }
            get
            {
                return this.SCORE.MidtermExam;
            }
        }
        public decimal FinalExam
        {
            set { }
            get
            {
                return this.SCORE.FinalExam;
            }
        }
        public string CareerName
        {
            set { }
            get
            {
                return this.STUDENT.CAREER.Name;
            }
        }
    }
}
