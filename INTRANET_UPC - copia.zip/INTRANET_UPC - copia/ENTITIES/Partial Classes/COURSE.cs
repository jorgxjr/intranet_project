﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class COURSE
    {
        public string CourseArea
        {
            set
            {
                //nothing at all
            }
            get
            {
                return this.AREA.Description;
            }
        }
    }
}
