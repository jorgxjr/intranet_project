﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public partial class STUDENT
    {
        public string FullName
        {
            set { }
            get
            {
                return this.USER.LastName;
            }
        }
    }
}
