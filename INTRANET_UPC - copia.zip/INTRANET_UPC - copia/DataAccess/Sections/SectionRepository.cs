﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Sections
{
    public class SectionRepository : ISectionRepository
    {
        public bool CreateSection(SECTION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.SECTIONs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public SECTION GetSection(int id)
        {
            throw new NotImplementedException();
        }

        public List<SECTION> GetSections()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var sections = from c in dataContext.SECTIONs select c;

                return sections.ToList();
            }
        }
    }
}
