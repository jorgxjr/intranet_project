﻿using ENTITIES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Sections
{
    public interface ISectionRepository
    {
        bool CreateSection(SECTION obj);
        SECTION GetSection(int id);
        List<SECTION> GetSections();
    }
}
