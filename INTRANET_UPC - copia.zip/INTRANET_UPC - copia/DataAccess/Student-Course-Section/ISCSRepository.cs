﻿using ENTITIES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Student_Course_Section
{
    public interface ISCSRepository
    {
        bool CreateSCS(STUDENT__COURSE_SECTION obj);
        STUDENT__COURSE_SECTION GetSCS(int id);
        List<STUDENT__COURSE_SECTION> GetListaSCS();
    }
}
