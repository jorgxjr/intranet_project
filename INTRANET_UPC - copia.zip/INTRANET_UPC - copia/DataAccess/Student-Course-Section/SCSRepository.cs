﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Student_Course_Section
{
    public class SCSRepository : ISCSRepository
    {
        public bool CreateSCS(STUDENT__COURSE_SECTION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.STUDENT__COURSE_SECTION.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<STUDENT__COURSE_SECTION> GetListSCS()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var scs = from c in dataContext.STUDENT__COURSE_SECTION.
                         Include("STUDENT.USER").
                         Include("SCORE")
                         select c;

                return scs.ToList();
            }
        }

        public List<STUDENT__COURSE_SECTION> GetListSCSByCSID(int csID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var scs = from c in dataContext.STUDENT__COURSE_SECTION.
                         Include("STUDENT.USER").
                         Include("STUDENT.CAREER")
                         where c.Course_SectionID.Equals(csID)
                         select c;

                return scs.ToList();
            }
        }

        public List<STUDENT__COURSE_SECTION> GetListSCSByTeacherID(int teacherID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var scs = from c in dataContext.STUDENT__COURSE_SECTION.
                         Include("STUDENT.USER").
                         Include("SCORE").
                         Include("COURSE_SECTION.TECHER_COURSE.COURSE").
                         Include("COURSE_SECTION.SECTION")
                          where c.COURSE_SECTION.TECHER_COURSE.TeacherID.Equals(teacherID)
                          select c;

                return scs.ToList();
            }
        }

        public STUDENT__COURSE_SECTION GetSCS(int id)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var scs = dataContext.STUDENT__COURSE_SECTION.First(i => i.ID == id);

                return scs;
            }
        }
        public bool UpdateSCS(int id, int scoreID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var scs = dataContext.STUDENT__COURSE_SECTION.First(i => i.ID == id);
                    scs.ScoreID = scoreID;
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }
    }
}
