﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Student_Course_Section
{
    public class SCSRepository : ISCSRepository
    {
        public bool CreateSCS(STUDENT__COURSE_SECTION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.STUDENT__COURSE_SECTION.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public List<STUDENT__COURSE_SECTION> GetListaSCS()
        {
            throw new NotImplementedException();
        }

        public STUDENT__COURSE_SECTION GetSCS(int id)
        {
            throw new NotImplementedException();
        }
    }
}
