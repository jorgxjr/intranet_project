﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Course_Section
{
    public class CSRepository : ICSRepository
    {
        public bool CreateCS(COURSE_SECTION obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.COURSE_SECTION.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public COURSE_SECTION GetCS(int id)
        {
            throw new NotImplementedException();
        }

        public List<COURSE_SECTION> GetListCS()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var cs = from c in dataContext.COURSE_SECTION select c;

                return cs.ToList();
            }
        }

        public List<COURSE_SECTION> GetListCSByTCID(int tcID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var cs = from c in dataContext.COURSE_SECTION.
                         Include("SECTION")
                         where c.Teacher_CourseID.Equals(tcID)
                         select c;

                return cs.ToList();
            }
        }
    }
}
