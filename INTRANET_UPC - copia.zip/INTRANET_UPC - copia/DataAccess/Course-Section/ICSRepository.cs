﻿using ENTITIES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Course_Section
{
    public interface ICSRepository
    {
        bool CreateCS(COURSE_SECTION obj);
        COURSE_SECTION GetCS(int id);
        List<COURSE_SECTION> GetListCS();
        List<COURSE_SECTION> GetListCSByTCID(int tCID);
    }
}
