﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Teachers
{
    public class TeacherRepository : ITeacherRepository
    {
        public bool CreateTeacher(TEACHER obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.TEACHERs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteTeacher(int teacherId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var teacher = from c in dataContext.TEACHERs where c.ID == teacherId select c;
                    TEACHER objTeacher = teacher.FirstOrDefault();

                    dataContext.TEACHERs.Remove(objTeacher);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public TEACHER GetTeacher(int teacherId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var teacher = from c in dataContext.TEACHERs where c.ID == teacherId select c;
                TEACHER objTeacher = teacher.FirstOrDefault();

                return objTeacher;
            }
        }

        public List<TEACHER> GetTeacher()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var teacher = from c in dataContext.TEACHERs select c;

                return teacher.ToList();
            }
        }

        public bool UpdateTeacher(TEACHER obj)
        {
            throw new NotImplementedException();
        }
    }
}
