﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Teachers
{
    public interface ITeacherRepository
    {
        bool CreateTeacher(TEACHER obj);
        bool UpdateTeacher(TEACHER obj);
        bool DeleteTeacher(int teacherId);
        TEACHER GetTeacher(int teacherId);
        List<TEACHER> GetTeacher();
    }
}
