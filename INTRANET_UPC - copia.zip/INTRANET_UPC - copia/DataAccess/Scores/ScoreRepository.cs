﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Scores
{
    public class ScoreRepository : IScoreRepository
    {
        public bool CreateScore(SCORE obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.SCOREs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public SCORE GetScore(int id)
        {
            throw new NotImplementedException();
        }

        public List<SCORE> GetScores()
        {
            throw new NotImplementedException();
        }
    }
}
