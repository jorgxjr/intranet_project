﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Teacher_Course
{
    public class TCRepository : ITCRepository
    {
        public TECHER_COURSE GetTCByTeacherID(int teacherID)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var cs = dataContext.TECHER_COURSE.First(i => i.TeacherID == teacherID);

                //var item = Items.First(i => i.Id == 123);

                return cs;
            }
        }
    }
}
