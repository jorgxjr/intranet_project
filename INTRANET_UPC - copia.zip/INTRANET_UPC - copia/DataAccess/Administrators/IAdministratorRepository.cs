﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Administrators
{
    public interface IAdministratorRepository
    {
        bool CreateAdministrator(ADMINISTRATOR obj);
        bool UpdateAdministrator(ADMINISTRATOR obj);
        bool DeleteAdministrator(int administratorId);
        ADMINISTRATOR GetAdministrator(int administratorId);
        List<ADMINISTRATOR> GetAdministrator();
    }
}
