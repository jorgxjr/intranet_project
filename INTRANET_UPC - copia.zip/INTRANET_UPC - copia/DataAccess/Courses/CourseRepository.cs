﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Courses
{
    public class CourseRepository : ICourseRepository
    {
        public bool CreateCourse(COURSE obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.COURSEs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteCourse(int courseId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var course = from c in dataContext.COURSEs where c.ID == courseId select c;
                    COURSE objCourse = course.FirstOrDefault();

                    dataContext.COURSEs.Remove(objCourse);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public COURSE GetCourse(int courseId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var course = from c in dataContext.COURSEs where c.ID == courseId select c;
                COURSE objCourse = course.FirstOrDefault();

                return objCourse;
            }
        }

        public List<COURSE> GetCourse()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var course = from c in dataContext.COURSEs.Include("AREA") select c;

                return course.ToList();
            }
        }

        public COURSE GetCourse(string courseName)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var course = from c in dataContext.COURSEs where c.Name == courseName select c;
                COURSE objCourse = course.FirstOrDefault();

                return objCourse;
            }
        }

        public COURSE GetCourse_AreaID(int areaId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var course = from c in dataContext.COURSEs where c.AreaID == areaId select c;
                COURSE objCourse = course.FirstOrDefault();

                return objCourse;
            }
        }

        public bool UpdateCourse(COURSE obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var course = from c in dataContext.COURSEs where c.ID == obj.ID select c;

                    COURSE objCourse = course.FirstOrDefault();
                    objCourse.Name = obj.Name;
                    objCourse.Obligatory = obj.Obligatory;
                    objCourse.AreaID = obj.AreaID;
                    objCourse.Credit = obj.Credit;

                    dataContext.SaveChanges();

                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }
    }
}
