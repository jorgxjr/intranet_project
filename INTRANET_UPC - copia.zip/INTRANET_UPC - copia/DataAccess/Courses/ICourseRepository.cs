﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Courses
{
    public interface ICourseRepository
    {
        bool CreateCourse(COURSE obj);
        bool UpdateCourse(COURSE obj);
        bool DeleteCourse(int courseId);
        COURSE GetCourse(int courseId);
        COURSE GetCourse(string courseName);
        COURSE GetCourse_AreaID(int areaId);
        List<COURSE> GetCourse();
    }
}
