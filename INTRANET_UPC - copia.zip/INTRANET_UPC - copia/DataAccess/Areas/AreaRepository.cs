﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ENTITIES;

namespace DataAccess.Areas
{
    public class AreaRepository : IAreaRepository
    {
        public bool CreateArea(AREA obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    dataContext.AREAs.Add(obj);
                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public bool DeleteArea(int areaId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var area = from c in dataContext.AREAs where c.ID == areaId select c;
                    AREA objArea = area.FirstOrDefault();

                    dataContext.AREAs.Remove(objArea);

                    dataContext.SaveChanges();
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }

        public AREA GetArea(int areaId)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var area = from c in dataContext.AREAs where c.ID == areaId select c;
                AREA objArea = area.FirstOrDefault();

                return objArea;
            }
        }

        public List<AREA> GetArea()
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var area = from c in dataContext.AREAs select c;

                return area.ToList();
            }
        }

        public AREA GetArea(AREA areaDescription)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                var area = from c in dataContext.AREAs where c.Description == areaDescription.Description && c.ID!=areaDescription.ID select c;
                AREA objArea = area.FirstOrDefault();

                return objArea;
            }
        }

        public bool UpdateArea(AREA obj)
        {
            using (var dataContext = new IntranetUPCEntitiesContext())
            {
                try
                {
                    var area = from c in dataContext.AREAs where c.ID == obj.ID select c;

                  
                    AREA objArea = area.FirstOrDefault();
                    objArea.Description = obj.Description;
                    
                    dataContext.SaveChanges();

                    return true;
                }
                catch(Exception e)
                {
                    return false;
                }
            }
        }
    }
}
